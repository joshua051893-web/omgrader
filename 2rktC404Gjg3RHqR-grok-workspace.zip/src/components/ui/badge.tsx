import type { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Badge({
  className,
  tone = "neutral",
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: "neutral" | "ok" | "warn" | "danger" | "accent" }) {
  const tones = {
    neutral: "bg-bg text-muted border-line",
    ok: "bg-accent-soft text-ok border-transparent",
    warn: "bg-[#f3e6cf] text-warn border-transparent dark:bg-[#3a2e16]",
    danger: "bg-[#f3d6d2] text-danger border-transparent dark:bg-[#3a2220]",
    accent: "bg-accent text-accent-fg border-transparent",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium",
        tones[tone],
        className,
      )}
      {...props}
    />
  );
}
