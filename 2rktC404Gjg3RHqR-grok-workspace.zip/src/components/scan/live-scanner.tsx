import { useEffect, useRef, useState } from "react";
import { Camera, Flashlight, FlashlightOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  captureVideoFrame,
  detectOnCanvas,
  markerSquares,
  paperGuide,
  scoreAlignment,
  videoLetterbox,
  type AlignFrame,
  type CornerId,
} from "@/lib/omr/live-align";
import { cn } from "@/lib/utils";

interface Props {
  paperWidthMm: number;
  paperHeightMm: number;
  busy?: boolean;
  onCapture: (canvas: HTMLCanvasElement) => Promise<void> | void;
}

const CORNERS: CornerId[] = ["tl", "tr", "br", "bl"];

export function LiveScanner({ paperWidthMm, paperHeightMm, busy, onCapture }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef(0);
  const lockRef = useRef(0);
  const coolRef = useRef(0);
  const capturingRef = useRef(false);
  const detectScratch = useRef<HTMLCanvasElement | null>(null);
  const flashUntil = useRef(0);
  const onCaptureRef = useRef(onCapture);
  const busyRef = useRef(busy);
  const paperRef = useRef({ w: paperWidthMm, h: paperHeightMm });
  const lastHits = useRef("");
  const [on, setOn] = useState(false);
  const [torch, setTorch] = useState(false);
  const [status, setStatus] = useState("Start the camera, then line up the four corner squares");
  const [hits, setHits] = useState<Record<CornerId, boolean>>({ tl: false, tr: false, bl: false, br: false });
  const [lastOk, setLastOk] = useState<string | null>(null);

  onCaptureRef.current = onCapture;
  busyRef.current = busy;
  paperRef.current = { w: paperWidthMm, h: paperHeightMm };

  useEffect(() => () => stop(), []);

  async function start() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: "environment" },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
      });
      streamRef.current = stream;
      const v = videoRef.current;
      if (!v) return;
      v.srcObject = stream;
      await v.play();
      setOn(true);
      setStatus("Point at the sheet. Drop each black corner square into a target square.");
      loop();
    } catch {
      toast.error("Camera access was blocked. Allow the camera, or upload a photo instead.");
    }
  }

  function stop() {
    cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setOn(false);
    setTorch(false);
    lockRef.current = 0;
  }

  async function toggleTorch() {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return;
    try {
      await track.applyConstraints({ advanced: [{ torch: !torch } as MediaTrackConstraintSet] });
      setTorch((t) => !t);
    } catch {
      toast.error("Torch is not available on this camera.");
    }
  }

  function beep() {
    try {
      const ctx = new AudioContext();
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = 880;
      o.connect(g);
      g.connect(ctx.destination);
      g.gain.value = 0.05;
      o.start();
      o.stop(ctx.currentTime + 0.12);
    } catch {
      /* ignore */
    }
  }

  async function grab(auto: boolean) {
    const v = videoRef.current;
    if (!v || capturingRef.current || busyRef.current) return;
    if (Date.now() < coolRef.current) return;
    capturingRef.current = true;
    flashUntil.current = Date.now() + 140;
    if (auto) beep();
    try {
      const frame = captureVideoFrame(v);
      setStatus("Reading sheet…");
      await onCaptureRef.current(frame);
      setLastOk(new Date().toLocaleTimeString());
      setStatus("Captured. Show the next paper.");
      coolRef.current = Date.now() + 1600;
      lockRef.current = 0;
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Capture failed.");
      setStatus("Could not read that frame. Line up the corners and try again.");
    } finally {
      capturingRef.current = false;
    }
  }

  function loop() {
    const v = videoRef.current;
    const ov = overlayRef.current;
    const wrap = wrapRef.current;
    if (!v || !ov || !wrap || !streamRef.current) return;
    rafRef.current = requestAnimationFrame(loop);
    if (!v.videoWidth) return;

    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const cssW = wrap.clientWidth;
    const cssH = wrap.clientHeight;
    if (ov.width !== Math.round(cssW * dpr) || ov.height !== Math.round(cssH * dpr)) {
      ov.width = Math.round(cssW * dpr);
      ov.height = Math.round(cssH * dpr);
    }
    const ctx = ov.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cssW, cssH);

    const box = videoLetterbox(v.videoWidth, v.videoHeight, cssW, cssH);
    ctx.drawImage(v, box.x, box.y, box.w, box.h);

    const guide = paperGuide(box, paperRef.current.w, paperRef.current.h);
    let align: AlignFrame | null = null;

    if (!capturingRef.current && !busyRef.current && Date.now() > coolRef.current) {
      if (!detectScratch.current) detectScratch.current = document.createElement("canvas");
      const small = detectScratch.current;
      const maxW = 720;
      const s = Math.min(1, maxW / v.videoWidth);
      small.width = Math.max(1, Math.round(v.videoWidth * s));
      small.height = Math.max(1, Math.round(v.videoHeight * s));
      small.getContext("2d")!.drawImage(v, 0, 0, small.width, small.height);
      const found = detectOnCanvas(small);
      const mapped = found
        ? {
            tl: { x: box.x + found.tl.x * (box.w / small.width), y: box.y + found.tl.y * (box.h / small.height) },
            tr: { x: box.x + found.tr.x * (box.w / small.width), y: box.y + found.tr.y * (box.h / small.height) },
            bl: { x: box.x + found.bl.x * (box.w / small.width), y: box.y + found.bl.y * (box.h / small.height) },
            br: { x: box.x + found.br.x * (box.w / small.width), y: box.y + found.br.y * (box.h / small.height) },
          }
        : null;
      align = scoreAlignment(mapped, guide, paperRef.current.w, paperRef.current.h);
      const hits4 = CORNERS.every((c) => align!.hits[c]);
      if (align.locked || hits4) {
        lockRef.current += 1;
        if (lockRef.current >= 3) void grab(true);
      } else {
        lockRef.current = Math.max(0, lockRef.current - 1);
      }
      const key = CORNERS.map((c) => (align!.hits[c] ? "1" : "0")).join("") + align.message;
      if (key !== lastHits.current) {
        lastHits.current = key;
        setHits(align.hits);
        setStatus(align.message);
      }
    }

    drawOverlay(ctx, cssW, cssH, guide, align, lockRef.current, paperRef.current.w, paperRef.current.h);
    if (Date.now() < flashUntil.current) {
      ctx.fillStyle = "rgba(255,255,255,0.55)";
      ctx.fillRect(0, 0, cssW, cssH);
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <p className="text-xs font-medium tracking-wide text-muted uppercase">Live scan</p>
          <p className="text-sm text-ink">{status}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {!on ? (
            <Button onClick={() => void start()}>
              <Camera /> Start live scan
            </Button>
          ) : (
            <>
              <Button variant="outline" onClick={() => void toggleTorch()}>
                {torch ? <FlashlightOff /> : <Flashlight />} Light
              </Button>
              <Button variant="outline" disabled={busy} onClick={() => void grab(false)}>
                Capture now
              </Button>
              <Button variant="ghost" onClick={stop}>
                Stop camera
              </Button>
            </>
          )}
        </div>
      </div>
      <div
        ref={wrapRef}
        className="relative min-h-[62vh] overflow-hidden rounded-[var(--radius-lg)] border border-line bg-ink sm:min-h-[70vh]"
      >
        <video ref={videoRef} className="pointer-events-none absolute h-px w-px opacity-0" playsInline muted autoPlay />
        <canvas ref={overlayRef} className="absolute inset-0 h-full w-full" />
        <div className="pointer-events-none absolute inset-x-0 top-0 flex justify-between p-3">
          {(["tl", "tr"] as CornerId[]).map((id) => (
            <CornerChip key={id} on={hits[id]} label={id.toUpperCase()} />
          ))}
        </div>
        <div className="pointer-events-none absolute inset-x-0 bottom-0 flex justify-between p-3">
          {(["bl", "br"] as CornerId[]).map((id) => (
            <CornerChip key={id} on={hits[id]} label={id.toUpperCase()} />
          ))}
        </div>
        {lastOk && (
          <p className="pointer-events-none absolute right-3 bottom-10 rounded-full bg-ok px-2 py-0.5 text-[10px] text-accent-fg">
            Last capture {lastOk}
          </p>
        )}
      </div>
      <p className="text-xs text-muted">
        Hold the paper so it fills the large frame and each black corner sits in a square. When all four lock, the sheet captures by itself.
      </p>
    </div>
  );
}

function CornerChip({ on, label }: { on: boolean; label: string }) {
  return (
    <span
      className={cn(
        "rounded-full px-2 py-0.5 text-[10px] font-medium",
        on ? "bg-ok text-accent-fg" : "bg-surface/80 text-muted",
      )}
    >
      {label}
    </span>
  );
}

function drawOverlay(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  guide: { x: number; y: number; w: number; h: number },
  align: AlignFrame | null,
  lock: number,
  paperW: number,
  paperH: number,
) {
  ctx.save();
  ctx.beginPath();
  ctx.rect(0, 0, w, h);
  ctx.rect(guide.x, guide.y, guide.w, guide.h);
  ctx.fillStyle = "rgba(12,10,8,0.48)";
  ctx.fill("evenodd");

  const squares = markerSquares(guide, paperW, paperH);
  for (const id of CORNERS) {
    const sq = squares[id];
    const hit = Boolean(align?.hits[id]);
    ctx.strokeStyle = hit ? "#3d9a6e" : "#f4efe6";
    ctx.lineWidth = hit ? 4 : 3;
    ctx.strokeRect(sq.x, sq.y, sq.s, sq.s);
    ctx.strokeStyle = hit ? "rgba(61,154,110,0.55)" : "rgba(244,239,230,0.45)";
    ctx.lineWidth = 1.5;
    ctx.strokeRect(sq.x + 5, sq.y + 5, sq.s - 10, sq.s - 10);
  }

  if (align) {
    for (const id of CORNERS) {
      const p = align.corners[id];
      if (!p) continue;
      ctx.fillStyle = align.hits[id] ? "#3d9a6e" : "#e0b56a";
      ctx.beginPath();
      ctx.arc(p.x, p.y, 5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  if (lock > 0) {
    const t = Math.min(1, lock / 3);
    ctx.strokeStyle = `rgba(61,154,110,${0.35 + t * 0.65})`;
    ctx.lineWidth = 3;
    ctx.strokeRect(guide.x + 8, guide.y + 8, guide.w - 16, guide.h - 16);
  }
  ctx.restore();
}
