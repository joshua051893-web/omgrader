import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import type { Assessment, ScanResult } from "@/lib/types";

function classLabel(a: Pick<Assessment, "name" | "gradeLevel" | "section" | "testSet">) {
  return `${a.name} · Grade ${a.gradeLevel}-${a.section}${a.testSet ? ` · Set ${a.testSet}` : ""}`;
}

export type ScanPrompt =
  | {
      type: "reroute";
      reason: "wrong_exam" | "wrong_section";
      from: Assessment;
      to: Assessment;
      resolve: (saveThere: boolean) => void;
    }
  | {
      type: "unknown";
      code: string;
      current: Assessment;
      resolve: (keep: boolean) => void;
    }
  | {
      type: "duplicate";
      assessment: Assessment;
      roll: string;
      studentName: string;
      previous: ScanResult;
      incomingScore: string;
      resolve: (replace: boolean) => void;
    }
  | {
      type: "blocked";
      message: string;
      resolve: () => void;
    };

export function ScanPromptDialog({ prompt }: { prompt: ScanPrompt | null }) {
  if (!prompt) return null;

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) {
          if (prompt.type === "reroute") prompt.resolve(false);
          else if (prompt.type === "duplicate") prompt.resolve(false);
          else if (prompt.type === "unknown") prompt.resolve(false);
          else prompt.resolve();
        }
      }}
    >
      <DialogContent className="space-y-4" onPointerDownOutside={(e) => e.preventDefault()}>
        {prompt.type === "reroute" && (
          <>
            <DialogTitle>{prompt.reason === "wrong_section" ? "Different section" : "Different exam"}</DialogTitle>
            <p className="text-sm text-muted">
              This paper belongs to{" "}
              <strong className="text-ink">{classLabel(prompt.to)}</strong>, not {classLabel(prompt.from)}.
            </p>
            <p className="text-sm text-muted">
              It will not be saved under the class you have selected. Save it on the paper’s actual section, or cancel.
            </p>
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => prompt.resolve(true)}>Save on Grade {prompt.to.gradeLevel}-{prompt.to.section}</Button>
              <Button variant="outline" onClick={() => prompt.resolve(false)}>
                Cancel
              </Button>
            </div>
          </>
        )}
        {prompt.type === "unknown" && (
          <>
            <DialogTitle>Unknown exam code</DialogTitle>
            <p className="text-sm text-muted">
              The barcode <span className="font-mono text-ink">{prompt.code}</span> does not match any assessment in OMG.
            </p>
            <p className="text-sm text-muted">Cancel this sheet, or record it only if it is for {classLabel(prompt.current)}.</p>
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => prompt.resolve(true)}>Record here</Button>
              <Button variant="outline" onClick={() => prompt.resolve(false)}>
                Cancel
              </Button>
            </div>
          </>
        )}
        {prompt.type === "duplicate" && (
          <>
            <DialogTitle>Already scanned</DialogTitle>
            <p className="text-sm text-muted">
              Roll <strong className="text-ink">{prompt.roll}</strong>
              {prompt.studentName ? ` (${prompt.studentName})` : ""} already has a paper for{" "}
              <strong className="text-ink">{classLabel(prompt.assessment)}</strong>
              {": "}
              {prompt.previous.score} points ({Math.round(prompt.previous.percentage)}%).
            </p>
            <p className="text-sm text-muted">Incoming score: {prompt.incomingScore}. Replace the previous scan, or cancel this one?</p>
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => prompt.resolve(true)}>Replace</Button>
              <Button variant="outline" onClick={() => prompt.resolve(false)}>
                Cancel
              </Button>
            </div>
          </>
        )}
        {prompt.type === "blocked" && (
          <>
            <DialogTitle>Cannot save this sheet</DialogTitle>
            <p className="text-sm text-muted">{prompt.message}</p>
            <Button onClick={prompt.resolve}>OK</Button>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
