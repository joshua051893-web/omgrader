import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import type { Assessment } from "@/lib/types";
import { buildLayout } from "@/lib/sheets/layout";
import { findFiducials } from "@/lib/omr/fiducials";
import { loadImageElement, toGrayscale } from "@/lib/omr/image";
import { uprightForReview } from "@/lib/omr/upright";
import type { Pt } from "@/lib/omr/geometry";
import { keysForSet } from "@/lib/types";
import { detectSheet, type OmRDetection } from "@/lib/omr/scan";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type CornerId = "tl" | "tr" | "bl" | "br";
const CORNERS: CornerId[] = ["tl", "tr", "br", "bl"];
const LABELS: Record<CornerId, string> = { tl: "TL", tr: "TR", bl: "BL", br: "BR" };

interface Props {
  src: string;
  assessment: Assessment;
  busy?: boolean;
  onReread: (detection: OmRDetection, source: HTMLCanvasElement) => Promise<void> | void;
}

export function AnchorAdjust({ src, assessment, busy, onReread }: Props) {
  const imgRef = useRef<HTMLImageElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const sourceRef = useRef<HTMLCanvasElement | null>(null);
  const drag = useRef<{ id: CornerId; dx: number; dy: number } | null>(null);
  const [corners, setCorners] = useState<Record<CornerId, Pt> | null>(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [preview, setPreview] = useState<string | null>(null);
  const [natural, setNatural] = useState({ w: 1, h: 1 });
  const [box, setBox] = useState({ w: 1, h: 1 });
  const [status, setStatus] = useState("Drag each square onto a black corner marker, then re-read.");

  useEffect(() => {
    let gone = false;
    void (async () => {
      const img = await loadHtml(src);
      if (gone) return;
      const raw = await loadImageElement(img);
      const { canvas, corners: found } = uprightForReview(raw);
      sourceRef.current = canvas;
      setPreview(canvas.toDataURL("image/jpeg", 0.92));
      setNatural({ w: canvas.width, h: canvas.height });
      const inset = Math.min(canvas.width, canvas.height) * 0.07;
      setCorners(
        found ?? {
          tl: { x: inset, y: inset },
          tr: { x: canvas.width - inset, y: inset },
          bl: { x: inset, y: canvas.height - inset },
          br: { x: canvas.width - inset, y: canvas.height - inset },
        },
      );
      setStatus(
        found
          ? "Sheet turned upright. Drag a square if a marker is off, then re-read."
          : "Place the four squares on the black corner markers.",
      );
    })();
    return () => {
      gone = true;
    };
  }, [src]);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const measure = () => setBox({ w: el.clientWidth, h: el.clientHeight });
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [corners, natural.w, natural.h]);

  const scale = Math.min(box.w / natural.w, box.h / natural.h);
  const ox = (box.w - natural.w * scale) / 2;
  const oy = (box.h - natural.h * scale) / 2;
  const toScreen = (p: Pt) => ({ x: ox + p.x * scale, y: oy + p.y * scale });
  const toImage = (sx: number, sy: number): Pt => ({
    x: Math.max(0, Math.min(natural.w, (sx - ox) / scale)),
    y: Math.max(0, Math.min(natural.h, (sy - oy) / scale)),
  });

  function onPointerDown(id: CornerId, e: React.PointerEvent) {
    if (!corners) return;
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    const wrap = wrapRef.current!.getBoundingClientRect();
    const s = toScreen(corners[id]);
    drag.current = { id, dx: e.clientX - wrap.left - s.x, dy: e.clientY - wrap.top - s.y };
  }

  function onPointerMove(e: React.PointerEvent) {
    if (!drag.current || !corners) return;
    const wrap = wrapRef.current!.getBoundingClientRect();
    const p = toImage(e.clientX - wrap.left - drag.current.dx, e.clientY - wrap.top - drag.current.dy);
    const id = drag.current.id;
    setCorners({ ...corners, [id]: p });
  }

  function onPointerUp() {
    drag.current = null;
  }

  async function reread() {
    const canvas = sourceRef.current;
    if (!canvas || !corners) return;
    setStatus("Re-reading bubbles…");
    const detection = await detectSheet(canvas, assessment, { corners, offsetMm: offset });
    await onReread(detection, canvas);
    setStatus(detection.valid ? "Re-read complete. Check the answers below." : "Could not lock those corners. Nudge the squares and try again.");
  }

  const layout = buildLayout({ ...assessment.sheetConfig, itemCount: assessment.itemCount });
  const key = keysForSet(assessment);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <p className="text-xs font-medium tracking-wide text-muted uppercase">Anchor calibration</p>
          <p className="text-sm text-ink">{status}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              const canvas = sourceRef.current;
              if (!canvas) return;
              const gray = toGrayscale(canvas);
              const found = findFiducials(gray.data, gray.width, gray.height);
              if (found) {
                setCorners(found);
                setStatus("Auto-detected corners. Drag if a marker is off.");
              } else {
                toast.error("No corner markers found. Drag the squares onto them by hand.");
              }
            }}
          >
            Auto-find
          </Button>
          <Button size="sm" disabled={busy || !corners} onClick={() => void reread()}>
            Re-read with these anchors
          </Button>
        </div>
      </div>

      <div
        ref={wrapRef}
        className="relative w-full overflow-hidden rounded-[var(--radius-md)] border border-line bg-ink"
        style={{ aspectRatio: `${natural.w} / ${natural.h}`, maxHeight: "70vh" }}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
      >
        <img ref={imgRef} src={src} alt="" className="pointer-events-none hidden" />
        {corners && (
          <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox={`0 0 ${box.w} ${box.h}`}>
            <image href={preview ?? src} x={ox} y={oy} width={natural.w * scale} height={natural.h * scale} />
            <polygon
              points={CORNERS.map((id) => {
                const s = toScreen(corners[id]);
                return `${s.x},${s.y}`;
              }).join(" ")}
              fill="rgba(61,154,110,0.08)"
              stroke="#3d9a6e"
              strokeWidth={2}
              strokeDasharray="6 4"
            />
            {layout.answerBubbles.map((b, i) => {
              const imgP = mapBubble(b, layout, corners, offset);
              if (!imgP) return null;
              const p = toScreen(imgP);
              const isKey = key[b.item] === b.choice;
              const r = Math.max(2.5, b.r * (natural.w / layout.widthMm) * scale * 0.85);
              return (
                <circle
                  key={`${b.item}-${b.choice}-${i}`}
                  cx={p.x}
                  cy={p.y}
                  r={r}
                  fill={isKey ? "rgba(61,154,110,0.35)" : "none"}
                  stroke={isKey ? "#3d9a6e" : "rgba(244,239,230,0.65)"}
                  strokeWidth={isKey ? 1.6 : 0.8}
                />
              );
            })}
          </svg>
        )}
        {corners &&
          CORNERS.map((id) => {
            const s = toScreen(corners[id]);
            return (
              <button
                key={id}
                type="button"
                className={cn(
                  "absolute z-10 flex size-9 -translate-x-1/2 -translate-y-1/2 touch-none cursor-grab items-center justify-center rounded-sm border-2 bg-surface/95 text-[10px] font-bold text-ok active:cursor-grabbing",
                  "border-ok shadow-sm",
                )}
                style={{ left: s.x, top: s.y }}
                onPointerDown={(e) => onPointerDown(id, e)}
                onPointerMove={onPointerMove}
                onPointerUp={onPointerUp}
                onPointerCancel={onPointerUp}
              >
                {LABELS[id]}
              </button>
            );
          })}
      </div>

      <div className="flex flex-wrap items-center gap-2 text-sm">
        <span className="text-xs font-medium tracking-wide text-muted uppercase">Bubble grid</span>
        <Nudge label="←" onClick={() => setOffset((o) => ({ ...o, x: o.x - 0.5 }))} />
        <Nudge label="→" onClick={() => setOffset((o) => ({ ...o, x: o.x + 0.5 }))} />
        <Nudge label="↑" onClick={() => setOffset((o) => ({ ...o, y: o.y - 0.5 }))} />
        <Nudge label="↓" onClick={() => setOffset((o) => ({ ...o, y: o.y + 0.5 }))} />
        <span className="font-mono text-xs text-muted">
          offset {offset.x.toFixed(1)} mm, {offset.y.toFixed(1)} mm
        </span>
        <Button variant="ghost" size="sm" onClick={() => setOffset({ x: 0, y: 0 })}>
          Reset grid
        </Button>
      </div>
      <p className="text-xs text-muted">
        Green circles are the answer-key positions. Drag the four corner squares onto the printed markers. If the circles sit off the bubbles, nudge the grid, then re-read.
      </p>
    </div>
  );
}

function Nudge({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <Button type="button" variant="outline" size="sm" className="min-w-8 px-2" onClick={onClick}>
      {label}
    </Button>
  );
}

function loadHtml(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not open the scan image."));
    img.src = src;
  });
}

function mapBubble(
  b: { cx: number; cy: number },
  layout: { widthMm: number; heightMm: number; fiducials: { id: string; x: number; y: number; size: number }[] },
  corners: Record<CornerId, Pt>,
  offset: { x: number; y: number },
): Pt | null {
  const fid = (id: string) => layout.fiducials.find((f) => f.id === id)!;
  const src = [
    { x: fid("TL").x + fid("TL").size / 2, y: fid("TL").y + fid("TL").size / 2 },
    { x: fid("TR").x + fid("TR").size / 2, y: fid("TR").y + fid("TR").size / 2 },
    { x: fid("BR").x + fid("BR").size / 2, y: fid("BR").y + fid("BR").size / 2 },
    { x: fid("BL").x + fid("BL").size / 2, y: fid("BL").y + fid("BL").size / 2 },
  ];
  const dst = [corners.tl, corners.tr, corners.br, corners.bl];
  return bilinearMap({ x: b.cx + offset.x, y: b.cy + offset.y }, src, dst);
}

/** Map a point in sheet-mm through the four-corner correspondence onto the photo. */
function bilinearMap(p: Pt, src: Pt[], dst: Pt[]): Pt | null {
  const [s0, s1, s2, s3] = src;
  const [d0, d1, d2, d3] = dst;
  if (!s0 || !s1 || !s2 || !s3 || !d0 || !d1 || !d2 || !d3) return null;
  const minX = Math.min(s0.x, s1.x, s2.x, s3.x);
  const maxX = Math.max(s0.x, s1.x, s2.x, s3.x);
  const minY = Math.min(s0.y, s1.y, s2.y, s3.y);
  const maxY = Math.max(s0.y, s1.y, s2.y, s3.y);
  const u = (p.x - minX) / Math.max(1, maxX - minX);
  const v = (p.y - minY) / Math.max(1, maxY - minY);
  const top = lerp(d0, d1, u);
  const bot = lerp(d3, d2, u);
  return lerp(top, bot, v);
}

function lerp(a: Pt, b: Pt, t: number): Pt {
  return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
}
