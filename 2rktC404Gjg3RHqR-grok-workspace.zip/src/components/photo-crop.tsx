import { useEffect, useRef, useState, type PointerEvent } from "react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

interface Props {
  open: boolean;
  src: string | null;
  onOpenChange: (open: boolean) => void;
  onCropped: (blob: Blob) => void;
}

const OUT = 512;
const VIEW = 280;

export function PhotoCropDialog({ open, src, onOpenChange, onCropped }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const drag = useRef<{ x: number; y: number; ox: number; oy: number } | null>(null);
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!open || !src) return;
    const img = new Image();
    img.onload = () => {
      imgRef.current = img;
      const min = Math.min(img.width, img.height);
      const fit = VIEW / min;
      setZoom(fit);
      setOffset({ x: (VIEW - img.width * fit) / 2, y: (VIEW - img.height * fit) / 2 });
      setReady(true);
    };
    img.src = src;
    return () => {
      setReady(false);
      imgRef.current = null;
    };
  }, [open, src]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img || !ready) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.fillStyle = "#111";
    ctx.fillRect(0, 0, VIEW, VIEW);
    ctx.drawImage(img, offset.x, offset.y, img.width * zoom, img.height * zoom);
    ctx.strokeStyle = "rgba(255,255,255,0.85)";
    ctx.lineWidth = 2;
    ctx.strokeRect(1, 1, VIEW - 2, VIEW - 2);
  }, [offset, zoom, ready, open]);

  function pointerDown(e: PointerEvent<HTMLCanvasElement>) {
    e.currentTarget.setPointerCapture(e.pointerId);
    drag.current = { x: e.clientX, y: e.clientY, ox: offset.x, oy: offset.y };
  }
  function pointerMove(e: PointerEvent<HTMLCanvasElement>) {
    if (!drag.current) return;
    setOffset({
      x: drag.current.ox + (e.clientX - drag.current.x),
      y: drag.current.oy + (e.clientY - drag.current.y),
    });
  }
  function pointerUp() {
    drag.current = null;
  }

  function exportCrop() {
    const img = imgRef.current;
    if (!img) return;
    const out = document.createElement("canvas");
    out.width = OUT;
    out.height = OUT;
    const ctx = out.getContext("2d");
    if (!ctx) return;
    const scale = OUT / VIEW;
    ctx.fillStyle = "#111";
    ctx.fillRect(0, 0, OUT, OUT);
    ctx.drawImage(img, offset.x * scale, offset.y * scale, img.width * zoom * scale, img.height * zoom * scale);
    out.toBlob(
      (blob) => {
        if (blob) onCropped(blob);
      },
      "image/jpeg",
      0.92,
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogTitle>Crop photo</DialogTitle>
        <p className="mt-1 mb-4 text-sm text-muted">Drag to reposition. Use the slider to zoom. The square is what will appear on your profile.</p>
        <div className="flex flex-col items-center gap-4">
          <canvas
            ref={canvasRef}
            width={VIEW}
            height={VIEW}
            className="touch-none rounded-[var(--radius-md)] border border-line"
            style={{ width: VIEW, height: VIEW, cursor: "grab" }}
            onPointerDown={pointerDown}
            onPointerMove={pointerMove}
            onPointerUp={pointerUp}
            onPointerCancel={pointerUp}
          />
          <div className="w-full max-w-[280px]">
            <Label>Zoom</Label>
            <input
              type="range"
              min={0.2}
              max={3}
              step={0.01}
              value={zoom}
              onChange={(e) => setZoom(Number(e.target.value))}
              className="mt-1 w-full accent-[var(--color-accent)]"
            />
          </div>
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={exportCrop}>Save cropped photo</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
