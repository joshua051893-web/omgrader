import type { ReactNode } from "react";
import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import {
  BookOpen,
  ClipboardList,
  LayoutDashboard,
  ScanLine,
  Settings,
  Users,
  BarChart3,
  UserRound,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { db } from "@/lib/db/database";
import { DEFAULT_SETTINGS } from "@/lib/db/defaults";
import { blobUrl } from "@/lib/db/repo";
import { ThemeToggle } from "@/components/theme-toggle";
import { BackButton } from "@/components/nav/back-button";

const NAV = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/students", label: "Students", icon: Users },
  { to: "/assessments", label: "Assessments", icon: ClipboardList },
  { to: "/scan", label: "Scan papers", icon: ScanLine },
  { to: "/gradebook", label: "Gradebook", icon: BookOpen },
  { to: "/reports", label: "Reports", icon: BarChart3 },
  { to: "/profile", label: "Profile", icon: UserRound },
  { to: "/settings", label: "Settings", icon: Settings },
];

const CREDIT = "Developed by J.D.C. of SPCIHS, to support - 09197677274";
const CREDIT_TEL = "09197677274";

function CreditBanner({ place }: { place: "top" | "bottom" }) {
  return (
    <div
      className={cn(
        "credit-banner fixed inset-x-0 z-[70] bg-accent px-3 py-1.5 text-center text-[11px] leading-snug font-medium tracking-wide text-accent-fg",
        place === "top" ? "top-0" : "bottom-0",
      )}
      role={place === "bottom" ? "contentinfo" : "banner"}
      aria-label={CREDIT}
    >
      Developed by J.D.C. of SPCIHS, to support -{" "}
      <a href={`tel:${CREDIT_TEL}`} className="underline decoration-accent-fg/70 underline-offset-2">
        {CREDIT_TEL}
      </a>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const settings = useLiveQuery(() => db.settings.get("singleton")) ?? DEFAULT_SETTINGS;
  const [photo, setPhoto] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    void blobUrl(settings.photoBlobId).then((u) => {
      if (alive) setPhoto(u);
    });
    return () => {
      alive = false;
    };
  }, [settings.photoBlobId]);

  return (
    <div className="min-h-screen bg-bg text-ink">
      <CreditBanner place="top" />
      <div className="mx-auto flex max-w-[1400px] gap-0 pt-8 pb-28 md:gap-6 md:px-6 md:pt-10 md:pb-12">
        <aside className="sticky top-8 hidden h-[calc(100vh-5.5rem)] w-56 shrink-0 flex-col py-2 md:flex">
          <div className="px-3 pb-4">
            <Link to="/" className="block">
              <p className="font-display text-2xl tracking-tight">OMG</p>
              <p className="text-xs text-muted">Optical Media Grader</p>
            </Link>
          </div>
          <Link to="/profile" className="mb-4 flex items-center gap-3 px-3">
            <span className="size-10 overflow-hidden rounded-full border border-line bg-accent-soft">
              {photo ? (
                <img src={photo} alt="" className="size-full object-cover" />
              ) : (
                <span className="flex size-full items-center justify-center text-xs font-medium text-accent">
                  {(settings.teacherName || "T").slice(0, 1)}
                </span>
              )}
            </span>
            <span className="min-w-0">
              <span className="block truncate text-sm font-medium">{settings.teacherName || "Teacher"}</span>
              <span className="block truncate text-xs text-muted">{settings.schoolName}</span>
            </span>
          </Link>
          <nav className="flex flex-1 flex-col gap-1">
            {NAV.map((item) => {
              const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex items-center gap-2 rounded-[var(--radius-md)] px-3 py-2 text-sm",
                    active ? "bg-accent text-accent-fg" : "text-muted hover:bg-accent-soft hover:text-accent",
                  )}
                >
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="mt-auto flex items-center justify-between px-2 pb-2">
            <span className="text-xs text-muted">Appearance</span>
            <ThemeToggle />
          </div>
        </aside>
        <main className="min-h-[calc(100vh-5.5rem)] flex-1 px-4 pt-5 pb-6 md:rounded-[var(--radius-xl)] md:border md:border-line md:bg-bg-elevated md:px-8 md:py-8">
          <div className="mb-4 flex items-center justify-between gap-3">
            <BackButton />
            <div className="ml-auto md:hidden">
              <ThemeToggle />
            </div>
          </div>
          {children}
        </main>
      </div>
      <nav className="fixed inset-x-0 bottom-8 z-40 flex justify-around border-t border-line bg-surface/95 px-1 py-2 backdrop-blur md:hidden">
        {NAV.slice(0, 5).map((item) => {
          const Icon = item.icon;
          const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex min-w-12 flex-col items-center gap-1 px-2 py-1 text-[10px]",
                active ? "text-accent" : "text-muted",
              )}
            >
              <Icon className="size-5" />
              {item.label.split(" ")[0]}
            </Link>
          );
        })}
      </nav>
      <CreditBanner place="bottom" />
    </div>
  );
}
