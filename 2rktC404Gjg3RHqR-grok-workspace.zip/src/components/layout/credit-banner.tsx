import { cn } from "@/lib/utils";

export const CREDIT = "Developed by J.D.C. of SPCIHS, to support - 09197677274";
export const CREDIT_TEL = "09197677274";

export function CreditBanner({ place }: { place: "top" | "bottom" }) {
  return (
    <div
      className={cn(
        "credit-banner fixed inset-x-0 z-[70] bg-accent px-3 py-1.5 text-center text-[11px] leading-snug font-medium tracking-wide text-accent-fg",
        place === "top" ? "top-0" : "bottom-0",
      )}
      role={place === "bottom" ? "contentinfo" : "banner"}
      aria-label={CREDIT}
    >
      Developed by J.D.C. of SPCIHS, to support -{" "}
      <a href={`tel:${CREDIT_TEL}`} className="underline decoration-accent-fg/70 underline-offset-2">
        {CREDIT_TEL}
      </a>
    </div>
  );
}
