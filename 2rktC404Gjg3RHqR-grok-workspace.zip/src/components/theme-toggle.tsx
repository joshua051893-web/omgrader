import { Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/theme-provider";
import { cn } from "@/lib/utils";
import type { ThemeMode } from "@/lib/theme";

export function ThemeToggle({ className }: { className?: string }) {
  const { mode, resolved, setMode } = useTheme();
  const next: ThemeMode = resolved === "dark" ? "light" : "dark";
  return (
    <Button
      type="button"
      variant="ghost"
      size="icon"
      className={cn("text-muted", className)}
      aria-label={resolved === "dark" ? "Switch to light mode" : "Switch to dark mode"}
      title={mode === "system" ? `Theme: system (${resolved})` : `Theme: ${mode}`}
      onClick={() => setMode(next)}
    >
      {resolved === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
    </Button>
  );
}

export function ThemePicker() {
  const { mode, setMode } = useTheme();
  const options: Array<{ value: ThemeMode; label: string }> = [
    { value: "light", label: "Light" },
    { value: "dark", label: "Dark" },
    { value: "system", label: "System" },
  ];
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((opt) => (
        <Button key={opt.value} type="button" size="sm" variant={mode === opt.value ? "default" : "outline"} onClick={() => setMode(opt.value)}>
          {opt.label}
        </Button>
      ))}
    </div>
  );
}
