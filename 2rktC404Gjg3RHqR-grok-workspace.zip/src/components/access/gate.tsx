import type { ReactNode } from "react";
import { Navigate, useRouterState } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/app-shell";

export function AccessGate({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  if (pathname === "/login" || pathname === "/register") return <Navigate to="/" />;
  return <AppShell>{children}</AppShell>;
}
