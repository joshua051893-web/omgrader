import { useEffect, useMemo, useRef, useState, type KeyboardEvent as Kbd, type PointerEvent } from "react";
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  Bold,
  Columns3,
  Download,
  Minus,
  Percent,
  Plus,
  Printer,
  Rows3,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import type { CellFormat, GradeWorkbook, WorkbookSheet } from "@/lib/types";
import { cellKey, colLetter } from "@/lib/spreadsheet/addr";
import { evaluateSheet, formatValue } from "@/lib/spreadsheet/formula";
import { downloadWorkbookXlsx } from "@/lib/spreadsheet/xlsx";
import {
  clearRange,
  deleteCols,
  deleteRows,
  fillRange,
  insertCols,
  insertRows,
  isPointing,
  insertRef,
  pasteTSV,
  rangeTSV,
  setCellValue,
} from "@/lib/spreadsheet/ops";
import { cn, uid } from "@/lib/utils";

const FILLS = [
  { id: "", label: "None" },
  { id: "accent-soft", label: "Green" },
  { id: "warn", label: "Amber" },
  { id: "ok", label: "Mint" },
  { id: "danger", label: "Rose" },
];

function fillClass(bg?: string) {
  if (bg === "accent-soft") return "bg-accent-soft";
  if (bg === "warn") return "bg-[#f3e6cf] dark:bg-[#3a2e16]";
  if (bg === "ok") return "bg-accent-soft/70";
  if (bg === "danger") return "bg-[#f3d6d2] dark:bg-[#3a2220]";
  return "bg-surface";
}

interface Props {
  book: GradeWorkbook;
  onChange: (book: GradeWorkbook) => void;
}

export function SpreadsheetEditor({ book, onChange }: Props) {
  const sheet = book.sheets.find((s) => s.id === book.activeSheetId) ?? book.sheets[0];
  if (!sheet) return null;
  return <SheetView key={sheet.id} book={book} sheet={sheet} onChange={onChange} />;
}

function SheetView({ book, sheet, onChange }: Props & { sheet: WorkbookSheet }) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLInputElement>(null);
  const [sel, setSel] = useState({ c: 0, r: 0 });
  const [end, setEnd] = useState({ c: 0, r: 0 });
  const [origin, setOrigin] = useState({ c: 0, r: 0 });
  const [edit, setEdit] = useState<string | null>(null);
  const [dragging, setDragging] = useState<"sel" | "fill" | null>(null);
  const values = useMemo(() => evaluateSheet(sheet.cells, sheet.rows, sheet.cols), [sheet.cells, sheet.rows, sheet.cols]);
  const active = sheet.cells[cellKey(origin.c, origin.r)];
  const live = edit ?? active?.v ?? "";

  useEffect(() => {
    wrapRef.current?.focus();
  }, [sheet.id]);

  function patch(next: WorkbookSheet) {
    onChange({
      ...book,
      sheets: book.sheets.map((s) => (s.id === next.id ? next : s)),
      activeSheetId: next.id,
      updatedAt: new Date().toISOString(),
    });
  }

  function commit(raw: string | null = edit) {
    if (raw == null) return;
    patch(setCellValue(sheet, origin.c, origin.r, {}, raw));
    setEdit(null);
    setSel(origin);
    setEnd(origin);
    wrapRef.current?.focus();
  }

  function startEdit(seed?: string, at = sel) {
    setOrigin(at);
    setSel(at);
    setEnd(at);
    setEdit(seed ?? sheet.cells[cellKey(at.c, at.r)]?.v ?? "");
    requestAnimationFrame(() => barRef.current?.focus());
  }

  function inRange(c: number, r: number) {
    return c >= Math.min(sel.c, end.c) && c <= Math.max(sel.c, end.c) && r >= Math.min(sel.r, end.r) && r <= Math.max(sel.r, end.r);
  }

  function applyPoint(c: number, r: number, rangeEnd?: { c: number; r: number }) {
    if (edit == null || !isPointing(edit)) return false;
    const a = cellKey(c, r);
    const b = rangeEnd ? cellKey(rangeEnd.c, rangeEnd.r) : a;
    const ref = a === b ? a : `${a}:${b}`;
    setEdit(insertRef(edit, ref));
    return true;
  }

  function onCellPointer(c: number, r: number, e: PointerEvent<HTMLTableCellElement>) {
    if (edit != null && isPointing(edit)) {
      e.preventDefault();
      applyPoint(c, r);
      setSel({ c, r });
      setEnd({ c, r });
      setDragging("sel");
      barRef.current?.focus();
      return;
    }
    if (edit != null) commit();
    const next = { c, r };
    setOrigin(next);
    setSel(next);
    setEnd(next);
    setDragging("sel");
    wrapRef.current?.focus();
  }

  function onKey(e: Kbd<HTMLDivElement>) {
    const ctrl = e.ctrlKey || e.metaKey;
    if (edit != null && document.activeElement === barRef.current) {
      if (e.key === "Enter") {
        e.preventDefault();
        commit();
        setSel({ c: origin.c, r: Math.min(sheet.rows - 1, origin.r + 1) });
        setEnd({ c: origin.c, r: Math.min(sheet.rows - 1, origin.r + 1) });
        setOrigin({ c: origin.c, r: Math.min(sheet.rows - 1, origin.r + 1) });
      }
      if (e.key === "Escape") {
        e.preventDefault();
        setEdit(null);
        wrapRef.current?.focus();
      }
      if (e.key === "Tab") {
        e.preventDefault();
        commit();
        const c = Math.min(sheet.cols - 1, origin.c + (e.shiftKey ? -1 : 1));
        setSel({ c, r: origin.r });
        setEnd({ c, r: origin.r });
        setOrigin({ c, r: origin.r });
      }
      return;
    }
    if (edit != null) return;
    if (e.key === "Enter" || e.key === "F2") {
      e.preventDefault();
      startEdit();
      return;
    }
    if (e.key === "Delete" || e.key === "Backspace") {
      e.preventDefault();
      patch(clearRange(sheet, sel.c, sel.r, end.c, end.r));
      return;
    }
    if (ctrl && e.key.toLowerCase() === "c") {
      e.preventDefault();
      void navigator.clipboard.writeText(rangeTSV(sheet, sel.c, sel.r, end.c, end.r, values));
      return;
    }
    if (ctrl && e.key.toLowerCase() === "x") {
      e.preventDefault();
      void navigator.clipboard.writeText(rangeTSV(sheet, sel.c, sel.r, end.c, end.r, values));
      patch(clearRange(sheet, sel.c, sel.r, end.c, end.r));
      return;
    }
    if (ctrl && e.key.toLowerCase() === "v") {
      e.preventDefault();
      void navigator.clipboard.readText().then((t) => patch(pasteTSV(sheet, sel.c, sel.r, t)));
      return;
    }
    if (ctrl && e.key.toLowerCase() === "b") {
      e.preventDefault();
      patch(setCellValue(sheet, origin.c, origin.r, { bold: !active?.bold }));
      return;
    }
    if (ctrl && e.key.toLowerCase() === "d") {
      e.preventDefault();
      patch(fillRange(sheet, Math.min(sel.c, end.c), Math.min(sel.r, end.r), Math.max(sel.c, end.c), Math.max(sel.r, end.r)));
      return;
    }
    const move = (dc: number, dr: number) => {
      const c = Math.max(0, Math.min(sheet.cols - 1, (e.shiftKey ? end.c : sel.c) + dc));
      const r = Math.max(0, Math.min(sheet.rows - 1, (e.shiftKey ? end.r : sel.r) + dr));
      if (e.shiftKey) setEnd({ c, r });
      else {
        setSel({ c, r });
        setEnd({ c, r });
        setOrigin({ c, r });
      }
    };
    if (e.key === "ArrowRight") {
      e.preventDefault();
      move(1, 0);
    }
    if (e.key === "ArrowLeft") {
      e.preventDefault();
      move(-1, 0);
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      move(0, 1);
    }
    if (e.key === "ArrowUp") {
      e.preventDefault();
      move(0, -1);
    }
    if (e.key === "Tab") {
      e.preventDefault();
      move(e.shiftKey ? -1 : 1, 0);
    }
    if (e.key.length === 1 && !ctrl) {
      startEdit(e.key);
    }
  }

  function onPointerMove(c: number, r: number) {
    if (!dragging) return;
    if (edit != null && isPointing(edit)) {
      applyPoint(sel.c, sel.r, { c, r });
      setEnd({ c, r });
      return;
    }
    if (dragging === "fill") {
      setEnd({ c, r });
      return;
    }
    setEnd({ c, r });
  }

  function onPointerUp() {
    if (dragging === "fill") patch(fillRange(sheet, origin.c, origin.r, end.c, end.r));
    setDragging(null);
  }

  const fmtBtn = (fmt: CellFormat, label: string) => (
    <Button size="sm" variant={active?.fmt === fmt ? "default" : "outline"} onClick={() => patch(setCellValue(sheet, origin.c, origin.r, { fmt }))}>
      {label}
    </Button>
  );

  return (
    <div
      ref={wrapRef}
      className="flex min-h-[70vh] flex-col outline-none"
      tabIndex={0}
      onKeyDown={onKey}
      onPointerUp={onPointerUp}
    >
      <div className="no-print mb-2 flex flex-wrap items-center gap-1">
        <Button size="sm" variant={active?.bold ? "default" : "outline"} onClick={() => patch(setCellValue(sheet, origin.c, origin.r, { bold: !active?.bold }))}>
          <Bold />
        </Button>
        <Button size="sm" variant="outline" onClick={() => patch(setCellValue(sheet, origin.c, origin.r, { align: "left" }))}>
          <AlignLeft />
        </Button>
        <Button size="sm" variant="outline" onClick={() => patch(setCellValue(sheet, origin.c, origin.r, { align: "center" }))}>
          <AlignCenter />
        </Button>
        <Button size="sm" variant="outline" onClick={() => patch(setCellValue(sheet, origin.c, origin.r, { align: "right" }))}>
          <AlignRight />
        </Button>
        {fmtBtn("general", "General")}
        {fmtBtn("number", "0.00")}
        <Button size="sm" variant={active?.fmt === "percent" ? "default" : "outline"} onClick={() => patch(setCellValue(sheet, origin.c, origin.r, { fmt: "percent" }))}>
          <Percent />
        </Button>
        {FILLS.map((f) => (
          <button
            key={f.id || "none"}
            type="button"
            title={f.label}
            className={cn("size-7 rounded-sm border border-line", fillClass(f.id), active?.bg === f.id && "ring-2 ring-accent")}
            onClick={() => patch(setCellValue(sheet, origin.c, origin.r, { bg: f.id }))}
          />
        ))}
        <span className="mx-1 h-5 w-px bg-line" />
        <Button size="sm" variant="outline" title="Insert column left" onClick={() => patch(insertCols(sheet, sel.c, 1))}>
          <Columns3 /> Insert col
        </Button>
        <Button size="sm" variant="outline" title="Delete column" onClick={() => patch(deleteCols(sheet, sel.c, 1))}>
          <Minus /> Col
        </Button>
        <Button size="sm" variant="outline" title="Insert row above" onClick={() => patch(insertRows(sheet, sel.r, 1))}>
          <Rows3 /> Insert row
        </Button>
        <Button size="sm" variant="outline" onClick={() => patch(deleteRows(sheet, sel.r, 1))}>
          <Minus /> Row
        </Button>
        <Button size="sm" variant="outline" onClick={() => patch({ ...sheet, cols: sheet.cols + 3 })}>
          <Plus /> Columns
        </Button>
        <Button size="sm" variant="outline" onClick={() => patch({ ...sheet, rows: sheet.rows + 10 })}>
          <Plus /> Rows
        </Button>
        <Button
          size="sm"
          variant="outline"
          title="Fill down (Ctrl+D)"
          onClick={() => patch(fillRange(sheet, Math.min(sel.c, end.c), Math.min(sel.r, end.r), Math.max(sel.c, end.c), Math.max(sel.r, end.r)))}
        >
          Fill
        </Button>
        <span className="mx-1 h-5 w-px bg-line" />
        <Button size="sm" variant="outline" onClick={() => downloadWorkbookXlsx(book)}>
          <Download /> Excel
        </Button>
        <Button size="sm" variant="outline" onClick={() => window.print()}>
          <Printer /> Print
        </Button>
      </div>

      <div className="no-print mb-2 flex items-center gap-2">
        <span className="w-16 shrink-0 font-mono text-xs text-muted">
          {colLetter(origin.c)}
          {origin.r + 1}
        </span>
        <span className="text-muted">=</span>
        <input
          ref={barRef}
          className="h-9 flex-1 rounded-[var(--radius-sm)] border border-line bg-surface px-3 font-mono text-sm"
          value={live}
          onChange={(e) => {
            const v = e.target.value;
            setEdit(v);
            if (edit == null) setOrigin(sel);
          }}
          onFocus={() => {
            if (edit == null) startEdit(active?.v ?? "", origin);
          }}
          placeholder="Type = then click cells to build a formula, e.g. =AVERAGE(E2:E13)"
        />
        {edit != null && (
          <Button size="sm" onClick={() => commit()}>
            Enter
          </Button>
        )}
      </div>
      {edit?.startsWith("=") && (
        <p className="no-print mb-2 text-[11px] text-muted">
          Click other cells to insert references. Drag for a range. Enter to save. Escape to cancel.
        </p>
      )}

      <div className="sheet-print max-h-[62vh] flex-1 overflow-auto rounded-[var(--radius-md)] border border-line">
        <table className="border-collapse text-xs">
          <thead>
            <tr>
              <th className="sticky top-0 left-0 z-20 w-10 border border-line bg-bg-elevated" />
              {Array.from({ length: sheet.cols }, (_, c) => (
                <th
                  key={c}
                  className={cn(
                    "sticky top-0 z-10 border border-line bg-bg-elevated px-1 py-1 font-medium text-muted",
                    c >= Math.min(sel.c, end.c) && c <= Math.max(sel.c, end.c) && "bg-accent-soft text-ink",
                  )}
                  style={{ minWidth: sheet.colWidths[c] ?? 88, width: sheet.colWidths[c] ?? 88 }}
                  onClick={() => {
                    setSel({ c, r: 0 });
                    setEnd({ c, r: sheet.rows - 1 });
                    setOrigin({ c, r: 0 });
                  }}
                >
                  {colLetter(c)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: sheet.rows }, (_, r) => (
              <tr key={r}>
                <th
                  className={cn(
                    "sticky left-0 z-10 border border-line bg-bg-elevated px-1 text-muted",
                    r >= Math.min(sel.r, end.r) && r <= Math.max(sel.r, end.r) && "bg-accent-soft text-ink",
                  )}
                  onClick={() => {
                    setSel({ c: 0, r });
                    setEnd({ c: sheet.cols - 1, r });
                    setOrigin({ c: 0, r });
                  }}
                >
                  {r + 1}
                </th>
                {Array.from({ length: sheet.cols }, (_, c) => {
                  const key = cellKey(c, r);
                  const cell = sheet.cells[key];
                  const selected = inRange(c, r);
                  const isOrigin = origin.c === c && origin.r === r;
                  const display = formatValue(values[key] ?? null, cell?.fmt);
                  return (
                    <td
                      key={c}
                      className={cn(
                        "relative h-7 max-w-[240px] overflow-visible border border-line px-1 align-middle",
                        fillClass(cell?.bg),
                        selected && "bg-accent-soft/40",
                        isOrigin && "ring-2 ring-accent ring-inset",
                        cell?.bold && "font-semibold",
                        cell?.align === "center" && "text-center",
                        cell?.align === "right" && "text-right",
                        cell?.v?.startsWith("=") && !isOrigin && "text-ink",
                      )}
                      onPointerDown={(e) => onCellPointer(c, r, e)}
                      onPointerEnter={() => onPointerMove(c, r)}
                      onDoubleClick={() => startEdit(cell?.v ?? "", { c, r })}
                    >
                      {isOrigin && edit != null ? (
                        <span className="font-mono text-accent">{edit}</span>
                      ) : (
                        display
                      )}
                      {isOrigin && edit == null && (
                        <span
                          className="absolute right-0 bottom-0 z-10 size-2 cursor-crosshair bg-accent"
                          onPointerDown={(e) => {
                            e.stopPropagation();
                            setDragging("fill");
                            setOrigin({ c, r });
                            setSel({ c, r });
                            setEnd({ c, r });
                          }}
                        />
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="no-print mt-2 flex flex-wrap items-center gap-1">
        {book.sheets.map((s) => (
          <button
            key={s.id}
            type="button"
            className={cn(
              "rounded-t-[var(--radius-sm)] border border-b-0 border-line px-3 py-1.5 text-xs",
              s.id === sheet.id ? "bg-surface font-medium text-ink" : "bg-bg text-muted hover:text-ink",
            )}
            onClick={() => onChange({ ...book, activeSheetId: s.id })}
            onDoubleClick={() => {
              const name = prompt("Rename sheet", s.name);
              if (!name) return;
              onChange({ ...book, sheets: book.sheets.map((x) => (x.id === s.id ? { ...x, name } : x)) });
            }}
          >
            {s.name}
          </button>
        ))}
        <Button
          size="sm"
          variant="ghost"
          onClick={() => {
            const blank: WorkbookSheet = {
              id: uid("sht"),
              name: `Sheet ${book.sheets.length + 1}`,
              kind: "custom",
              rows: 40,
              cols: 16,
              cells: {},
              colWidths: {},
              autoCols: 0,
              autoRows: 0,
            };
            onChange({ ...book, sheets: [...book.sheets, blank], activeSheetId: blank.id });
          }}
        >
          <Plus className="size-3.5" /> Sheet
        </Button>
        {sheet.kind === "custom" && (
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              if (!confirm("Delete this sheet?")) return;
              const sheets = book.sheets.filter((s) => s.id !== sheet.id);
              onChange({ ...book, sheets, activeSheetId: sheets[0]?.id ?? "" });
            }}
          >
            <Trash2 className="size-3.5" />
          </Button>
        )}
      </div>
      <p className="no-print mt-2 text-[11px] text-muted">
        {"=SUM(A1:A10) · AVERAGE · IF(A1>=75,\"Pass\",\"Fail\") · COUNTIF · VLOOKUP · INDEX · MATCH · ROUND · MIN MAX. Click a cell, type =, then click other cells. Drag the square to fill. Ctrl+D fill, Ctrl+C / Ctrl+V copy paste."}
      </p>
    </div>
  );
}
