import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { applyTheme, readTheme, resolveTheme, type ThemeMode } from "@/lib/theme";
import { saveSettings } from "@/lib/db/repo";

interface ThemeCtx {
  mode: ThemeMode;
  resolved: "light" | "dark";
  setMode: (mode: ThemeMode) => void;
}

const Ctx = createContext<ThemeCtx>({
  mode: "system",
  resolved: "light",
  setMode: () => {},
});

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<ThemeMode>(() => readTheme());
  const [resolved, setResolved] = useState<"light" | "dark">(() => resolveTheme(readTheme()));

  useEffect(() => {
    applyTheme(mode);
    setResolved(resolveTheme(mode));
    void saveSettings({ theme: mode }).catch(() => undefined);
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => {
      applyTheme(mode);
      setResolved(resolveTheme(mode));
    };
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, [mode]);

  const value = useMemo(
    () => ({
      mode,
      resolved,
      setMode: (next: ThemeMode) => {
        setModeState(next);
        applyTheme(next);
        setResolved(resolveTheme(next));
      },
    }),
    [mode, resolved],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useTheme() {
  return useContext(Ctx);
}
