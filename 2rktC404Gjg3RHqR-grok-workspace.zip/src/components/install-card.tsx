import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Card, CardDesc, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { canPromptInstall, initInstallPrompt, isStandalone, promptInstall, subscribeInstall } from "@/lib/pwa/install";

export function InstallCard() {
  const [promptReady, setPromptReady] = useState(false);
  const [standalone, setStandalone] = useState(false);

  useEffect(() => {
    initInstallPrompt();
    setPromptReady(canPromptInstall());
    setStandalone(isStandalone());
    return subscribeInstall(() => {
      setPromptReady(canPromptInstall());
      setStandalone(isStandalone());
    });
  }, []);

  return (
    <Card className="space-y-3">
      <CardTitle>Keep OMG on this device</CardTitle>
      <CardDesc>
        Student records, answer keys, scans, and marked papers already live in this browser. Install the app so it opens like a normal program and keeps working when you are offline.
      </CardDesc>
      {standalone ? (
        <p className="text-sm text-ok">OMG is installed on this device.</p>
      ) : (
        <div className="flex flex-wrap gap-2">
          {promptReady && (
            <Button
              onClick={async () => {
                const ok = await promptInstall();
                toast.success(ok ? "Installed on this device." : "Install was cancelled.");
              }}
            >
              Install app
            </Button>
          )}
          <Button variant="outline" onClick={() => window.open("/?install=1", "_blank")}>
            Show install steps
          </Button>
        </div>
      )}
      <ol className="list-decimal space-y-1 pl-5 text-sm text-muted">
        <li>
          <strong className="text-ink">Phone or tablet (iPhone/iPad):</strong> open OMG in Safari, tap Share, then Add to Home Screen.
        </li>
        <li>
          <strong className="text-ink">Android:</strong> open in Chrome, tap the menu, then Install app or Add to Home screen.
        </li>
        <li>
          <strong className="text-ink">Windows or Mac:</strong> open in Chrome or Edge, then click the install icon in the address bar, or use Install app above.
        </li>
        <li>
          After install, launch OMG from your home screen or Start menu. Your data stays on this device. Use Backup & restore if you move to another computer.
        </li>
      </ol>
    </Card>
  );
}
