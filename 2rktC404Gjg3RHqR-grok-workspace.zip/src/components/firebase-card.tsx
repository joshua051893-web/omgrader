import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardDesc, CardTitle } from "@/components/ui/card";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { saveSettings } from "@/lib/db/repo";
import type { AppSettings } from "@/lib/types";
import { FIRESTORE_RULES, STORAGE_RULES, parseFirebaseConfigPaste } from "@/lib/firebase/config";
import { cloudSignIn, cloudSignOut, syncWithFirebase, testFirebaseConnection } from "@/lib/firebase/sync";
import { downloadBlob, formatDate } from "@/lib/utils";

export function FirebaseCard({ settings }: { settings: AppSettings }) {
  const [paste, setPaste] = useState("");
  const [email, setEmail] = useState(settings.firebaseEmail);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const connected = Boolean(settings.firebaseProjectId && settings.firebaseApiKey);

  async function saveConfig() {
    try {
      const cfg = parseFirebaseConfigPaste(paste);
      await saveSettings({
        firebaseApiKey: cfg.apiKey,
        firebaseAuthDomain: cfg.authDomain,
        firebaseProjectId: cfg.projectId,
        firebaseStorageBucket: cfg.storageBucket,
        firebaseMessagingSenderId: cfg.messagingSenderId,
        firebaseAppId: cfg.appId,
      });
      await testFirebaseConnection(cfg);
      setPaste("");
      toast.success(`Firebase project ${cfg.projectId} saved on this device.`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not read that config.");
    }
  }

  async function signIn(create: boolean) {
    setBusy(true);
    try {
      await cloudSignIn(email, password, create);
      toast.success(create ? "Firebase account created and signed in." : "Signed in to Firebase.");
      setPassword("");
    } catch (e) {
      toast.error(prettyFirebase(e));
    } finally {
      setBusy(false);
    }
  }

  async function sync() {
    setBusy(true);
    try {
      const r = await syncWithFirebase();
      toast.success(`Synced. Uploaded ${r.pushed}, downloaded ${r.pulled}, files ${r.files}.`);
    } catch (e) {
      toast.error(prettyFirebase(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="space-y-4">
      <div>
        <CardTitle>Firebase cloud sync</CardTitle>
        <CardDesc>
          OMG still stores everything on this device. Scanned paper images never leave this browser. Sync only copies
          roster, tests, answer keys, and scores to your Firebase project.
        </CardDesc>
      </div>

      <ol className="list-decimal space-y-2 pl-5 text-sm text-muted">
        <li>
          Open{" "}
          <a className="text-accent underline" href="https://console.firebase.google.com/" target="_blank" rel="noreferrer">
            Firebase Console
          </a>{" "}
          and create a project (or pick one you already have).
        </li>
        <li>Add a <strong className="text-ink">Web</strong> app. Copy the <code className="text-ink">firebaseConfig</code> object.</li>
        <li>
          Enable <strong className="text-ink">Authentication → Email/Password</strong> and{" "}
          <strong className="text-ink">Cloud Firestore</strong>. Storage is not required — photos stay on this device.
        </li>
        <li>Paste the config here, sign in with a Firebase email, then tap Sync now.</li>
      </ol>

      <div>
        <Label>Paste firebaseConfig</Label>
        <Textarea
          className="mt-1 font-mono text-xs"
          rows={7}
          placeholder={'const firebaseConfig = {\n  apiKey: "...",\n  projectId: "...",\n  appId: "...",\n};'}
          value={paste}
          onChange={(e) => setPaste(e.target.value)}
        />
        <Button className="mt-2" variant="outline" onClick={() => void saveConfig()}>
          Save Firebase config
        </Button>
        {connected && (
          <p className="mt-2 text-xs text-muted">
            Project <span className="font-mono text-ink">{settings.firebaseProjectId}</span>
            {settings.lastCloudSyncAt ? ` · last sync ${formatDate(settings.lastCloudSyncAt)}` : " · not synced yet"}
          </p>
        )}
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <Label>Firebase email</Label>
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" />
        </div>
        <div>
          <Label>Firebase password</Label>
          <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button disabled={busy || !connected} onClick={() => void signIn(false)}>
          Sign in to Firebase
        </Button>
        <Button disabled={busy || !connected} variant="outline" onClick={() => void signIn(true)}>
          Create Firebase user
        </Button>
        <Button disabled={busy || !connected} variant="ghost" onClick={() => void cloudSignOut().then(() => toast.message("Signed out of Firebase."))}>
          Sign out of cloud
        </Button>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button disabled={busy || !connected} onClick={() => void sync()}>
          {busy ? "Syncing…" : "Sync now"}
        </Button>
        <Button
          variant="outline"
          onClick={() => downloadBlob(new Blob([FIRESTORE_RULES], { type: "text/plain" }), "firestore.rules")}
        >
          Download Firestore rules
        </Button>
        <Button
          variant="outline"
          onClick={() => downloadBlob(new Blob([STORAGE_RULES], { type: "text/plain" }), "storage.rules")}
        >
          Download Storage rules
        </Button>
      </div>
      <p className="text-xs text-muted">
        In Firestore and Storage, replace the default rules with the downloaded files. They allow only signed-in users to
        read and write <span className="font-mono">schools/…</span>. Do not use open test rules on a real class list.
      </p>
    </Card>
  );
}

function prettyFirebase(e: unknown) {
  const msg = e instanceof Error ? e.message : "Firebase error.";
  if (msg.includes("auth/invalid-credential") || msg.includes("auth/wrong-password")) return "Incorrect Firebase email or password.";
  if (msg.includes("auth/email-already-in-use")) return "That Firebase email already exists. Sign in instead.";
  if (msg.includes("auth/user-not-found")) return "No Firebase user with that email. Create one first.";
  if (msg.includes("auth/weak-password")) return "Firebase password must be at least 6 characters.";
  if (msg.includes("auth/operation-not-allowed")) return "Enable Email/Password in Firebase Authentication first.";
  if (msg.includes("permission-denied")) return "Firestore or Storage denied access. Sign in and paste the downloaded rules.";
  return msg;
}
