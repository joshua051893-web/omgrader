import { type ReactNode, useEffect, useState } from "react";
import { ensureSeeded } from "@/lib/db/seed";

export function BootGate({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    ensureSeeded()
      .then(() => setReady(true))
      .catch((e) => setError(e instanceof Error ? e.message : "Could not open the local database."));
  }, []);
  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center p-8 text-center">
        <p className="max-w-md text-sm text-muted">{error}</p>
      </div>
    );
  }
  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p className="text-sm text-muted">Opening local records…</p>
      </div>
    );
  }
  return <>{children}</>;
}
