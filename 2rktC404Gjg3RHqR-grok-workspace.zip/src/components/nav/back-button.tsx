import { ArrowLeft } from "lucide-react";
import { useRouter, useRouterState } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { parentPath } from "@/lib/nav/back";

export function BackButton() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const router = useRouter();
  if (pathname === "/") return null;
  const parent = parentPath(pathname);

  return (
    <Button
      type="button"
      variant="outline"
      size="sm"
      className="no-print"
      onClick={() => {
        let fromApp = false;
        try {
          fromApp = Boolean(document.referrer) && new URL(document.referrer).origin === window.location.origin;
        } catch {
          fromApp = false;
        }
        if (fromApp && window.history.length > 1) {
          router.history.back();
          return;
        }
        router.history.push(parent);
      }}
    >
      <ArrowLeft />
      Back
    </Button>
  );
}
