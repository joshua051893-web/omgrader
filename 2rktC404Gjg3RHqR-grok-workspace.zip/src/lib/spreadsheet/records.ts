import type { Assessment, GradeWorkbook, ScanResult, SheetCell, Student, WorkbookSheet } from "@/lib/types";
import { cellKey, colLetter } from "@/lib/spreadsheet/addr";
import { padRoll, uid } from "@/lib/utils";

const HEADER_BG = "accent-soft";

function cell(v: string, extra: Partial<SheetCell> = {}): SheetCell {
  return { v, ...extra };
}

function header(v: string): SheetCell {
  return { v, bold: true, bg: HEADER_BG, align: "center" };
}

function mergeExtra(oldSheet: WorkbookSheet | undefined, next: WorkbookSheet): WorkbookSheet {
  if (!oldSheet) return next;
  const cells = { ...next.cells };
  for (const [k, c] of Object.entries(oldSheet.cells)) {
    const m = /^([A-Z]+)([0-9]+)$/.exec(k);
    if (!m) continue;
    let col = 0;
    for (const ch of m[1]!) col = col * 26 + (ch.charCodeAt(0) - 64);
    col -= 1;
    const row = Number(m[2]) - 1;
    if (col >= next.autoCols || row >= next.autoRows) cells[k] = c;
  }
  return {
    ...next,
    id: oldSheet.id,
    name: oldSheet.name,
    cells,
    colWidths: { ...next.colWidths, ...oldSheet.colWidths },
    cols: Math.max(next.cols, oldSheet.cols),
    rows: Math.max(next.rows, oldSheet.rows),
  };
}

function writeGrid(headers: string[], kind: WorkbookSheet["kind"], name: string, subject?: string, nDataRows = 0): WorkbookSheet {
  const cols = Math.max(headers.length + 4, 12);
  const rows = Math.max(nDataRows + 12, 40);
  const cells: Record<string, SheetCell> = {};
  headers.forEach((h, c) => {
    cells[cellKey(c, 0)] = header(h);
  });
  const colWidths: Record<number, number> = {};
  headers.forEach((h, i) => {
    colWidths[i] = Math.min(200, Math.max(76, h.length * 8 + 28));
  });
  if (headers[1]?.toLowerCase().includes("student") || headers[1] === "LRN") colWidths[1] = Math.max(colWidths[1] ?? 76, 140);
  if (headers[2] === "Student") colWidths[2] = 168;
  return {
    id: uid("sht"),
    name,
    kind,
    subject,
    rows,
    cols,
    cells,
    colWidths,
    autoCols: headers.length,
    autoRows: nDataRows + 1,
  };
}

function findScan(scans: ScanResult[], student: Student, assessmentId: string): ScanResult | undefined {
  const roll = padRoll(student.rollNumber);
  const matches = scans.filter((s) => {
    if (s.assessmentId !== assessmentId) return false;
    if (s.status === "pending") return false;
    if (s.studentId && s.studentId === student.id) return true;
    return padRoll(s.rollNumber) === roll && roll !== "";
  });
  matches.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return matches[0];
}

export function buildScansSheet(
  students: Student[],
  assessments: Assessment[],
  scans: ScanResult[],
  prev?: WorkbookSheet,
): WorkbookSheet {
  const headers = ["Roll", "Student"];
  for (const a of assessments) headers.push(`${a.name} (${a.subject})`, `${a.name} %`);
  headers.push("Average %", "Remarks");
  const sheet = writeGrid(headers, "scans", "Scanned Tests", undefined, students.length);
  const avgCol = 2 + assessments.length * 2;
  const prevByRoll = new Map<string, number>();
  if (prev) {
    for (let r = 1; r < prev.rows; r++) {
      const roll = prev.cells[cellKey(0, r)]?.v?.trim();
      if (roll && !roll.startsWith("=")) prevByRoll.set(padRoll(roll) || roll, r);
    }
  }
  students.forEach((st, i) => {
    const r = i + 1;
    const excelRow = r + 1;
    sheet.cells[cellKey(0, r)] = cell(st.rollNumber, { align: "center" });
    sheet.cells[cellKey(1, r)] = cell(st.fullName);
    assessments.forEach((a, ai) => {
      const s = findScan(scans, st, a.id);
      sheet.cells[cellKey(2 + ai * 2, r)] = cell(s ? String(s.score) : "", { align: "right", fmt: "number" });
      sheet.cells[cellKey(3 + ai * 2, r)] = cell(s ? String(Math.round(s.percentage * 100) / 100) : "", {
        align: "right",
        fmt: "number",
      });
    });
    const pctRefs = assessments.map((_, ai) => `${colLetter(3 + ai * 2)}${excelRow}`);
    sheet.cells[cellKey(avgCol, r)] = cell(
      pctRefs.length ? `=IF(COUNT(${pctRefs.join(",")})=0,"",ROUND(AVERAGE(${pctRefs.join(",")}),2))` : "",
      { bold: true, align: "right", fmt: "number" },
    );
    const oldR = prevByRoll.get(padRoll(st.rollNumber) || st.rollNumber);
    const oldRemark = oldR != null ? prev!.cells[cellKey(avgCol + 1, oldR)] : undefined;
    sheet.cells[cellKey(avgCol + 1, r)] = cell(oldRemark && !oldRemark.v.startsWith("=") ? oldRemark.v : "");
  });
  sheet.autoCols = headers.length;
  sheet.autoRows = students.length + 1;
  return mergeExtra(prev, sheet);
}

export function buildSubjectSheet(
  subject: string,
  students: Student[],
  assessments: Assessment[],
  scans: ScanResult[],
  prev?: WorkbookSheet,
): WorkbookSheet {
  const list = assessments.filter((a) => a.subject === subject);
  const headers = ["Roll", "Student"];
  for (const a of list) headers.push(a.name, `${a.name} %`);
  headers.push("Average %", "Letter");
  const sheet = writeGrid(headers, "subject", subject, subject, students.length);
  const avgCol = 2 + list.length * 2;
  students.forEach((st, i) => {
    const r = i + 1;
    const excelRow = r + 1;
    sheet.cells[cellKey(0, r)] = cell(st.rollNumber, { align: "center" });
    sheet.cells[cellKey(1, r)] = cell(st.fullName);
    list.forEach((a, ai) => {
      const s = findScan(scans, st, a.id);
      sheet.cells[cellKey(2 + ai * 2, r)] = cell(s ? String(s.score) : "", { align: "right", fmt: "number" });
      sheet.cells[cellKey(3 + ai * 2, r)] = cell(s ? String(Math.round(s.percentage * 100) / 100) : "", {
        align: "right",
        fmt: "number",
      });
    });
    const pctRefs = list.map((_, ai) => `${colLetter(3 + ai * 2)}${excelRow}`);
    const avgRef = `${colLetter(avgCol)}${excelRow}`;
    sheet.cells[cellKey(avgCol, r)] = cell(
      pctRefs.length ? `=IF(COUNT(${pctRefs.join(",")})=0,"",ROUND(AVERAGE(${pctRefs.join(",")}),2))` : "",
      { bold: true, align: "right", fmt: "number" },
    );
    sheet.cells[cellKey(avgCol + 1, r)] = cell(
      pctRefs.length
        ? `=IF(OR(${avgRef}="",${avgRef}=0),"",IF(${avgRef}>=90,"A",IF(${avgRef}>=80,"B",IF(${avgRef}>=75,"C",IF(${avgRef}>=60,"D","F")))))`
        : "",
      { align: "center", bold: true },
    );
  });
  sheet.autoCols = headers.length;
  sheet.autoRows = students.length + 1;
  return mergeExtra(prev, sheet);
}

export function workbookId(gradeLevel: string, section: string) {
  return `wb:${gradeLevel}:${section}`;
}

export function encodeGid(gradeLevel: string, section: string) {
  return `${encodeURIComponent(gradeLevel)}~${encodeURIComponent(section)}`;
}

export function parseGid(gid: string) {
  const [g, s] = gid.split("~");
  return { gradeLevel: decodeURIComponent(g || ""), section: decodeURIComponent(s || "") };
}

export function syncWorkbook(
  existing: GradeWorkbook | undefined,
  gradeLevel: string,
  section: string,
  students: Student[],
  assessments: Assessment[],
  scans: ScanResult[],
): GradeWorkbook {
  const classStudents = students
    .filter((s) => s.gradeLevel === gradeLevel && s.section === section)
    .slice()
    .sort((a, b) => a.rollNumber.localeCompare(b.rollNumber));
  const classAssessments = assessments
    .filter((a) => !a.archived && a.gradeLevel === gradeLevel && a.section === section)
    .slice()
    .sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name));
  const classScans = scans.filter((s) => classAssessments.some((a) => a.id === s.assessmentId));
  const subjects = Array.from(new Set(classAssessments.map((a) => a.subject).filter(Boolean)));

  const prevSheets = existing?.sheets ?? [];
  const scansSheet = buildScansSheet(classStudents, classAssessments, classScans, prevSheets.find((s) => s.kind === "scans"));
  const subjectSheets = subjects.map((sub) =>
    buildSubjectSheet(sub, classStudents, classAssessments, classScans, prevSheets.find((s) => s.kind === "subject" && s.subject === sub)),
  );
  const custom = prevSheets.filter((s) => s.kind === "custom");
  const sheets = [scansSheet, ...subjectSheets, ...custom];
  const t = new Date().toISOString();
  return {
    id: workbookId(gradeLevel, section),
    gradeLevel,
    section,
    name: `Grade ${gradeLevel} – ${section}`,
    sheets,
    activeSheetId:
      existing?.activeSheetId && sheets.some((s) => s.id === existing.activeSheetId) ? existing.activeSheetId : scansSheet.id,
    createdAt: existing?.createdAt ?? t,
    updatedAt: t,
  };
}
