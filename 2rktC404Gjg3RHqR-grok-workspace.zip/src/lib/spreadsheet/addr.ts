export function colLetter(index: number): string {
  let n = index + 1;
  let s = "";
  while (n > 0) {
    const r = (n - 1) % 26;
    s = String.fromCharCode(65 + r) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}

export function colIndex(letter: string): number {
  let n = 0;
  const u = letter.toUpperCase();
  for (let i = 0; i < u.length; i++) n = n * 26 + (u.charCodeAt(i) - 64);
  return n - 1;
}

export function cellKey(col: number, row: number): string {
  return `${colLetter(col)}${row + 1}`;
}

export function parseA1(ref: string): { col: number; row: number } | null {
  const m = /^\$?([A-Za-z]+)\$?([1-9][0-9]*)$/.exec(ref.trim());
  if (!m) return null;
  return { col: colIndex(m[1]!), row: Number(m[2]) - 1 };
}

export function parseRange(a: string, b: string): Array<{ col: number; row: number }> {
  const pa = parseA1(a);
  const pb = parseA1(b);
  if (!pa || !pb) return [];
  const c0 = Math.min(pa.col, pb.col);
  const c1 = Math.max(pa.col, pb.col);
  const r0 = Math.min(pa.row, pb.row);
  const r1 = Math.max(pa.row, pb.row);
  const out: Array<{ col: number; row: number }> = [];
  for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) out.push({ col: c, row: r });
  return out;
}
