import * as XLSX from "xlsx";
import type { GradeWorkbook, WorkbookSheet } from "@/lib/types";
import { cellKey } from "@/lib/spreadsheet/addr";
import { evaluateSheet, formatValue } from "@/lib/spreadsheet/formula";
import { downloadBlob } from "@/lib/utils";

function sheetToSheet(sheet: WorkbookSheet) {
  const values = evaluateSheet(sheet.cells, sheet.rows, sheet.cols);
  const ws: Record<string, unknown> = {};
  let maxC = 0;
  let maxR = 0;
  for (let r = 0; r < sheet.rows; r++) {
    for (let c = 0; c < sheet.cols; c++) {
      const key = cellKey(c, r);
      const raw = sheet.cells[key]?.v ?? "";
      if (!raw && values[key] == null) continue;
      maxC = Math.max(maxC, c);
      maxR = Math.max(maxR, r);
      const addr = XLSX.utils.encode_cell({ c, r });
      if (raw.startsWith("=")) {
        const computed = values[key];
        const cell: { t: string; f: string; v?: string | number } = { t: "n", f: raw.slice(1) };
        if (typeof computed === "number") cell.v = computed;
        else if (typeof computed === "string" && computed !== "") {
          cell.t = "s";
          cell.v = computed;
        } else {
          cell.t = "s";
          cell.v = "";
        }
        ws[addr] = cell;
      } else if (typeof values[key] === "number") {
        ws[addr] = { t: "n", v: values[key] };
      } else {
        ws[addr] = { t: "s", v: formatValue(values[key] ?? raw, sheet.cells[key]?.fmt) };
      }
    }
  }
  ws["!ref"] = XLSX.utils.encode_range({ s: { c: 0, r: 0 }, e: { c: Math.max(maxC, 0), r: Math.max(maxR, 0) } });
  ws["!cols"] = Array.from({ length: sheet.cols }, (_, i) => ({ wpx: sheet.colWidths[i] ?? 88 }));
  return ws;
}

export function downloadWorkbookXlsx(book: GradeWorkbook) {
  const wb = XLSX.utils.book_new();
  for (const sheet of book.sheets) {
    XLSX.utils.book_append_sheet(wb, sheetToSheet(sheet), sheet.name.slice(0, 31) || "Sheet");
  }
  const buf = XLSX.write(wb, { type: "array", bookType: "xlsx" }) as ArrayBuffer;
  downloadBlob(
    new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }),
    `${(book.name ?? `Grade-${book.gradeLevel}-${book.section}`).replace(/\s+/g, "-")}.xlsx`,
  );
}

export function csvForSheet(sheet: WorkbookSheet): string {
  const values = evaluateSheet(sheet.cells, sheet.rows, sheet.cols);
  const lines: string[] = [];
  for (let r = 0; r < sheet.rows; r++) {
    const cells: string[] = [];
    let used = false;
    for (let c = 0; c < sheet.cols; c++) {
      const raw = sheet.cells[cellKey(c, r)];
      const text = formatValue(values[cellKey(c, r)] ?? null, raw?.fmt);
      if (text) used = true;
      cells.push(`"${String(text).replace(/"/g, '""')}"`);
    }
    if (used) lines.push(cells.join(","));
  }
  return lines.join("\n");
}
