import type { SheetCell, WorkbookSheet } from "@/lib/types";
import { cellKey, colIndex, colLetter, parseA1 } from "@/lib/spreadsheet/addr";

const REF = /(^|[^A-Z0-9_])(\$?[A-Z]{1,3}\$?[1-9][0-9]{0,5})/gi;

export function adjustFormula(
  formula: string,
  map: (col: number, row: number, absC: boolean, absR: boolean) => { col: number; row: number } | null,
): string {
  if (!formula.startsWith("=")) return formula;
  return formula.replace(REF, (full, prefix: string, ref: string) => {
    const m = /^(\$?)([A-Z]+)(\$?)([0-9]+)$/i.exec(ref);
    if (!m) return full;
    const ac = m[1] === "$";
    const ar = m[3] === "$";
    const col = colIndex(m[2]!);
    const row = Number(m[4]) - 1;
    const next = map(col, row, ac, ar);
    if (!next) return `${prefix}#REF!`;
    return `${prefix}${ac ? "$" : ""}${colLetter(next.col)}${ar ? "$" : ""}${next.row + 1}`;
  });
}

export function fillFormula(formula: string, dc: number, dr: number): string {
  return adjustFormula(formula, (col, row, absC, absR) => ({
    col: absC ? col : col + dc,
    row: absR ? row : row + dr,
  }));
}

function remapCells(
  cells: Record<string, SheetCell>,
  mapKey: (col: number, row: number) => { col: number; row: number } | null,
  mapFormula: (col: number, row: number) => (c: number, r: number, absC: boolean, absR: boolean) => { col: number; row: number } | null,
): Record<string, SheetCell> {
  const next: Record<string, SheetCell> = {};
  for (const [k, cell] of Object.entries(cells)) {
    const pos = parseA1(k);
    if (!pos) continue;
    const dest = mapKey(pos.col, pos.row);
    if (!dest) continue;
    const v = cell.v.startsWith("=") ? adjustFormula(cell.v, mapFormula(pos.col, pos.row)) : cell.v;
    next[cellKey(dest.col, dest.row)] = { ...cell, v };
  }
  return next;
}

export function insertCols(sheet: WorkbookSheet, at: number, count = 1): WorkbookSheet {
  const cells = remapCells(
    sheet.cells,
    (c, r) => ({ col: c >= at ? c + count : c, row: r }),
    () => (c, r) => ({ col: c >= at ? c + count : c, row: r }),
  );
  const colWidths: Record<number, number> = {};
  for (const [k, w] of Object.entries(sheet.colWidths)) {
    const i = Number(k);
    colWidths[i >= at ? i + count : i] = w;
  }
  return {
    ...sheet,
    cols: sheet.cols + count,
    cells,
    colWidths,
    autoCols: at < sheet.autoCols ? sheet.autoCols + count : sheet.autoCols,
  };
}

export function deleteCols(sheet: WorkbookSheet, at: number, count = 1): WorkbookSheet {
  const cells = remapCells(
    sheet.cells,
    (c, r) => {
      if (c >= at && c < at + count) return null;
      return { col: c >= at + count ? c - count : c, row: r };
    },
    () => (c, r) => {
      if (c >= at && c < at + count) return null;
      return { col: c >= at + count ? c - count : c, row: r };
    },
  );
  const colWidths: Record<number, number> = {};
  for (const [k, w] of Object.entries(sheet.colWidths)) {
    const i = Number(k);
    if (i >= at && i < at + count) continue;
    colWidths[i >= at + count ? i - count : i] = w;
  }
  return {
    ...sheet,
    cols: Math.max(1, sheet.cols - count),
    cells,
    colWidths,
    autoCols: at < sheet.autoCols ? Math.max(0, sheet.autoCols - count) : sheet.autoCols,
  };
}

export function insertRows(sheet: WorkbookSheet, at: number, count = 1): WorkbookSheet {
  const cells = remapCells(
    sheet.cells,
    (c, r) => ({ col: c, row: r >= at ? r + count : r }),
    () => (c, r) => ({ col: c, row: r >= at ? r + count : r }),
  );
  return {
    ...sheet,
    rows: sheet.rows + count,
    cells,
    autoRows: at < sheet.autoRows ? sheet.autoRows + count : sheet.autoRows,
  };
}

export function deleteRows(sheet: WorkbookSheet, at: number, count = 1): WorkbookSheet {
  const cells = remapCells(
    sheet.cells,
    (c, r) => {
      if (r >= at && r < at + count) return null;
      return { col: c, row: r >= at + count ? r - count : r };
    },
    () => (c, r) => {
      if (r >= at && r < at + count) return null;
      return { col: c, row: r >= at + count ? r - count : r };
    },
  );
  return {
    ...sheet,
    rows: Math.max(1, sheet.rows - count),
    cells,
    autoRows: at < sheet.autoRows ? Math.max(0, sheet.autoRows - count) : sheet.autoRows,
  };
}

export function fillRange(sheet: WorkbookSheet, c0: number, r0: number, c1: number, r1: number): WorkbookSheet {
  const src = sheet.cells[cellKey(c0, r0)];
  if (!src) return sheet;
  const cells = { ...sheet.cells };
  const cc0 = Math.min(c0, c1);
  const cc1 = Math.max(c0, c1);
  const rr0 = Math.min(r0, r1);
  const rr1 = Math.max(r0, r1);
  for (let r = rr0; r <= rr1; r++) {
    for (let c = cc0; c <= cc1; c++) {
      if (c === c0 && r === r0) continue;
      const v = src.v.startsWith("=") ? fillFormula(src.v, c - c0, r - r0) : src.v;
      cells[cellKey(c, r)] = { ...src, v };
    }
  }
  return { ...sheet, cells, cols: Math.max(sheet.cols, cc1 + 2), rows: Math.max(sheet.rows, rr1 + 2) };
}

export function setCellValue(sheet: WorkbookSheet, c: number, r: number, patch: Partial<SheetCell> | null, raw?: string): WorkbookSheet {
  const key = cellKey(c, r);
  const cells = { ...sheet.cells };
  if (patch === null) delete cells[key];
  else {
    const cur = cells[key] ?? { v: "" };
    const v = raw == null ? cur.v : raw;
    const next = { ...cur, ...patch, v };
    if (!next.v && !next.bold && !next.bg && !next.fmt) delete cells[key];
    else cells[key] = next;
  }
  return { ...sheet, cells, cols: Math.max(sheet.cols, c + 2), rows: Math.max(sheet.rows, r + 2) };
}

export function clearRange(sheet: WorkbookSheet, c0: number, r0: number, c1: number, r1: number): WorkbookSheet {
  const cells = { ...sheet.cells };
  for (let r = Math.min(r0, r1); r <= Math.max(r0, r1); r++) {
    for (let c = Math.min(c0, c1); c <= Math.max(c0, c1); c++) delete cells[cellKey(c, r)];
  }
  return { ...sheet, cells };
}

export function rangeTSV(sheet: WorkbookSheet, c0: number, r0: number, c1: number, r1: number, values: Record<string, unknown>): string {
  const lines: string[] = [];
  for (let r = Math.min(r0, r1); r <= Math.max(r0, r1); r++) {
    const row: string[] = [];
    for (let c = Math.min(c0, c1); c <= Math.max(c0, c1); c++) {
      const raw = sheet.cells[cellKey(c, r)]?.v ?? "";
      row.push(raw || String(values[cellKey(c, r)] ?? ""));
    }
    lines.push(row.join("\t"));
  }
  return lines.join("\n");
}

export function pasteTSV(sheet: WorkbookSheet, c0: number, r0: number, text: string): WorkbookSheet {
  const cells = { ...sheet.cells };
  const lines = text.replace(/\r/g, "").split("\n");
  let maxC = sheet.cols;
  let maxR = sheet.rows;
  lines.forEach((line, ri) => {
    if (line === "" && ri === lines.length - 1) return;
    line.split("\t").forEach((val, ci) => {
      const c = c0 + ci;
      const r = r0 + ri;
      cells[cellKey(c, r)] = { ...(cells[cellKey(c, r)] ?? { v: "" }), v: val };
      maxC = Math.max(maxC, c + 2);
      maxR = Math.max(maxR, r + 2);
    });
  });
  return { ...sheet, cells, cols: maxC, rows: maxR };
}

export function isPointing(text: string | null): boolean {
  if (!text || !text.startsWith("=")) return false;
  const t = text.replace(/\s+$/, "");
  if (t === "=") return true;
  if (/[=+\-*/,(^&<>:]$/.test(t)) return true;
  return /[A-Z]{1,3}[0-9]{1,6}(:[A-Z]{1,3}[0-9]{1,6})?$/i.test(t);
}

export function insertRef(formula: string, ref: string): string {
  const t = formula.replace(/\s+$/, "");
  if (/[A-Z]{1,3}[0-9]{1,6}(:[A-Z]{1,3}[0-9]{1,6})?$/i.test(t) && !/[=+\-*/,(^&<>:]$/.test(t)) {
    return t.replace(/[A-Z]{1,3}[0-9]{1,6}(:[A-Z]{1,3}[0-9]{1,6})?$/i, ref);
  }
  return t + ref;
}
