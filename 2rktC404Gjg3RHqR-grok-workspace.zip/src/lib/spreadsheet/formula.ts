import { cellKey, parseA1, parseRange } from "@/lib/spreadsheet/addr";

export type CellValue = number | string | boolean | null;
type Getter = (col: number, row: number) => CellValue;
type Arg = CellValue | CellValue[][];

class FormulaError extends Error {
  constructor(readonly code: string) {
    super(code);
  }
}

function num(v: CellValue): number {
  if (v == null || v === "") return 0;
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "boolean") return v ? 1 : 0;
  if (typeof v === "string" && v.trim() !== "" && !Number.isNaN(Number(v))) return Number(v);
  throw new FormulaError("#VALUE!");
}

function truthy(v: CellValue): boolean {
  if (v == null || v === "" || v === false || v === 0) return false;
  if (typeof v === "string" && v.toUpperCase() === "FALSE") return false;
  return true;
}

function flatten(args: Arg[]): CellValue[] {
  const out: CellValue[] = [];
  for (const a of args) {
    if (Array.isArray(a)) for (const row of a) out.push(...row);
    else out.push(a);
  }
  return out;
}

function asVal(v: Arg | undefined): CellValue {
  if (v == null) return null;
  if (Array.isArray(v)) return v[0]?.[0] ?? null;
  return v;
}

function asGrid(v: Arg | undefined): CellValue[][] {
  if (v == null) return [[null]];
  if (Array.isArray(v)) return v;
  return [[v]];
}

function numbers(args: Arg[]): number[] {
  return flatten(args)
    .map((v) => {
      if (v == null || v === "") return null;
      try {
        return num(v);
      } catch {
        return null;
      }
    })
    .filter((n): n is number => n != null);
}

type Tok =
  | { k: "num"; n: number }
  | { k: "str"; s: string }
  | { k: "id"; s: string }
  | { k: "ref"; s: string }
  | { k: "op"; s: string }
  | { k: "lp" }
  | { k: "rp" }
  | { k: "comma" }
  | { k: "colon" }
  | { k: "pct" };

function tokenize(src: string): Tok[] {
  const s = src.trim();
  const out: Tok[] = [];
  let i = 0;
  while (i < s.length) {
    const c = s[i]!;
    if (c === " " || c === "\t" || c === "\n") {
      i++;
      continue;
    }
    if (c === "(") {
      out.push({ k: "lp" });
      i++;
      continue;
    }
    if (c === ")") {
      out.push({ k: "rp" });
      i++;
      continue;
    }
    if (c === ",") {
      out.push({ k: "comma" });
      i++;
      continue;
    }
    if (c === ":") {
      out.push({ k: "colon" });
      i++;
      continue;
    }
    if (c === "%") {
      out.push({ k: "pct" });
      i++;
      continue;
    }
    if (c === '"' || c === "'") {
      const q = c;
      i++;
      let buf = "";
      while (i < s.length && s[i] !== q) {
        buf += s[i] === "\\" ? s[++i] ?? "" : s[i];
        i++;
      }
      i++;
      out.push({ k: "str", s: buf });
      continue;
    }
    if ("+-*/^<>&=".includes(c)) {
      if ((c === "<" || c === ">" || c === "=") && i + 1 < s.length) {
        const two = c + s[i + 1];
        if (two === "<=" || two === ">=" || two === "<>" || two === "==") {
          out.push({ k: "op", s: two === "==" ? "=" : two });
          i += 2;
          continue;
        }
      }
      out.push({ k: "op", s: c });
      i++;
      continue;
    }
    if (c === "." || (c >= "0" && c <= "9")) {
      const m = /^[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?/.exec(s.slice(i));
      if (!m) throw new FormulaError("#VALUE!");
      out.push({ k: "num", n: Number(m[0]) });
      i += m[0].length;
      continue;
    }
    if (/[A-Za-z_$]/.test(c)) {
      const id = /^[A-Za-z_][A-Za-z0-9_.]*/.exec(s.slice(i))!;
      const after = s.slice(i + id[0].length).replace(/^\s+/, "");
      const ref = /^\$?[A-Za-z]{1,3}\$?[1-9][0-9]{0,5}/.exec(s.slice(i));
      if (after.startsWith("(")) {
        out.push({ k: "id", s: id[0].toUpperCase() });
        i += id[0].length;
        continue;
      }
      if (ref && parseA1(ref[0].replace(/\$/g, ""))) {
        out.push({ k: "ref", s: ref[0].replace(/\$/g, "").toUpperCase() });
        i += ref[0].length;
        continue;
      }
      out.push({ k: "id", s: id[0].toUpperCase() });
      i += id[0].length;
      continue;
    }
    throw new FormulaError("#NAME?");
  }
  return out;
}

function evalFormula(src: string, get: Getter): CellValue {
  const expr = src.trim().startsWith("=") ? src.trim().slice(1) : src.trim();
  if (!expr) return null;
  const tokens = tokenize(expr);
  let p = 0;
  const peek = () => tokens[p];
  const take = () => tokens[p++];

  function parseCompare(): Arg {
    let left = parseConcat();
    const op = peek();
    if (op?.k === "op" && ["=", "<>", "<", ">", "<=", ">="].includes(op.s)) {
      take();
      const right = parseConcat();
      const lv = asVal(left);
      const rv = asVal(right);
      try {
        const ln = num(lv);
        const rn = num(rv);
        if (op.s === "=") return ln === rn;
        if (op.s === "<>") return ln !== rn;
        if (op.s === "<") return ln < rn;
        if (op.s === ">") return ln > rn;
        if (op.s === "<=") return ln <= rn;
        if (op.s === ">=") return ln >= rn;
      } catch {
        const a = String(lv ?? "").toLowerCase();
        const b = String(rv ?? "").toLowerCase();
        if (op.s === "=") return a === b;
        if (op.s === "<>") return a !== b;
      }
      return false;
    }
    return left;
  }

  function parseConcat(): Arg {
    let left = parseAdd();
    while (peek()?.k === "op" && (peek() as { s: string }).s === "&") {
      take();
      const right = parseAdd();
      left = `${asVal(left) ?? ""}${asVal(right) ?? ""}`;
    }
    return left;
  }

  function parseAdd(): Arg {
    let left = parseMul();
    while (peek()?.k === "op" && "+-".includes((peek() as { s: string }).s)) {
      const op = take() as { s: string };
      const right = parseMul();
      left = op.s === "+" ? num(asVal(left)) + num(asVal(right)) : num(asVal(left)) - num(asVal(right));
    }
    return left;
  }

  function parseMul(): Arg {
    let left = parsePow();
    while (peek()?.k === "op" && "*/".includes((peek() as { s: string }).s)) {
      const op = take() as { s: string };
      const right = parsePow();
      const b = num(asVal(right));
      if (op.s === "/" && b === 0) throw new FormulaError("#DIV/0!");
      left = op.s === "*" ? num(asVal(left)) * b : num(asVal(left)) / b;
    }
    return left;
  }

  function parsePow(): Arg {
    let left = parsePercent();
    if (peek()?.k === "op" && (peek() as { s: string }).s === "^") {
      take();
      left = num(asVal(left)) ** num(asVal(parsePow()));
    }
    return left;
  }

  function parsePercent(): Arg {
    let left = parseUnary();
    while (peek()?.k === "pct") {
      take();
      left = num(asVal(left)) / 100;
    }
    return left;
  }

  function parseUnary(): Arg {
    if (peek()?.k === "op" && (peek() as { s: string }).s === "-") {
      take();
      return -num(asVal(parseUnary()));
    }
    if (peek()?.k === "op" && (peek() as { s: string }).s === "+") {
      take();
      return parseUnary();
    }
    return parsePrimary();
  }

  function parsePrimary(): Arg {
    const t = peek();
    if (!t) throw new FormulaError("#VALUE!");
    if (t.k === "num") {
      take();
      return t.n;
    }
    if (t.k === "str") {
      take();
      return t.s;
    }
    if (t.k === "id") {
      take();
      if (t.s === "TRUE") return true;
      if (t.s === "FALSE") return false;
      if (peek()?.k === "lp") {
        take();
        const args: Arg[] = [];
        if (peek()?.k !== "rp") {
          args.push(parseCompare());
          while (peek()?.k === "comma") {
            take();
            args.push(parseCompare());
          }
        }
        if (peek()?.k !== "rp") throw new FormulaError("#VALUE!");
        take();
        return callFn(t.s, args, get);
      }
      throw new FormulaError("#NAME?");
    }
    if (t.k === "ref") {
      take();
      if (peek()?.k === "colon") {
        take();
        const b = take();
        if (b?.k !== "ref") throw new FormulaError("#REF!");
        const a = parseA1(t.s);
        const p2 = parseA1(b.s);
        if (!a || !p2) throw new FormulaError("#REF!");
        const c0 = Math.min(a.col, p2.col);
        const c1 = Math.max(a.col, p2.col);
        const r0 = Math.min(a.row, p2.row);
        const r1 = Math.max(a.row, p2.row);
        const grid: CellValue[][] = [];
        for (let r = r0; r <= r1; r++) {
          const row: CellValue[] = [];
          for (let c = c0; c <= c1; c++) row.push(get(c, r));
          grid.push(row);
        }
        return grid;
      }
      const a = parseA1(t.s);
      if (!a) throw new FormulaError("#REF!");
      return get(a.col, a.row);
    }
    if (t.k === "lp") {
      take();
      const v = parseCompare();
      if (peek()?.k !== "rp") throw new FormulaError("#VALUE!");
      take();
      return v;
    }
    throw new FormulaError("#VALUE!");
  }

  const result = parseCompare();
  if (p !== tokens.length) throw new FormulaError("#VALUE!");
  return asVal(result);
}

function matchCrit(v: CellValue, crit: CellValue): boolean {
  if (typeof crit === "string") {
    const m = /^(<=|>=|<>|=|<|>)(.*)$/.exec(crit.trim());
    if (m) {
      const op = m[1]!;
      const rhs: CellValue = m[2] !== "" && !Number.isNaN(Number(m[2])) ? Number(m[2]) : m[2]!;
      try {
        const a = num(v);
        const b = num(rhs);
        if (op === ">") return a > b;
        if (op === "<") return a < b;
        if (op === ">=") return a >= b;
        if (op === "<=") return a <= b;
        if (op === "<>") return a !== b;
        return a === b;
      } catch {
        return op === "<>" ? String(v) !== String(rhs) : String(v) === String(rhs);
      }
    }
  }
  try {
    return num(v) === num(crit);
  } catch {
    return String(v ?? "").toLowerCase() === String(crit ?? "").toLowerCase();
  }
}

function callFn(name: string, args: Arg[], get: Getter): CellValue {
  const n = name.toUpperCase();
  const flat = flatten(args);
  const xs = () => numbers(args);

  if (n === "SUM" || n === "PRODUCT") {
    const nums = xs();
    return n === "SUM" ? nums.reduce((a, b) => a + b, 0) : nums.reduce((a, b) => a * b, 1);
  }
  if (n === "AVERAGE" || n === "AVG" || n === "MEAN") {
    const nums = xs();
    return nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : null;
  }
  if (n === "MIN") return xs().length ? Math.min(...xs()) : null;
  if (n === "MAX") return xs().length ? Math.max(...xs()) : null;
  if (n === "COUNT") return xs().length;
  if (n === "COUNTA") return flat.filter((v) => v != null && v !== "").length;
  if (n === "COUNTBLANK") return flat.filter((v) => v == null || v === "").length;
  if (n === "IF") return truthy(asVal(args[0])) ? asVal(args[1]) : asVal(args[2]);
  if (n === "IFS") {
    for (let i = 0; i < args.length; i += 2) {
      if (truthy(asVal(args[i]))) return asVal(args[i + 1]);
    }
    return null;
  }
  if (n === "IFERROR" || n === "IFNA") {
    const v = asVal(args[0]);
    if (typeof v === "string" && v.startsWith("#")) return asVal(args[1]);
    return v;
  }
  if (n === "AND") return args.every((a) => truthy(asVal(a)));
  if (n === "OR") return args.some((a) => truthy(asVal(a)));
  if (n === "XOR") return args.filter((a) => truthy(asVal(a))).length % 2 === 1;
  if (n === "NOT") return !truthy(asVal(args[0]));
  if (n === "ROUND") {
    const x = asVal(args[0]);
    if (x == null || x === "") return null;
    const d = args[1] == null ? 0 : num(asVal(args[1]));
    const f = 10 ** d;
    return Math.round(num(x) * f) / f;
  }
  if (n === "ROUNDUP" || n === "ROUNDDOWN") {
    const x = num(asVal(args[0]));
    const d = args[1] == null ? 0 : num(asVal(args[1]));
    const f = 10 ** d;
    const m = n === "ROUNDUP" ? (x >= 0 ? Math.ceil : Math.floor) : x >= 0 ? Math.floor : Math.ceil;
    return m(x * f) / f;
  }
  if (n === "ABS") return Math.abs(num(asVal(args[0])));
  if (n === "INT" || n === "TRUNC") return Math.trunc(num(asVal(args[0])));
  if (n === "SQRT") return Math.sqrt(num(asVal(args[0])));
  if (n === "POWER") return num(asVal(args[0])) ** num(asVal(args[1]));
  if (n === "MOD") return num(asVal(args[0])) % num(asVal(args[1]));
  if (n === "SIGN") return Math.sign(num(asVal(args[0])));
  if (n === "PI") return Math.PI;
  if (n === "EXP") return Math.exp(num(asVal(args[0])));
  if (n === "LN") return Math.log(num(asVal(args[0])));
  if (n === "LOG") return Math.log(num(asVal(args[0]))) / Math.log(num(asVal(args[1] ?? 10)));
  if (n === "LOG10") return Math.log10(num(asVal(args[0])));
  if (n === "CEILING") return Math.ceil(num(asVal(args[0])));
  if (n === "FLOOR") return Math.floor(num(asVal(args[0])));
  if (n === "MEDIAN") {
    const nms = xs().slice().sort((a, b) => a - b);
    if (!nms.length) return null;
    const m = Math.floor(nms.length / 2);
    return nms.length % 2 ? nms[m]! : (nms[m - 1]! + nms[m]!) / 2;
  }
  if (n === "STDEV" || n === "STDEV.S") {
    const nms = xs();
    if (nms.length < 2) return null;
    const mean = nms.reduce((a, b) => a + b, 0) / nms.length;
    return Math.sqrt(nms.reduce((a, b) => a + (b - mean) ** 2, 0) / (nms.length - 1));
  }
  if (n === "VAR" || n === "VAR.S") {
    const nms = xs();
    if (nms.length < 2) return null;
    const mean = nms.reduce((a, b) => a + b, 0) / nms.length;
    return nms.reduce((a, b) => a + (b - mean) ** 2, 0) / (nms.length - 1);
  }
  if (n === "LARGE" || n === "SMALL") {
    const nms = xs().slice().sort((a, b) => (n === "LARGE" ? b - a : a - b));
    const k = Math.max(1, Math.trunc(num(asVal(args[1])))) - 1;
    return nms[k] ?? null;
  }
  if (n === "RANK") {
    const x = num(asVal(args[0]));
    const nms = numbers(args.slice(1)).slice().sort((a, b) => b - a);
    return nms.indexOf(x) + 1 || null;
  }
  if (n === "COUNTIF") {
    const range = flatten([args[0] ?? null]);
    return range.filter((v) => matchCrit(v, asVal(args[1]))).length;
  }
  if (n === "SUMIF") {
    const range = flatten([args[0] ?? null]);
    const sumr = args[2] == null ? range : flatten([args[2]]);
    let t = 0;
    range.forEach((v, i) => {
      if (matchCrit(v, asVal(args[1]))) {
        try {
          t += num(sumr[i] ?? 0);
        } catch {
          /* skip */
        }
      }
    });
    return t;
  }
  if (n === "AVERAGEIF") {
    const range = flatten([args[0] ?? null]);
    const avg = args[2] == null ? range : flatten([args[2]]);
    const hit: number[] = [];
    range.forEach((v, i) => {
      if (matchCrit(v, asVal(args[1]))) {
        try {
          hit.push(num(avg[i] ?? 0));
        } catch {
          /* skip */
        }
      }
    });
    return hit.length ? hit.reduce((a, b) => a + b, 0) / hit.length : null;
  }
  if (n === "CONCAT" || n === "CONCATENATE") return flat.map((v) => (v == null ? "" : String(v))).join("");
  if (n === "TEXTJOIN") {
    const sep = String(asVal(args[0]) ?? "");
    const skip = truthy(asVal(args[1]));
    return flatten(args.slice(2))
      .filter((v) => !skip || (v != null && v !== ""))
      .map((v) => String(v ?? ""))
      .join(sep);
  }
  if (n === "LEFT") return String(asVal(args[0]) ?? "").slice(0, num(asVal(args[1] ?? 1)));
  if (n === "RIGHT") {
    const str = String(asVal(args[0]) ?? "");
    return str.slice(-num(asVal(args[1] ?? 1)));
  }
  if (n === "MID") {
    const str = String(asVal(args[0]) ?? "");
    const start = Math.max(0, num(asVal(args[1])) - 1);
    return str.slice(start, start + num(asVal(args[2] ?? str.length)));
  }
  if (n === "LEN") return String(asVal(args[0]) ?? "").length;
  if (n === "TRIM") return String(asVal(args[0]) ?? "").trim().replace(/\s+/g, " ");
  if (n === "UPPER") return String(asVal(args[0]) ?? "").toUpperCase();
  if (n === "LOWER") return String(asVal(args[0]) ?? "").toLowerCase();
  if (n === "PROPER")
    return String(asVal(args[0]) ?? "").replace(/\w\S*/g, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
  if (n === "VALUE") return num(asVal(args[0]));
  if (n === "TEXT") {
    const x = num(asVal(args[0]));
    const fmt = String(asVal(args[1]) ?? "0");
    if (fmt.includes("%")) return `${(x * 100).toFixed(0)}%`;
    const d = (fmt.split(".")[1] || "").length;
    return d ? x.toFixed(d) : String(Math.round(x));
  }
  if (n === "FIND" || n === "SEARCH") {
    const needle = String(asVal(args[0]) ?? "");
    const hay = String(asVal(args[1]) ?? "");
    const start = Math.max(0, num(asVal(args[2] ?? 1)) - 1);
    const i = (n === "FIND" ? hay.indexOf(needle, start) : hay.toLowerCase().indexOf(needle.toLowerCase(), start)) + 1;
    if (i === 0) throw new FormulaError("#VALUE!");
    return i;
  }
  if (n === "SUBSTITUTE") {
    const t = String(asVal(args[0]) ?? "");
    const a = String(asVal(args[1]) ?? "");
    const b = String(asVal(args[2]) ?? "");
    return t.split(a).join(b);
  }
  if (n === "ISBLANK") {
    const v = asVal(args[0]);
    return v == null || v === "";
  }
  if (n === "ISNUMBER") {
    try {
      num(asVal(args[0]));
      return asVal(args[0]) !== "" && asVal(args[0]) != null;
    } catch {
      return false;
    }
  }
  if (n === "ISTEXT") return typeof asVal(args[0]) === "string";
  if (n === "N") {
    try {
      return num(asVal(args[0]));
    } catch {
      return 0;
    }
  }
  if (n === "NA") throw new FormulaError("#N/A");
  if (n === "TODAY") {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }
  if (n === "NOW") return new Date().toISOString();
  if (n === "YEAR") return new Date(String(asVal(args[0]))).getFullYear();
  if (n === "MONTH") return new Date(String(asVal(args[0]))).getMonth() + 1;
  if (n === "DAY") return new Date(String(asVal(args[0]))).getDate();
  if (n === "RAND") return Math.random();
  if (n === "RANDBETWEEN") {
    const a = Math.ceil(num(asVal(args[0])));
    const b = Math.floor(num(asVal(args[1])));
    return Math.floor(Math.random() * (b - a + 1)) + a;
  }
  if (n === "SUMPRODUCT") {
    const g = args.map(asGrid);
    const rows = Math.min(...g.map((x) => x.length));
    const cols = Math.min(...g.map((x) => x[0]?.length ?? 0));
    let t = 0;
    for (let r = 0; r < rows; r++)
      for (let c = 0; c < cols; c++) {
        t += g.reduce((p, grid) => p * num(grid[r]?.[c] ?? 0), 1);
      }
    return t;
  }
  if (n === "VLOOKUP") {
    const key = asVal(args[0]);
    const grid = asGrid(args[1]);
    const idx = Math.max(1, Math.trunc(num(asVal(args[2])))) - 1;
    const exact = args[3] == null ? true : !truthy(asVal(args[3]));
    for (const row of grid) {
      const k = row[0];
      if (exact) {
        if (String(k ?? "").toLowerCase() === String(key ?? "").toLowerCase() || k === key) return row[idx] ?? null;
      } else {
        try {
          if (num(k) <= num(key)) return row[idx] ?? null;
        } catch {
          /* skip */
        }
      }
    }
    throw new FormulaError("#N/A");
  }
  if (n === "INDEX") {
    const grid = asGrid(args[0]);
    const r = Math.max(1, Math.trunc(num(asVal(args[1])))) - 1;
    const c = args[2] == null ? 0 : Math.max(1, Math.trunc(num(asVal(args[2])))) - 1;
    return grid[r]?.[c] ?? null;
  }
  if (n === "MATCH") {
    const key = asVal(args[0]);
    const list = flatten([args[1] ?? null]);
    const i = list.findIndex((v) => String(v ?? "").toLowerCase() === String(key ?? "").toLowerCase() || v === key);
    if (i < 0) throw new FormulaError("#N/A");
    return i + 1;
  }
  if (n === "CHOOSE") {
    const i = Math.trunc(num(asVal(args[0])));
    return asVal(args[i]);
  }
  if (n === "INDIRECT") {
    const ref = String(asVal(args[0]) ?? "");
    const a = parseA1(ref);
    if (!a) throw new FormulaError("#REF!");
    return get(a.col, a.row);
  }
  if (n === "ROW") {
    const ref = String(asVal(args[0]) ?? "A1");
    return (parseA1(ref)?.row ?? 0) + 1;
  }
  if (n === "COLUMN") {
    const ref = String(asVal(args[0]) ?? "A1");
    return (parseA1(ref)?.col ?? 0) + 1;
  }
  throw new FormulaError("#NAME?");
}

export function tryEval(raw: string, get: Getter): CellValue {
  try {
    return evalFormula(raw, get);
  } catch (e) {
    if (e instanceof FormulaError) return e.code;
    return "#ERROR!";
  }
}

export function evaluateSheet(cells: Record<string, { v: string }>, rows: number, cols: number): Record<string, CellValue> {
  const cache = new Map<string, CellValue>();
  const seen = new Set<string>();

  function valueOf(col: number, row: number): CellValue {
    const key = cellKey(col, row);
    if (cache.has(key)) return cache.get(key)!;
    if (seen.has(key)) return "#CYCLE!";
    const raw = cells[key]?.v ?? "";
    if (raw.trim().startsWith("=")) {
      seen.add(key);
      const v = tryEval(raw, valueOf);
      seen.delete(key);
      cache.set(key, v);
      return v;
    }
    if (raw === "") {
      cache.set(key, null);
      return null;
    }
    if (raw.trim() !== "" && !Number.isNaN(Number(raw))) {
      const n = Number(raw);
      cache.set(key, n);
      return n;
    }
    cache.set(key, raw);
    return raw;
  }

  const out: Record<string, CellValue> = {};
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const k = cellKey(c, r);
      if (cells[k]) out[k] = valueOf(c, r);
    }
  }
  return out;
}

export function formatValue(v: CellValue, fmt?: string): string {
  if (v == null) return "";
  if (typeof v === "string") return v;
  if (typeof v === "boolean") return v ? "TRUE" : "FALSE";
  if (fmt === "percent") return `${v.toFixed(0)}%`;
  if (fmt === "number") return Number.isInteger(v) ? String(v) : v.toFixed(2);
  if (Number.isInteger(v)) return String(v);
  return String(Math.round(v * 10000) / 10000);
}

void parseRange;
