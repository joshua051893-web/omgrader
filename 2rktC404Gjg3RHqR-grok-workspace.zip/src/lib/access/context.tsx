import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { db } from "@/lib/db/database";
import type { AppUser, LicenseConfig } from "@/lib/types";
import { clearSession, readSession, writeSession } from "@/lib/access/session";
import { loginUser } from "@/lib/access/repo";

interface AccessValue {
  ready: boolean;
  user: AppUser | null;
  license: LicenseConfig | null;
  login: (username: string, password: string) => Promise<AppUser>;
  logout: () => void;
  refresh: () => Promise<void>;
}

const AccessContext = createContext<AccessValue | null>(null);

export function AccessProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<AppUser | null>(null);
  const [license, setLicense] = useState<LicenseConfig | null>(null);

  const refresh = useCallback(async () => {
    const session = readSession();
    const lic = (await db.license.get("singleton")) ?? null;
    setLicense(lic);
    if (!session) {
      setUser(null);
      return;
    }
    const row = await db.users.get(session.userId);
    setUser(row ?? null);
    if (!row) clearSession();
  }, []);

  useEffect(() => {
    void refresh().finally(() => setReady(true));
  }, [refresh]);

  const value = useMemo<AccessValue>(
    () => ({
      ready,
      user,
      license,
      refresh,
      logout: () => {
        clearSession();
        setUser(null);
      },
      login: async (username, password) => {
        const next = await loginUser(username, password);
        writeSession(next.id);
        setUser(next);
        return next;
      },
    }),
    [ready, user, license, refresh],
  );

  return <AccessContext.Provider value={value}>{children}</AccessContext.Provider>;
}

export function useAccess() {
  const ctx = useContext(AccessContext);
  if (!ctx) throw new Error("useAccess must be used inside AccessProvider");
  return ctx;
}

export function useOptionalAccess() {
  return useContext(AccessContext);
}
