const enc = new TextEncoder();

export async function hashPassword(password: string, salt?: string) {
  const usedSalt = salt ?? crypto.randomUUID();
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: enc.encode(usedSalt), iterations: 80_000 },
    key,
    256,
  );
  const hash = [...new Uint8Array(bits)].map((b) => b.toString(16).padStart(2, "0")).join("");
  return { salt: usedSalt, hash };
}

export async function verifyPassword(password: string, salt: string, hash: string) {
  const next = await hashPassword(password, salt);
  return next.hash === hash;
}
