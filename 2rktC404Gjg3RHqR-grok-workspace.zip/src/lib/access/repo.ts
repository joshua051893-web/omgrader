import { db } from "@/lib/db/database";
import { hashPassword, verifyPassword } from "@/lib/access/crypto";
import { DEFAULT_ADMIN_PASSWORD, DEFAULT_ADMIN_USERNAME } from "@/lib/access/constants";
import type { AppUser, LicenseConfig, UserStatus } from "@/lib/types";
import { nowIso, uid } from "@/lib/utils";

export const DEFAULT_LICENSE: LicenseConfig = {
  id: "singleton",
  expiresAt: null,
  maxScansPerDay: null,
  maxScansPerMonth: null,
  maxScansPerYear: null,
  maxScansTotal: null,
  message: "",
  updatedAt: nowIso(),
};

export async function ensureAccessSeeded() {
  const existing = await db.users.where("username").equals(DEFAULT_ADMIN_USERNAME).first();
  if (!existing) {
    const { salt, hash } = await hashPassword(DEFAULT_ADMIN_PASSWORD);
    const t = nowIso();
    const admin: AppUser = {
      id: uid("usr"),
      username: DEFAULT_ADMIN_USERNAME,
      fullName: "Administrator",
      email: "admin@omg.local",
      schoolName: "",
      contactNumber: "",
      passwordSalt: salt,
      passwordHash: hash,
      role: "admin",
      status: "approved",
      expiresAt: null,
      maxScansPerMonth: null,
      maxScansPerYear: null,
      notes: "Default administrator.",
      createdAt: t,
      updatedAt: t,
      approvedAt: t,
    };
    await db.users.put(admin);
  }
  const license = await db.license.get("singleton");
  if (!license) await db.license.put({ ...DEFAULT_LICENSE, updatedAt: nowIso() });
}

export async function registerUser(input: {
  username: string;
  password: string;
  fullName: string;
  email: string;
  schoolName: string;
  contactNumber: string;
}) {
  const username = input.username.trim().toLowerCase();
  if (!username || !input.password || !input.fullName.trim()) {
    throw new Error("Username, full name, and password are required.");
  }
  if (input.password.length < 6) throw new Error("Password must be at least 6 characters.");
  const clash = await db.users.where("username").equals(username).first();
  if (clash) throw new Error("That username is already taken.");
  const { salt, hash } = await hashPassword(input.password);
  const t = nowIso();
  const adminCount = await db.users.where("role").equals("admin").count();
  const first = adminCount === 0;
  const user: AppUser = {
    id: uid("usr"),
    username,
    fullName: input.fullName.trim(),
    email: input.email.trim(),
    schoolName: input.schoolName.trim(),
    contactNumber: input.contactNumber.trim(),
    passwordSalt: salt,
    passwordHash: hash,
    role: first ? "admin" : "teacher",
    status: first ? "approved" : "pending",
    expiresAt: null,
    maxScansPerMonth: null,
    maxScansPerYear: null,
    notes: "",
    createdAt: t,
    updatedAt: t,
    approvedAt: first ? t : null,
  };
  await db.users.put(user);
  return user;
}

export async function loginUser(username: string, password: string) {
  const user = await db.users.where("username").equals(username.trim().toLowerCase()).first();
  if (!user) throw new Error("Incorrect username or password.");
  const ok = await verifyPassword(password, user.passwordSalt, user.passwordHash);
  if (!ok) throw new Error("Incorrect username or password.");
  return user;
}

export async function setUserStatus(id: string, status: UserStatus) {
  const user = await db.users.get(id);
  if (!user) throw new Error("User not found.");
  await db.users.update(id, {
    status,
    approvedAt: status === "approved" ? nowIso() : user.approvedAt,
    updatedAt: nowIso(),
  });
}

export async function saveLicense(patch: Partial<LicenseConfig>) {
  const cur = (await db.license.get("singleton")) ?? DEFAULT_LICENSE;
  await db.license.put({ ...cur, ...patch, id: "singleton", updatedAt: nowIso() });
}

export async function updateUser(id: string, patch: Partial<AppUser>) {
  const user = await db.users.get(id);
  if (!user) throw new Error("User not found.");
  await db.users.put({ ...user, ...patch, id, updatedAt: nowIso() });
}

export async function changePassword(id: string, next: string) {
  if (next.length < 6) throw new Error("Password must be at least 6 characters.");
  const { salt, hash } = await hashPassword(next);
  await updateUser(id, { passwordSalt: salt, passwordHash: hash });
}
