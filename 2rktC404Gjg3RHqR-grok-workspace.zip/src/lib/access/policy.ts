import { db } from "@/lib/db/database";
import type { AppUser, LicenseConfig } from "@/lib/types";

export function licenseExpired(license: LicenseConfig | undefined) {
  if (!license?.expiresAt) return false;
  return license.expiresAt < new Date().toISOString().slice(0, 10);
}

export function accountExpired(user: AppUser) {
  if (!user.expiresAt) return false;
  return user.expiresAt < new Date().toISOString().slice(0, 10);
}

export function accessBlockedReason(user: AppUser, license: LicenseConfig | undefined): string | null {
  if (user.status === "pending") return "Your registration is waiting for the administrator to approve it.";
  if (user.status === "rejected") return "Your registration was not approved.";
  if (user.status === "suspended") return "This account is suspended. Ask the administrator.";
  if (accountExpired(user)) return "Your access period for OMG has ended. Ask the administrator to extend it.";
  if (user.role !== "admin" && licenseExpired(license)) {
    return license?.message || "The license for this copy of OMG has ended. Ask the administrator.";
  }
  return null;
}

function inRange(iso: string, start: Date, end: Date) {
  const t = new Date(iso).getTime();
  return t >= start.getTime() && t < end.getTime();
}

export interface ScanUsage {
  day: number;
  month: number;
  year: number;
  total: number;
  userMonth: number;
  userYear: number;
}

export async function scanUsage(userId?: string): Promise<ScanUsage> {
  const scans = await db.scans.toArray();
  const now = new Date();
  const day0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const month0 = new Date(now.getFullYear(), now.getMonth(), 1);
  const year0 = new Date(now.getFullYear(), 0, 1);
  const nextDay = new Date(day0);
  nextDay.setDate(nextDay.getDate() + 1);
  const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const nextYear = new Date(now.getFullYear() + 1, 0, 1);
  let day = 0;
  let month = 0;
  let year = 0;
  let userMonth = 0;
  let userYear = 0;
  for (const s of scans) {
    if (inRange(s.createdAt, day0, nextDay)) day++;
    if (inRange(s.createdAt, month0, nextMonth)) month++;
    if (inRange(s.createdAt, year0, nextYear)) year++;
    if (userId && s.scannedByUserId === userId) {
      if (inRange(s.createdAt, month0, nextMonth)) userMonth++;
      if (inRange(s.createdAt, year0, nextYear)) userYear++;
    }
  }
  return { day, month, year, total: scans.length, userMonth, userYear };
}

export async function assertCanScan(user: AppUser, extra = 1) {
  const license = await db.license.get("singleton");
  const blocked = accessBlockedReason(user, license);
  if (blocked) throw new Error(blocked);
  const usage = await scanUsage(user.id);
  const over = (limit: number | null | undefined, used: number, label: string) => {
    if (limit == null || limit <= 0) return;
    if (used + extra > limit) throw new Error(`Scan limit reached (${label}: ${used}/${limit}). Ask the administrator.`);
  };
  over(license?.maxScansPerDay, usage.day, "today");
  over(license?.maxScansPerMonth, usage.month, "this month");
  over(license?.maxScansPerYear, usage.year, "this year");
  over(license?.maxScansTotal, usage.total, "all time");
  over(user.maxScansPerMonth, usage.userMonth, "your month");
  over(user.maxScansPerYear, usage.userYear, "your year");
}
