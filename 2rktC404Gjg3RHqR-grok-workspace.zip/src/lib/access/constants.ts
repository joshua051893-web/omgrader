export const SESSION_KEY = "omg-access-session";
export const DEFAULT_ADMIN_USERNAME = "admin";
export const DEFAULT_ADMIN_PASSWORD = "Admin@OMG1";
