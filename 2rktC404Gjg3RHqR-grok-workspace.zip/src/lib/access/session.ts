import { SESSION_KEY } from "@/lib/access/constants";

export interface SessionPayload {
  userId: string;
  at: string;
}

export function readSession(): SessionPayload | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SessionPayload;
    if (!parsed?.userId) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function writeSession(userId: string) {
  localStorage.setItem(SESSION_KEY, JSON.stringify({ userId, at: new Date().toISOString() } satisfies SessionPayload));
}

export function clearSession() {
  localStorage.removeItem(SESSION_KEY);
}
