import { db } from "@/lib/db/database";
import { DEFAULT_SETTINGS, defaultCategories, defaultSheetConfig } from "@/lib/db/defaults";
import type { Assessment, Student } from "@/lib/types";
import { emptyKey } from "@/lib/types";
import { examCodeFor } from "@/lib/sheets/exam-code";
import { ensureAccessSeeded } from "@/lib/access/repo";
import { nowIso, padRoll, uid } from "@/lib/utils";

const SAMPLE_NAMES = [
  "Juan P. Dela Cruz",
  "Maria L. Santos",
  "Andres R. Reyes",
  "Ana M. Garcia",
  "Jose D. Ramos",
  "Liza C. Torres",
  "Miguel A. Cruz",
  "Sofia N. Mendoza",
  "Carlo B. Villanueva",
  "Patricia S. Lopez",
  "Diego F. Navarro",
  "Elena T. Bautista",
];

function sampleStudents(): Student[] {
  const t = nowIso();
  return SAMPLE_NAMES.map((name, i) => {
    const roll = padRoll(String(i + 1), 3);
    return {
      id: uid("stu"),
      rollNumber: roll,
      lrn: "",
      firstName: "",
      middleName: "",
      lastName: "",
      fullName: name,
      gradeLevel: "9",
      section: "A",
      schoolYear: "2026-2027",
      extra: "",
      createdAt: t,
      updatedAt: t,
    };
  });
}

export async function ensureSeeded() {
  await ensureAccessSeeded();
  const existing = await db.settings.get("singleton");
  if (existing?.seeded) return;

  const cats = defaultCategories();
  const students = sampleStudents();
  const t = nowIso();
  const key = [
    "A", "C", "B", "D", "A",
    "B", "C", "A", "D", "B",
    "A", "A", "C", "D", "B",
    "C", "A", "B", "D", "A",
  ];
  const assessment: Assessment = {
    id: uid("asm"),
    name: "Fractions Quiz 1",
    subject: "Mathematics",
    gradeLevel: "9",
    section: "A",
    teacher: DEFAULT_SETTINGS.teacherName,
    schoolYear: "2026-2027",
    date: t.slice(0, 10),
    itemCount: 20,
    passingScore: 12,
    instructions: "Shade one answer per item. Use a dark pen.",
    answerKey: key,
    answerKeys: { A: key, B: emptyKey(20), C: emptyKey(20) },
    testSet: "A",
    timeLimitMinutes: 30,
    type: "Quiz",
    archived: false,
    examCode: "",
    sheetConfig: defaultSheetConfig({
      quizName: "Fractions Quiz 1",
      subject: "Mathematics",
      itemCount: 20,
      date: t.slice(0, 10),
      testSet: "A",
    }),
    createdAt: t,
    updatedAt: t,
  };
  assessment.examCode = examCodeFor(assessment);
  assessment.sheetConfig.examCode = assessment.examCode;

  await db.transaction("rw", db.settings, db.categories, db.students, db.assessments, db.templates, async () => {
    const again = await db.settings.get("singleton");
    if (again?.seeded) return;
    await db.settings.put({ ...DEFAULT_SETTINGS, seeded: true });
    await db.categories.bulkAdd(cats);
    await db.students.bulkAdd(students);
    await db.assessments.add(assessment);
    await db.templates.bulkAdd([
      {
        id: uid("tpl"),
        name: "Grade 9 – 20 Item Quiz",
        config: defaultSheetConfig({ itemCount: 20, quizName: "20-Item Quiz" }),
        createdAt: t,
      },
      {
        id: uid("tpl"),
        name: "Grade 10 – 50 Item Test",
        config: defaultSheetConfig({
          itemCount: 50,
          quizName: "50-Item Test",
          choices: ["A", "B", "C", "D", "E"],
        }),
        createdAt: t,
      },
      {
        id: uid("tpl"),
        name: "Quarterly Exam – 60 Items",
        config: defaultSheetConfig({
          itemCount: 60,
          quizName: "Quarterly Examination",
          paper: "Legal",
        }),
        createdAt: t,
      },
    ]);
  });
}
