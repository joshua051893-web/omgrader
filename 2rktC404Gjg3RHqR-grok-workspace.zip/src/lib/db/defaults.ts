import type { AppSettings, GradeCategory, SheetConfig } from "@/lib/types";
import { uid } from "@/lib/utils";

export const DEFAULT_SETTINGS: AppSettings = {
  id: "singleton",
  schoolName: "Riverside National High School",
  schoolId: "301234",
  schoolAddress: "Riverside, Philippines",
  teacherName: "Ms. Reyes",
  teacherFirstName: "Maria",
  teacherLastName: "Reyes",
  position: "Subject Teacher",
  contactNumber: "0917 000 0000",
  email: "ms.reyes@school.edu",
  photoBlobId: null,
  theme: "system",
  defaultGrade: "9",
  defaultSection: "A",
  defaultSchoolYear: "2026-2027",
  rollDigits: 3,
  seeded: false,
  firebaseApiKey: "",
  firebaseAuthDomain: "",
  firebaseProjectId: "",
  firebaseStorageBucket: "",
  firebaseMessagingSenderId: "",
  firebaseAppId: "",
  firebaseEnabled: false,
  firebaseEmail: "",
  lastCloudSyncAt: null,
};

export function defaultCategories(): GradeCategory[] {
  return [
    { id: uid("cat"), name: "Written Works", weight: 30, sortOrder: 0 },
    { id: uid("cat"), name: "Performance Tasks", weight: 50, sortOrder: 1 },
    { id: uid("cat"), name: "Quarterly Assessment", weight: 20, sortOrder: 2 },
  ];
}

export function defaultSheetConfig(partial: Partial<SheetConfig> = {}): SheetConfig {
  return {
    paper: "A4",
    customWidthMm: 210,
    customHeightMm: 297,
    orientation: "portrait",
    itemCount: 20,
    choices: ["A", "B", "C", "D"],
    quizName: "Quiz",
    subject: "Mathematics",
    teacher: DEFAULT_SETTINGS.teacherName,
    school: DEFAULT_SETTINGS.schoolName,
    date: new Date().toISOString().slice(0, 10),
    instructions: "Use a dark pen or pencil. Shade each bubble fully. Erase completely to change an answer.",
    showRollBubbles: true,
    rollDigits: 3,
    showName: true,
    showLrn: true,
    showSection: true,
    testSet: "A",
    ...partial,
  };
}
