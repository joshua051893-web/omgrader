import Dexie, { type Table } from "dexie";
import type {
  AppSettings,
  AppUser,
  Assessment,
  BackupMeta,
  BlobRecord,
  GradeCategory,
  GradeWorkbook,
  LicenseConfig,
  ScanResult,
  SheetTemplate,
  Student,
} from "@/lib/types";

export class QuillmarkDB extends Dexie {
  students!: Table<Student, string>;
  assessments!: Table<Assessment, string>;
  scans!: Table<ScanResult, string>;
  categories!: Table<GradeCategory, string>;
  templates!: Table<SheetTemplate, string>;
  blobs!: Table<BlobRecord, string>;
  settings!: Table<AppSettings, string>;
  backups!: Table<BackupMeta, string>;
  workbooks!: Table<GradeWorkbook, string>;
  users!: Table<AppUser, string>;
  license!: Table<LicenseConfig, string>;

  constructor() {
    super("quillmark-local");
    this.version(1).stores({
      students: "id, rollNumber, lrn, lastName, fullName, gradeLevel, section, schoolYear",
      assessments: "id, name, subject, gradeLevel, section, schoolYear, date, archived, categoryId",
      scans: "id, assessmentId, studentId, rollNumber, status, createdAt",
      categories: "id, sortOrder",
      templates: "id, name",
      blobs: "id, kind, createdAt",
      settings: "id",
      backups: "id, createdAt",
    });
    this.version(2).stores({
      students: "id, rollNumber, lrn, lastName, fullName, gradeLevel, section, schoolYear",
      assessments: "id, name, subject, gradeLevel, section, schoolYear, date, archived, testSet",
      scans: "id, assessmentId, studentId, rollNumber, status, createdAt",
      categories: "id, sortOrder",
      templates: "id, name",
      blobs: "id, kind, createdAt",
      settings: "id",
      backups: "id, createdAt",
    });
    this.version(3).stores({
      students: "id, rollNumber, lrn, lastName, fullName, gradeLevel, section, schoolYear",
      assessments: "id, name, subject, gradeLevel, section, schoolYear, date, archived, testSet",
      scans: "id, assessmentId, studentId, rollNumber, status, createdAt",
      categories: "id, sortOrder",
      templates: "id, name",
      blobs: "id, kind, createdAt",
      settings: "id",
      backups: "id, createdAt",
      workbooks: "id, gradeLevel, section",
    });
    this.version(4).stores({
      students: "id, rollNumber, lrn, lastName, fullName, gradeLevel, section, schoolYear",
      assessments: "id, name, subject, gradeLevel, section, schoolYear, date, archived, testSet",
      scans: "id, assessmentId, studentId, rollNumber, status, createdAt, scannedByUserId",
      categories: "id, sortOrder",
      templates: "id, name",
      blobs: "id, kind, createdAt",
      settings: "id",
      backups: "id, createdAt",
      workbooks: "id, gradeLevel, section",
      users: "id, username, status, role, createdAt",
      license: "id",
    });
  }
}

export const db = new QuillmarkDB();
