import { db } from "@/lib/db/database";
import type { AppSettings, Assessment, ScanResult, Student } from "@/lib/types";
import { fullName, nowIso, padRoll, uid } from "@/lib/utils";
import { DEFAULT_SETTINGS } from "@/lib/db/defaults";

export async function getSettings(): Promise<AppSettings> {
  const row = await db.settings.get("singleton");
  return { ...DEFAULT_SETTINGS, ...row, id: "singleton" };
}

export async function saveSettings(patch: Partial<AppSettings>) {
  const cur = await getSettings();
  await db.settings.put({ ...cur, ...patch, id: "singleton" });
}

export async function upsertStudent(input: Omit<Student, "id" | "createdAt" | "updatedAt"> & { id?: string }) {
  const t = nowIso();
  const existing = input.id ? await db.students.get(input.id) : undefined;
  const name = (input.fullName || fullName(input.firstName, input.middleName, input.lastName)).trim();
  const student: Student = {
    id: existing?.id ?? uid("stu"),
    rollNumber: padRoll(input.rollNumber),
    lrn: input.lrn ?? "",
    firstName: input.firstName || "",
    middleName: input.middleName || "",
    lastName: input.lastName || "",
    fullName: name,
    gradeLevel: input.gradeLevel,
    section: input.section,
    schoolYear: input.schoolYear,
    extra: input.extra ?? "",
    createdAt: existing?.createdAt ?? t,
    updatedAt: t,
  };
  await db.students.put(student);
  return student;
}

export async function deleteStudent(id: string) {
  await db.students.delete(id);
}

export async function saveAssessment(a: Assessment) {
  await db.assessments.put({ ...a, updatedAt: nowIso() });
}

export async function saveScan(scan: ScanResult) {
  await db.scans.put({ ...scan, updatedAt: nowIso() });
}

export async function deleteScan(scan: ScanResult) {
  await db.scans.delete(scan.id);
  const ids = [scan.originalBlobId, scan.markedBlobId].filter(Boolean) as string[];
  if (ids.length) await db.blobs.bulkDelete(ids);
}

export async function deleteAssessment(id: string) {
  const scans = await db.scans.where("assessmentId").equals(id).toArray();
  for (const scan of scans) await deleteScan(scan);
  await db.assessments.delete(id);
}

export async function putBlob(kind: "scan" | "marked" | "photo" | "other", blob: Blob, name: string) {
  const id = uid("blob");
  const bytes = await blob.arrayBuffer();
  await db.blobs.put({ id, kind, mime: blob.type || "image/png", name, bytes, createdAt: nowIso() });
  return id;
}

export async function blobUrl(id: string | null | undefined): Promise<string | null> {
  if (!id) return null;
  const rec = await db.blobs.get(id);
  if (!rec) return null;
  return URL.createObjectURL(new Blob([rec.bytes], { type: rec.mime }));
}
