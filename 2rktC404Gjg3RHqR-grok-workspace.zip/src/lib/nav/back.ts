export function parentPath(pathname: string): string {
  if (pathname === "/") return "/";
  if (pathname.startsWith("/review/")) return "/scan";
  if (pathname.startsWith("/students/")) return "/students";
  if (pathname.startsWith("/assessments/")) return "/assessments";
  if (pathname.startsWith("/gradebook/")) return "/gradebook";
  return "/";
}
