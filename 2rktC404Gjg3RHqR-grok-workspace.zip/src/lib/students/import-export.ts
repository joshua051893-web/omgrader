import * as XLSX from "xlsx";
import type { Student } from "@/lib/types";
import { fullName, nowIso, padRoll, uid } from "@/lib/utils";

export const STUDENT_COLUMNS = ["Roll Number", "Full Name", "Grade", "Section", "School Year"] as const;

export type ImportMode = "add" | "update" | "replace";

export interface ImportRow {
  row: number;
  rollNumber: string;
  fullName: string;
  gradeLevel: string;
  section: string;
  schoolYear: string;
  lrn: string;
  firstName: string;
  middleName: string;
  lastName: string;
  errors: string[];
  warnings: string[];
}

export function studentTemplateWorkbook(): ArrayBuffer {
  const ws = XLSX.utils.aoa_to_sheet([
    [...STUDENT_COLUMNS],
    ["001", "Juan P. Dela Cruz", "9", "A", "2026-2027"],
  ]);
  ws["!cols"] = STUDENT_COLUMNS.map((h) => ({ wch: Math.max(14, h.length + 4) }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Students");
  return XLSX.write(wb, { type: "array", bookType: "xlsx" }) as ArrayBuffer;
}

export function studentTemplateCsv(): string {
  return `${STUDENT_COLUMNS.join(",")}
001,Juan P. Dela Cruz,9,A,2026-2027
`;
}

function cell(v: unknown): string {
  return String(v ?? "").trim();
}

export function parseStudentFile(data: ArrayBuffer, filename: string): ImportRow[] {
  const wb = XLSX.read(data, { type: "array" });
  const sheet = wb.Sheets[wb.SheetNames[0]!];
  if (!sheet) return [];
  const json = XLSX.utils.sheet_to_json(sheet, { defval: "" }) as Record<string, unknown>[];
  void filename;
  return json.map((raw: Record<string, unknown>, i: number) => {
    const get = (...keys: string[]) => {
      for (const k of keys) {
        const found = Object.keys(raw).find(
          (rk) => rk.toLowerCase().replace(/\s+/g, "") === k.toLowerCase().replace(/\s+/g, ""),
        );
        if (found) return cell(raw[found]);
      }
      return "";
    };
    const firstName = get("First Name", "First");
    const middleName = get("Middle Name", "Middle", "MI");
    const lastName = get("Last Name", "Last");
    const name = get("Full Name", "Name", "Student") || fullName(firstName, middleName, lastName);
    const row: ImportRow = {
      row: i + 2,
      rollNumber: padRoll(get("Roll Number", "Roll", "RollNo")),
      fullName: name,
      gradeLevel: get("Grade", "Grade Level"),
      section: get("Section"),
      schoolYear: get("School Year", "SY"),
      lrn: get("LRN", "Student ID", "LRN/Student ID"),
      firstName,
      middleName,
      lastName,
      errors: [],
      warnings: [],
    };
    if (!row.rollNumber) row.errors.push("Missing roll number");
    if (!row.fullName) row.errors.push("Missing full name");
    if (!row.gradeLevel) row.errors.push("Missing grade");
    if (!row.section) row.errors.push("Missing section");
    if (!row.schoolYear) row.errors.push("Missing school year");
    return row;
  });
}

export function validateImport(rows: ImportRow[], existing: Student[]): ImportRow[] {
  const byRoll = new Map<string, number[]>();
  rows.forEach((r, i) => {
    if (r.rollNumber) {
      const a = byRoll.get(r.rollNumber) ?? [];
      a.push(i);
      byRoll.set(r.rollNumber, a);
    }
  });
  return rows.map((r) => {
    const errors = [...r.errors];
    const warnings = [...r.warnings];
    if ((byRoll.get(r.rollNumber)?.length ?? 0) > 1) errors.push("Duplicate roll number in file");
    if (existing.some((s) => s.rollNumber === r.rollNumber)) warnings.push("Roll number already in roster");
    return { ...r, errors, warnings };
  });
}

export function rowsToStudents(rows: ImportRow[], existing: Student[], mode: ImportMode): Student[] {
  const t = nowIso();
  if (mode === "replace") {
    return rows.filter((r) => r.errors.length === 0).map((r) => toStudent(r, t));
  }
  const map = new Map(existing.map((s) => [s.id, s]));
  const byRoll = new Map(existing.map((s) => [s.rollNumber, s]));
  for (const r of rows) {
    if (r.errors.length) continue;
    const prev = byRoll.get(r.rollNumber);
    if (prev && (mode === "update" || mode === "add")) {
      if (mode === "add") continue;
      const next: Student = {
        ...prev,
        ...toStudent(r, t),
        id: prev.id,
        createdAt: prev.createdAt,
      };
      map.set(prev.id, next);
    } else {
      const s = toStudent(r, t);
      map.set(s.id, s);
    }
  }
  return Array.from(map.values());
}

function toStudent(r: ImportRow, t: string): Student {
  return {
    id: uid("stu"),
    rollNumber: padRoll(r.rollNumber),
    lrn: r.lrn,
    firstName: r.firstName,
    middleName: r.middleName,
    lastName: r.lastName,
    fullName: r.fullName,
    gradeLevel: r.gradeLevel,
    section: r.section,
    schoolYear: r.schoolYear,
    extra: "",
    createdAt: t,
    updatedAt: t,
  };
}

export function studentsToXlsx(students: Student[]): ArrayBuffer {
  const aoa = [
    [...STUDENT_COLUMNS],
    ...students.map((s) => [s.rollNumber, s.fullName, s.gradeLevel, s.section, s.schoolYear]),
  ];
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Students");
  return XLSX.write(wb, { type: "array", bookType: "xlsx" }) as ArrayBuffer;
}

export function studentsToCsv(students: Student[]): string {
  const header = STUDENT_COLUMNS.join(",");
  const lines = students.map((s) =>
    [s.rollNumber, s.fullName, s.gradeLevel, s.section, s.schoolYear]
      .map((v) => `"${String(v).replace(/"/g, '""')}"`)
      .join(","),
  );
  return [header, ...lines].join("\n");
}
