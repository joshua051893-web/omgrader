import type { Assessment, GradeCategory, ScanResult, Student } from "@/lib/types";
import { keysForSet } from "@/lib/types";

export interface StudentGradeRow {
  student: Student;
  byAssessment: Record<string, ScanResult | null>;
  categoryPct: Record<string, number | null>;
  average: number | null;
}

export function computeGradebook(
  students: Student[],
  assessments: Assessment[],
  scans: ScanResult[],
  _categories: GradeCategory[] = [],
): StudentGradeRow[] {
  const active = assessments.filter((a) => !a.archived);
  return students
    .slice()
    .sort((a, b) => a.rollNumber.localeCompare(b.rollNumber))
    .map((student) => {
      const byAssessment: Record<string, ScanResult | null> = {};
      const pcts: number[] = [];
      for (const a of active) {
        const s = scans.find((x) => x.assessmentId === a.id && x.studentId === student.id && x.status !== "pending");
        byAssessment[a.id] = s ?? null;
        if (s) pcts.push(s.percentage);
      }
      return {
        student,
        byAssessment,
        categoryPct: {},
        average: pcts.length ? pcts.reduce((p, n) => p + n, 0) / pcts.length : null,
      };
    });
}

export interface ItemStat {
  item: number;
  key: string;
  correct: number;
  wrong: number;
  blank: number;
  difficulty: number;
  optionCounts: Record<string, number>;
  mostWrong: string | null;
}

export function itemAnalysis(assessment: Assessment, scans: ScanResult[]): ItemStat[] {
  const n = assessment.itemCount;
  const key = keysForSet(assessment);
  const choices = assessment.sheetConfig.choices;
  const stats: ItemStat[] = Array.from({ length: n }, (_, item) => ({
    item,
    key: key[item] ?? "",
    correct: 0,
    wrong: 0,
    blank: 0,
    difficulty: 0,
    optionCounts: Object.fromEntries(choices.map((c) => [c, 0])),
    mostWrong: null,
  }));
  const usable = scans.filter((s) => s.assessmentId === assessment.id && !s.flags.includes("unreadable"));
  for (const s of usable) {
    for (let i = 0; i < n; i++) {
      const a = s.answers[i] ?? null;
      const k = key[i];
      const st = stats[i]!;
      if (!a) st.blank++;
      else {
        st.optionCounts[a] = (st.optionCounts[a] ?? 0) + 1;
        if (k && a === k) st.correct++;
        else st.wrong++;
      }
    }
  }
  for (const st of stats) {
    const total = st.correct + st.wrong + st.blank;
    st.difficulty = total ? st.correct / total : 0;
    let best: string | null = null;
    let bestN = 0;
    for (const [opt, count] of Object.entries(st.optionCounts)) {
      if (opt === st.key) continue;
      if (count > bestN) {
        bestN = count;
        best = opt;
      }
    }
    st.mostWrong = bestN ? best : null;
  }
  return stats;
}

export function assessmentSummary(assessment: Assessment, scans: ScanResult[]) {
  const usable = scans.filter((s) => s.assessmentId === assessment.id && s.status !== "pending");
  const scores = usable.map((s) => s.score).sort((a, b) => a - b);
  const avg = scores.length ? scores.reduce((p, n) => p + n, 0) / scores.length : 0;
  const mid = scores.length
    ? scores.length % 2
      ? scores[(scores.length - 1) / 2]!
      : (scores[scores.length / 2 - 1]! + scores[scores.length / 2]!) / 2
    : 0;
  const passed = usable.filter((s) => s.score >= assessment.passingScore).length;
  return {
    count: usable.length,
    highest: scores.length ? scores[scores.length - 1]! : 0,
    lowest: scores.length ? scores[0]! : 0,
    average: avg,
    median: mid,
    passed,
    failed: usable.length - passed,
  };
}
