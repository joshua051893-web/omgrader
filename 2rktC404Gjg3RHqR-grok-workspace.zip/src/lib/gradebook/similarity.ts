import type { Assessment, ScanResult, Student } from "@/lib/types";
import { keysForSet } from "@/lib/types";

export interface PairSimilarity {
  section: string;
  aId: string;
  bId: string;
  aName: string;
  aRoll: string;
  bName: string;
  bRoll: string;
  sharedWrong: number;
  bothWrong: number;
  index: number;
}

export interface SectionSimilarity {
  section: string;
  pairs: PairSimilarity[];
  averageIndex: number;
  highPairs: number;
}

const HIGH = 60;

export function wrongAnswerSimilarity(
  assessment: Assessment,
  scans: ScanResult[],
  students: Student[],
): SectionSimilarity[] {
  const key = keysForSet(assessment);
  const usable = scans.filter(
    (s) => s.assessmentId === assessment.id && !s.flags.includes("unreadable") && s.answers.length,
  );

  const bySection = new Map<string, ScanResult[]>();
  for (const scan of usable) {
    const st = students.find((x) => x.id === scan.studentId);
    const section = st?.section || scan.rollNumber ? (st?.section ?? "Unknown") : "Unknown";
    const arr = bySection.get(section) ?? [];
    arr.push(scan);
    bySection.set(section, arr);
  }

  const sections: SectionSimilarity[] = [];
  for (const [section, list] of bySection) {
    const pairs: PairSimilarity[] = [];
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const sa = list[i]!;
        const sb = list[j]!;
        let bothWrong = 0;
        let sharedWrong = 0;
        for (let q = 0; q < assessment.itemCount; q++) {
          const ka = key[q];
          const aa = sa.answers[q] ?? null;
          const ab = sb.answers[q] ?? null;
          if (!aa || !ab || !ka) continue;
          const wa = aa !== ka;
          const wb = ab !== ka;
          if (wa && wb) {
            bothWrong++;
            if (aa === ab) sharedWrong++;
          }
        }
        const index = bothWrong ? Math.round((sharedWrong / bothWrong) * 100) : 0;
        const sta = students.find((x) => x.id === sa.studentId);
        const stb = students.find((x) => x.id === sb.studentId);
        pairs.push({
          section,
          aId: sa.studentId ?? sa.id,
          bId: sb.studentId ?? sb.id,
          aName: sta?.fullName ?? `Roll ${sa.rollNumber}`,
          aRoll: sa.rollNumber,
          bName: stb?.fullName ?? `Roll ${sb.rollNumber}`,
          bRoll: sb.rollNumber,
          sharedWrong,
          bothWrong,
          index,
        });
      }
    }
    pairs.sort((x, y) => y.index - x.index || y.sharedWrong - x.sharedWrong);
    const avg = pairs.length ? pairs.reduce((p, n) => p + n.index, 0) / pairs.length : 0;
    sections.push({
      section,
      pairs,
      averageIndex: avg,
      highPairs: pairs.filter((p) => p.index >= HIGH && p.bothWrong >= 3).length,
    });
  }
  sections.sort((a, b) => a.section.localeCompare(b.section));
  return sections;
}
