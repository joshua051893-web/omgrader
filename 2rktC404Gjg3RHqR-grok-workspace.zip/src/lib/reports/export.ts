import * as XLSX from "xlsx";
import JSZip from "jszip";
import { db } from "@/lib/db/database";
import type { Assessment, ScanResult, Student } from "@/lib/types";
import { itemAnalysis, assessmentSummary } from "@/lib/gradebook/compute";
import { downloadBlob } from "@/lib/utils";

export function resultsWorkbook(assessment: Assessment, scans: ScanResult[], students: Student[]): ArrayBuffer {
  const rows = scans.map((s) => {
    const st = students.find((x) => x.id === s.studentId);
    return {
      "Roll No.": s.rollNumber,
      Student: st?.fullName ?? "",
      Score: `${s.score}/${assessment.itemCount}`,
      Percentage: Math.round(s.percentage),
      Correct: s.correct,
      Wrong: s.wrong,
      Blank: s.blank,
      Status: s.status,
      Flags: s.flags.join(", "),
    };
  });
  const ws = XLSX.utils.json_to_sheet(rows);
  const stats = itemAnalysis(assessment, scans);
  const itemRows = stats.map((st) => ({
    Item: st.item + 1,
    Key: st.key,
    Correct: st.correct,
    Wrong: st.wrong,
    Blank: st.blank,
    ...st.optionCounts,
    Difficulty: Math.round(st.difficulty * 100) / 100,
    "Most frequent wrong": st.mostWrong ?? "",
  }));
  const ws2 = XLSX.utils.json_to_sheet(itemRows);
  const summary = assessmentSummary(assessment, scans);
  const ws3 = XLSX.utils.json_to_sheet([summary]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Results");
  XLSX.utils.book_append_sheet(wb, ws2, "Item Analysis");
  XLSX.utils.book_append_sheet(wb, ws3, "Summary");
  return XLSX.write(wb, { type: "array", bookType: "xlsx" }) as ArrayBuffer;
}

export async function downloadAssessmentZip(assessment: Assessment): Promise<void> {
  const zip = new JSZip();
  const scans = await db.scans.where("assessmentId").equals(assessment.id).toArray();
  const students = await db.students.toArray();
  const xlsx = resultsWorkbook(assessment, scans, students);
  zip.file("results.xlsx", xlsx);
  const originals = zip.folder("Original Scans");
  const marked = zip.folder("Marked Papers");
  for (const s of scans) {
    if (s.originalBlobId) {
      const b = await db.blobs.get(s.originalBlobId);
      if (b) originals?.file(b.name || `${s.rollNumber}.png`, b.bytes);
    }
    if (s.markedBlobId) {
      const b = await db.blobs.get(s.markedBlobId);
      if (b) marked?.file(b.name || `${s.rollNumber}-marked.png`, b.bytes);
    }
  }
  const out = await zip.generateAsync({ type: "blob" });
  downloadBlob(out, `${assessment.name.replace(/\s+/g, "-")}-results.zip`);
}

export function arrayToCsv(rows: Record<string, unknown>[]): string {
  if (!rows.length) return "";
  const keys = Object.keys(rows[0]!);
  const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return [keys.join(","), ...rows.map((r) => keys.map((k) => esc(r[k])).join(","))].join("\n");
}
