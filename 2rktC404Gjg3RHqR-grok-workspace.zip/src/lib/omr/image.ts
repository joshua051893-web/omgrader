export async function loadImageElement(
  src: Blob | ImageBitmap | HTMLCanvasElement | HTMLImageElement,
): Promise<HTMLCanvasElement> {
  if (src instanceof HTMLCanvasElement) return src;
  if (typeof ImageBitmap !== "undefined" && src instanceof ImageBitmap) {
    return canvasFromBitmap(src);
  }
  if (src instanceof HTMLImageElement) {
    const c = document.createElement("canvas");
    c.width = src.naturalWidth || src.width;
    c.height = src.naturalHeight || src.height;
    c.getContext("2d")!.drawImage(src, 0, 0);
    return c;
  }
  const blob = src as Blob;
  try {
    const bmp = await createImageBitmap(blob, { imageOrientation: "from-image" } as ImageBitmapOptions);
    return canvasFromBitmap(bmp);
  } catch {
    try {
      const bmp = await createImageBitmap(blob);
      const oriented = await applyJpegExif(blob, canvasFromBitmap(bmp));
      return oriented;
    } catch {
      return loadViaImageTag(blob);
    }
  }
}

function canvasFromBitmap(src: ImageBitmap): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = src.width;
  c.height = src.height;
  c.getContext("2d")!.drawImage(src, 0, 0);
  src.close?.();
  return c;
}

function loadViaImageTag(blob: Blob): Promise<HTMLCanvasElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      const c = document.createElement("canvas");
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      c.getContext("2d")!.drawImage(img, 0, 0);
      URL.revokeObjectURL(url);
      resolve(c);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("The image file could not be opened. Try a JPEG or PNG scan."));
    };
    img.src = url;
  });
}

async function applyJpegExif(blob: Blob, canvas: HTMLCanvasElement): Promise<HTMLCanvasElement> {
  if (blob.type && !blob.type.includes("jpeg") && !blob.type.includes("jpg")) return canvas;
  const buf = await blob.arrayBuffer();
  const ori = jpegOrientation(buf);
  if (ori <= 1) return canvas;
  return rotateCanvas(canvas, ori);
}

function jpegOrientation(buf: ArrayBuffer): number {
  const view = new DataView(buf);
  if (view.byteLength < 4 || view.getUint16(0) !== 0xffd8) return 1;
  let offset = 2;
  while (offset + 4 < view.byteLength) {
    const marker = view.getUint16(offset);
    offset += 2;
    if (marker === 0xffe1) {
      const size = view.getUint16(offset);
      const start = offset + 2;
      if (start + 6 > view.byteLength) return 1;
      if (view.getUint32(start) !== 0x45786966) return 1;
      const tiff = start + 6;
      const little = view.getUint16(tiff) === 0x4949;
      const get16 = (o: number) => (little ? view.getUint16(o, true) : view.getUint16(o, false));
      const get32 = (o: number) => (little ? view.getUint32(o, true) : view.getUint32(o, false));
      const ifd = tiff + get32(tiff + 4);
      const n = get16(ifd);
      for (let i = 0; i < n; i++) {
        const e = ifd + 2 + i * 12;
        if (e + 12 > view.byteLength) break;
        if (get16(e) === 0x0112) return get16(e + 8);
      }
      return 1;
    }
    if ((marker & 0xff00) !== 0xff00) break;
    if (offset + 2 > view.byteLength) break;
    offset += view.getUint16(offset);
  }
  return 1;
}

function rotateCanvas(src: HTMLCanvasElement, orientation: number): HTMLCanvasElement {
  const c = document.createElement("canvas");
  const swap = orientation >= 5;
  c.width = swap ? src.height : src.width;
  c.height = swap ? src.width : src.height;
  const ctx = c.getContext("2d")!;
  switch (orientation) {
    case 2:
      ctx.translate(c.width, 0);
      ctx.scale(-1, 1);
      break;
    case 3:
      ctx.translate(c.width, c.height);
      ctx.rotate(Math.PI);
      break;
    case 4:
      ctx.translate(0, c.height);
      ctx.scale(1, -1);
      break;
    case 5:
      ctx.rotate(0.5 * Math.PI);
      ctx.scale(1, -1);
      break;
    case 6:
      ctx.rotate(0.5 * Math.PI);
      ctx.translate(0, -src.height);
      break;
    case 7:
      ctx.rotate(0.5 * Math.PI);
      ctx.translate(c.height, -src.height);
      ctx.scale(-1, 1);
      break;
    case 8:
      ctx.rotate(-0.5 * Math.PI);
      ctx.translate(-src.width, 0);
      break;
    default:
      break;
  }
  ctx.drawImage(src, 0, 0);
  return c;
}

export function toGrayscale(canvas: HTMLCanvasElement): { data: Uint8ClampedArray; width: number; height: number } {
  const ctx = canvas.getContext("2d", { willReadFrequently: true })!;
  const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const g = new Uint8ClampedArray(img.width * img.height);
  for (let i = 0, p = 0; i < img.data.length; i += 4, p++) {
    g[p] = (img.data[i]! * 0.299 + img.data[i + 1]! * 0.587 + img.data[i + 2]! * 0.114) | 0;
  }
  return { data: g, width: img.width, height: img.height };
}

export function otsuThreshold(gray: Uint8ClampedArray): number {
  const hist = new Array(256).fill(0);
  for (let i = 0; i < gray.length; i++) hist[gray[i]!]++;
  const total = gray.length;
  let sum = 0;
  for (let t = 0; t < 256; t++) sum += t * hist[t];
  let sumB = 0;
  let wB = 0;
  let max = 0;
  let thresh = 127;
  for (let t = 0; t < 256; t++) {
    wB += hist[t];
    if (wB === 0) continue;
    const wF = total - wB;
    if (wF === 0) break;
    sumB += t * hist[t];
    const mB = sumB / wB;
    const mF = (sum - sumB) / wF;
    const between = wB * wF * (mB - mF) * (mB - mF);
    if (between > max) {
      max = between;
      thresh = t;
    }
  }
  return thresh;
}

export function downsampleGray(
  gray: Uint8ClampedArray,
  width: number,
  height: number,
  maxSide = 1400,
): { data: Uint8ClampedArray; width: number; height: number; scale: number } {
  const scale = Math.min(1, maxSide / Math.max(width, height));
  if (scale >= 0.99) return { data: gray, width, height, scale: 1 };
  const w = Math.max(2, Math.round(width * scale));
  const h = Math.max(2, Math.round(height * scale));
  const out = new Uint8ClampedArray(w * h);
  for (let y = 0; y < h; y++) {
    const sy = Math.min(height - 1, ((y + 0.5) / h) * height);
    const y0 = sy | 0;
    for (let x = 0; x < w; x++) {
      const sx = Math.min(width - 1, ((x + 0.5) / w) * width);
      const x0 = sx | 0;
      out[y * w + x] = gray[y0 * width + x0]!;
    }
  }
  return { data: out, width: w, height: h, scale };
}
