import type { Pt } from "@/lib/omr/geometry";
import { otsuThreshold, downsampleGray } from "@/lib/omr/image";

interface Blob {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
  area: number;
  cx: number;
  cy: number;
}

export type Corners = { tl: Pt; tr: Pt; bl: Pt; br: Pt };

export function findFiducials(
  gray: Uint8ClampedArray,
  width: number,
  height: number,
  opts: { orient?: boolean } = {},
): Corners | null {
  const small = downsampleGray(gray, width, height, 1400);
  const t = otsuThreshold(small.data);
  const bin = new Uint8Array(small.data.length);
  for (let i = 0; i < small.data.length; i++) bin[i] = small.data[i]! < t * 0.78 ? 1 : 0;

  const blobs = connectedSquares(bin, small.width, small.height);
  const minA = small.width * small.height * 0.00008;
  const maxA = small.width * small.height * 0.045;
  const squares = blobs.filter((b) => {
    const w = b.maxX - b.minX + 1;
    const h = b.maxY - b.minY + 1;
    const aspect = w / h;
    const fill = b.area / (w * h);
    return b.area >= minA && b.area <= maxA && aspect > 0.62 && aspect < 1.5 && fill > 0.38;
  });
  if (squares.length < 4) return null;

  squares.sort((a, b) => b.area - a.area);
  const candidates = squares.slice(0, 12);
  const picked = pickFourCorners(candidates, small.width, small.height);
  if (!picked) return null;

  const inv = 1 / small.scale;
  const raw: Corners = {
    tl: { x: picked.tl.cx * inv, y: picked.tl.cy * inv },
    tr: { x: picked.tr.cx * inv, y: picked.tr.cy * inv },
    bl: { x: picked.bl.cx * inv, y: picked.bl.cy * inv },
    br: { x: picked.br.cx * inv, y: picked.br.cy * inv },
  };
  return opts.orient === false ? raw : orientByHollow(gray, width, height, raw) ?? raw;
}

export function rotateCorners(c: Corners, turns: number): Corners {
  const t = ((turns % 4) + 4) % 4;
  if (t === 0) return c;
  if (t === 1) return { tl: c.bl, tr: c.tl, br: c.tr, bl: c.br };
  if (t === 2) return { tl: c.br, tr: c.bl, br: c.tl, bl: c.tr };
  return { tl: c.tr, tr: c.br, br: c.bl, bl: c.tl };
}

function holeScore(gray: Uint8ClampedArray, width: number, height: number, p: Pt, r: number) {
  let inner = 0;
  let innerN = 0;
  let ring = 0;
  let ringN = 0;
  const r2 = r * r;
  const innerR = r * 0.42;
  const innerR2 = innerR * innerR;
  const x0 = Math.max(0, (p.x - r) | 0);
  const x1 = Math.min(width - 1, (p.x + r) | 0);
  const y0 = Math.max(0, (p.y - r) | 0);
  const y1 = Math.min(height - 1, (p.y + r) | 0);
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const dx = x - p.x;
      const dy = y - p.y;
      const d2 = dx * dx + dy * dy;
      if (d2 > r2) continue;
      const g = gray[y * width + x]!;
      if (d2 <= innerR2) {
        inner += g;
        innerN++;
      } else if (d2 > r2 * 0.45) {
        ring += g;
        ringN++;
      }
    }
  }
  if (!innerN || !ringN) return 0;
  return inner / innerN - ring / ringN;
}

function orientByHollow(gray: Uint8ClampedArray, width: number, height: number, raw: Corners): Corners | null {
  const pts = [raw.tl, raw.tr, raw.br, raw.bl];
  const span = Math.hypot(raw.tr.x - raw.tl.x, raw.tr.y - raw.tl.y);
  const r = Math.max(8, span * 0.045);
  const scores = pts.map((p) => holeScore(gray, width, height, p, r));
  const max = Math.max(...scores);
  const second = scores.slice().sort((a, b) => b - a)[1] ?? -999;
  if (max < 12 || max - second < 8) return null;
  const hollow = pts[scores.indexOf(max)]!;
  const cx = (raw.tl.x + raw.tr.x + raw.br.x + raw.bl.x) / 4;
  const cy = (raw.tl.y + raw.tr.y + raw.br.y + raw.bl.y) / 4;
  const ring = pts.slice().sort((a, b) => Math.atan2(a.y - cy, a.x - cx) - Math.atan2(b.y - cy, b.x - cx));
  const i = ring.findIndex((p) => p === hollow);
  if (i < 0) return null;
  return {
    tr: ring[i]!,
    br: ring[(i + 1) % 4]!,
    bl: ring[(i + 2) % 4]!,
    tl: ring[(i + 3) % 4]!,
  };
}

function pickFourCorners(blobs: Blob[], width: number, height: number) {
  if (blobs.length < 4) return null;
  const scored = blobs.map((b) => ({
    b,
    tl: b.cx + b.cy,
    tr: width - b.cx + b.cy,
    bl: b.cx + (height - b.cy),
    br: width - b.cx + (height - b.cy),
  }));
  const tl = scored.reduce((a, c) => (c.tl < a.tl ? c : a)).b;
  const tr = scored.reduce((a, c) => (c.tr < a.tr ? c : a)).b;
  const bl = scored.reduce((a, c) => (c.bl < a.bl ? c : a)).b;
  const br = scored.reduce((a, c) => (c.br < a.br ? c : a)).b;
  const set = new Set([tl, tr, bl, br]);
  if (set.size < 4) return largestQuad(blobs);
  return { tl, tr, bl, br };
}

function largestQuad(blobs: Blob[]) {
  if (blobs.length < 4) return null;
  const take = blobs.slice(0, Math.min(8, blobs.length));
  let best: { tl: Blob; tr: Blob; bl: Blob; br: Blob } | null = null;
  let bestA = 0;
  for (let i = 0; i < take.length; i++) {
    for (let j = i + 1; j < take.length; j++) {
      for (let k = j + 1; k < take.length; k++) {
        for (let m = k + 1; m < take.length; m++) {
          const four = [take[i]!, take[j]!, take[k]!, take[m]!];
          const cx = four.reduce((s, b) => s + b.cx, 0) / 4;
          const cy = four.reduce((s, b) => s + b.cy, 0) / 4;
          const ring = four.slice().sort((a, b) => Math.atan2(a.cy - cy, a.cx - cx) - Math.atan2(b.cy - cy, b.cx - cx));
          const area = Math.abs(
            ring.reduce((s, p, n) => {
              const q = ring[(n + 1) % 4]!;
              return s + p.cx * q.cy - q.cx * p.cy;
            }, 0) / 2,
          );
          if (area > bestA) {
            bestA = area;
            const top = ring.slice().sort((a, b) => a.cy - b.cy || a.cx - b.cx);
            const tl = top[0]!.cx < top[1]!.cx ? top[0]! : top[1]!;
            const tr = top[0]!.cx < top[1]!.cx ? top[1]! : top[0]!;
            const bot = ring.filter((b) => b !== tl && b !== tr);
            const bl = bot[0]!.cx < bot[1]!.cx ? bot[0]! : bot[1]!;
            const br = bot[0]!.cx < bot[1]!.cx ? bot[1]! : bot[0]!;
            best = { tl, tr, bl, br };
          }
        }
      }
    }
  }
  return best;
}

function connectedSquares(bin: Uint8Array, width: number, height: number): Blob[] {
  const seen = new Uint8Array(bin.length);
  const blobs: Blob[] = [];
  const qx: number[] = [];
  const qy: number[] = [];
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = y * width + x;
      if (!bin[i] || seen[i]) continue;
      qx.length = 0;
      qy.length = 0;
      qx.push(x);
      qy.push(y);
      seen[i] = 1;
      let minX = x,
        minY = y,
        maxX = x,
        maxY = y,
        area = 0,
        sx = 0,
        sy = 0;
      while (qx.length) {
        const cx = qx.pop()!;
        const cy = qy.pop()!;
        area++;
        sx += cx;
        sy += cy;
        if (cx < minX) minX = cx;
        if (cy < minY) minY = cy;
        if (cx > maxX) maxX = cx;
        if (cy > maxY) maxY = cy;
        for (const [dx, dy] of [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ] as const) {
          const nx = cx + dx;
          const ny = cy + dy;
          if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
          const ni = ny * width + nx;
          if (bin[ni] && !seen[ni]) {
            seen[ni] = 1;
            qx.push(nx);
            qy.push(ny);
          }
        }
      }
      if (area > 20) {
        blobs.push({ minX, minY, maxX, maxY, area, cx: sx / area, cy: sy / area });
      }
    }
  }
  return blobs;
}
