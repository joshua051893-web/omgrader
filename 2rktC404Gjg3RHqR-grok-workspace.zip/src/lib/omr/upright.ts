import type { Corners } from "@/lib/omr/fiducials";
import { findFiducials } from "@/lib/omr/fiducials";
import { toGrayscale } from "@/lib/omr/image";
import type { Pt } from "@/lib/omr/geometry";

export function rotateCanvasTurns(src: HTMLCanvasElement, turns: number): HTMLCanvasElement {
  const t = ((turns % 4) + 4) % 4;
  if (t === 0) return src;
  const out = document.createElement("canvas");
  out.width = t === 2 ? src.width : src.height;
  out.height = t === 2 ? src.height : src.width;
  const ctx = out.getContext("2d")!;
  if (t === 1) {
    ctx.translate(out.width, 0);
    ctx.rotate(Math.PI / 2);
  } else if (t === 2) {
    ctx.translate(out.width, out.height);
    ctx.rotate(Math.PI);
  } else {
    ctx.translate(0, out.height);
    ctx.rotate(-Math.PI / 2);
  }
  ctx.drawImage(src, 0, 0);
  return out;
}

export function mapPtTurns(p: Pt, w: number, h: number, turns: number): Pt {
  const t = ((turns % 4) + 4) % 4;
  if (t === 0) return p;
  if (t === 1) return { x: h - p.y, y: p.x };
  if (t === 2) return { x: w - p.x, y: h - p.y };
  return { x: p.y, y: w - p.x };
}

function mapCorners(c: Corners, w: number, h: number, turns: number): Corners {
  return {
    tl: mapPtTurns(c.tl, w, h, turns),
    tr: mapPtTurns(c.tr, w, h, turns),
    bl: mapPtTurns(c.bl, w, h, turns),
    br: mapPtTurns(c.br, w, h, turns),
  };
}

function uprightScore(c: Corners) {
  const ang = Math.atan2(c.tr.y - c.tl.y, c.tr.x - c.tl.x);
  const topDown = (c.tl.y + c.tr.y) / 2 < (c.bl.y + c.br.y) / 2;
  const leftRight = (c.tl.x + c.bl.x) / 2 < (c.tr.x + c.br.x) / 2;
  return Math.abs(ang) + (topDown ? 0 : 4) + (leftRight ? 0 : 4);
}

export function uprightForReview(src: HTMLCanvasElement): { canvas: HTMLCanvasElement; corners: Corners | null } {
  const gray = toGrayscale(src);
  const found = findFiducials(gray.data, gray.width, gray.height);
  if (!found) return { canvas: src, corners: null };

  let bestTurns = 0;
  let best = uprightScore(found);
  for (let t = 1; t < 4; t++) {
    const mapped = mapCorners(found, src.width, src.height, t);
    const s = uprightScore(mapped);
    if (s < best) {
      best = s;
      bestTurns = t;
    }
  }
  const canvas = rotateCanvasTurns(src, bestTurns);
  const corners = mapCorners(found, src.width, src.height, bestTurns);
  return { canvas, corners };
}
