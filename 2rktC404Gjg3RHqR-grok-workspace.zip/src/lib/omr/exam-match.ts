import type { Assessment, ScanResult, Student } from "@/lib/types";
import { examCodeFor, sanitizeExamCode } from "@/lib/sheets/exam-code";
import { padRoll } from "@/lib/utils";

export function codesMatch(a: string, b: string) {
  const x = sanitizeExamCode(a);
  const y = sanitizeExamCode(b);
  if (!x || !y) return false;
  return x === y || x.startsWith(y) || y.startsWith(x);
}

export function findAssessmentByExamCode(code: string | null | undefined, assessments: Assessment[]): Assessment | null {
  if (!code) return null;
  const exact = assessments.find((a) => examCodeFor(a) === sanitizeExamCode(code));
  if (exact) return exact;
  return assessments.find((a) => codesMatch(examCodeFor(a), code)) ?? null;
}

export type ExamMatch =
  | { kind: "ok"; assessment: Assessment }
  | { kind: "wrong_exam"; assessment: Assessment; code: string }
  | { kind: "wrong_section"; assessment: Assessment; code: string }
  | { kind: "unknown"; code: string }
  | { kind: "none" };

export function matchScannedExam(code: string | null, current: Assessment, assessments: Assessment[]): ExamMatch {
  if (!code) return { kind: "none" };
  const found = findAssessmentByExamCode(code, assessments);
  if (!found) return { kind: "unknown", code };
  if (found.id === current.id) return { kind: "ok", assessment: found };
  const sameTest =
    found.name.trim().toLowerCase() === current.name.trim().toLowerCase() &&
    found.subject.trim().toLowerCase() === current.subject.trim().toLowerCase();
  const sectionDiff = found.gradeLevel !== current.gradeLevel || found.section !== current.section;
  if (sameTest && sectionDiff) return { kind: "wrong_section", assessment: found, code };
  return { kind: "wrong_exam", assessment: found, code };
}

export function findDuplicateScan(
  scans: ScanResult[],
  assessmentId: string,
  rollNumber: string,
  studentId: string | null,
  digits = 3,
): ScanResult | undefined {
  const roll = padRoll(rollNumber, digits);
  if (!roll && !studentId) return undefined;
  return scans.find((s) => {
    if (s.assessmentId !== assessmentId) return false;
    if (studentId && s.studentId === studentId) return true;
    return Boolean(roll) && padRoll(s.rollNumber, digits) === roll;
  });
}

export function studentInClass(student: Student, assessment: Assessment) {
  return student.gradeLevel === assessment.gradeLevel && student.section === assessment.section;
}

export function findStudentByRoll(students: Student[], rollNumber: string, digits = 3, prefer?: Assessment) {
  const roll = padRoll(rollNumber, digits);
  if (!roll) return undefined;
  if (prefer) {
    const inClass = students.find(
      (s) => studentInClass(s, prefer) && padRoll(s.rollNumber, digits) === roll,
    );
    if (inClass) return inClass;
  }
  return students.find((s) => padRoll(s.rollNumber, digits) === roll);
}

export function matchingAssessmentForStudent(
  student: Student,
  current: Assessment,
  assessments: Assessment[],
): Assessment | null {
  const sameQuiz = assessments.filter(
    (a) =>
      a.name.trim().toLowerCase() === current.name.trim().toLowerCase() &&
      a.subject.trim().toLowerCase() === current.subject.trim().toLowerCase() &&
      (a.testSet ?? "A") === (current.testSet ?? "A") &&
      studentInClass(student, a),
  );
  return sameQuiz[0] ?? assessments.find((a) => studentInClass(student, a)) ?? null;
}
