export type Pt = { x: number; y: number };

export function solveHomography(src: Pt[], dst: Pt[]): number[] | null {
  if (src.length < 4 || dst.length < 4) return null;
  const A: number[][] = [];
  const b: number[] = [];
  for (let i = 0; i < 4; i++) {
    const s = src[i]!;
    const d = dst[i]!;
    A.push([s.x, s.y, 1, 0, 0, 0, -d.x * s.x, -d.x * s.y]);
    b.push(d.x);
    A.push([0, 0, 0, s.x, s.y, 1, -d.y * s.x, -d.y * s.y]);
    b.push(d.y);
  }
  const h = gaussianSolve(A, b);
  if (!h) return null;
  h.push(1);
  return h;
}

function gaussianSolve(A: number[][], b: number[]): number[] | null {
  const n = b.length;
  const M = A.map((row, i) => [...row, b[i]!]);
  for (let col = 0; col < n; col++) {
    let pivot = col;
    for (let r = col + 1; r < n; r++) {
      if (Math.abs(M[r]![col]!) > Math.abs(M[pivot]![col]!)) pivot = r;
    }
    const tmp = M[col]!;
    M[col] = M[pivot]!;
    M[pivot] = tmp;
    const div = M[col]![col]!;
    if (Math.abs(div) < 1e-12) return null;
    for (let c = col; c <= n; c++) M[col]![c]! /= div;
    for (let r = 0; r < n; r++) {
      if (r === col) continue;
      const f = M[r]![col]!;
      for (let c = col; c <= n; c++) M[r]![c]! -= f * M[col]![c]!;
    }
  }
  return M.map((row) => row[n]!);
}

export function applyH(h: number[], x: number, y: number): Pt {
  const w = h[6]! * x + h[7]! * y + h[8]!;
  return {
    x: (h[0]! * x + h[1]! * y + h[2]!) / w,
    y: (h[3]! * x + h[4]! * y + h[5]!) / w,
  };
}

export function warpToCanvas(
  src: HTMLCanvasElement,
  h: number[],
  width: number,
  height: number,
): HTMLCanvasElement {
  const out = document.createElement("canvas");
  out.width = width;
  out.height = height;
  const sctx = src.getContext("2d", { willReadFrequently: true })!;
  const srcData = sctx.getImageData(0, 0, src.width, src.height);
  const dctx = out.getContext("2d")!;
  const dst = dctx.createImageData(width, height);
  const inv = invertH(h);
  if (!inv) return out;
  const sw = src.width;
  const sh = src.height;
  const sbuf = srcData.data;
  const dbuf = dst.data;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const p = applyH(inv, x + 0.5, y + 0.5);
      if (p.x < 0 || p.y < 0 || p.x >= sw - 1 || p.y >= sh - 1) continue;
      const x0 = p.x | 0;
      const y0 = p.y | 0;
      const fx = p.x - x0;
      const fy = p.y - y0;
      const i00 = (y0 * sw + x0) * 4;
      const i10 = i00 + 4;
      const i01 = i00 + sw * 4;
      const i11 = i01 + 4;
      const di = (y * width + x) * 4;
      for (let c = 0; c < 3; c++) {
        const v =
          sbuf[i00 + c]! * (1 - fx) * (1 - fy) +
          sbuf[i10 + c]! * fx * (1 - fy) +
          sbuf[i01 + c]! * (1 - fx) * fy +
          sbuf[i11 + c]! * fx * fy;
        dbuf[di + c] = v | 0;
      }
      dbuf[di + 3] = 255;
    }
  }
  dctx.putImageData(dst, 0, 0);
  return out;
}

export function invertH(h: number[]): number[] | null {
  const m = [
    [h[0]!, h[1]!, h[2]!],
    [h[3]!, h[4]!, h[5]!],
    [h[6]!, h[7]!, h[8]!],
  ];
  const det =
    m[0]![0]! * (m[1]![1]! * m[2]![2]! - m[1]![2]! * m[2]![1]!) -
    m[0]![1]! * (m[1]![0]! * m[2]![2]! - m[1]![2]! * m[2]![0]!) +
    m[0]![2]! * (m[1]![0]! * m[2]![1]! - m[1]![1]! * m[2]![0]!);
  if (Math.abs(det) < 1e-12) return null;
  const i00 = (m[1]![1]! * m[2]![2]! - m[1]![2]! * m[2]![1]!) / det;
  const i01 = (m[0]![2]! * m[2]![1]! - m[0]![1]! * m[2]![2]!) / det;
  const i02 = (m[0]![1]! * m[1]![2]! - m[0]![2]! * m[1]![1]!) / det;
  const i10 = (m[1]![2]! * m[2]![0]! - m[1]![0]! * m[2]![2]!) / det;
  const i11 = (m[0]![0]! * m[2]![2]! - m[0]![2]! * m[2]![0]!) / det;
  const i12 = (m[0]![2]! * m[1]![0]! - m[0]![0]! * m[1]![2]!) / det;
  const i20 = (m[1]![0]! * m[2]![1]! - m[1]![1]! * m[2]![0]!) / det;
  const i21 = (m[0]![1]! * m[2]![0]! - m[0]![0]! * m[2]![1]!) / det;
  const i22 = (m[0]![0]! * m[1]![1]! - m[0]![1]! * m[1]![0]!) / det;
  return [i00, i01, i02, i10, i11, i12, i20, i21, i22];
}
