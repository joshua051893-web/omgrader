import type { Assessment, ScanFlag, ScanResult, ScanStatus, Student } from "@/lib/types";
import { keysForSet } from "@/lib/types";
import { buildLayout } from "@/lib/sheets/layout";
import { findFiducials, rotateCorners, type Corners } from "@/lib/omr/fiducials";
import { applyH, invertH, solveHomography, warpToCanvas, type Pt } from "@/lib/omr/geometry";
import { loadImageElement, toGrayscale } from "@/lib/omr/image";
import { examCodeFor, readExamCodeFromImage } from "@/lib/sheets/exam-code";
import { nowIso, padRoll, uid } from "@/lib/utils";

export interface DetectedAnswer {
  item: number;
  choice: string | null;
  confidence: number;
  multiple: boolean;
  unclear: boolean;
  fillRatios: Record<string, number>;
}

export interface OmRDetection {
  warped: HTMLCanvasElement;
  rollNumber: string;
  rollConfidence: number;
  answers: DetectedAnswer[];
  flags: ScanFlag[];
  confidence: number;
  valid: boolean;
  examCode: string | null;
}

export interface DetectOpts {
  corners?: Corners;
  offsetMm?: { x: number; y: number };
}

export async function detectSheet(
  source: Blob | HTMLCanvasElement,
  assessment: Assessment,
  opts: DetectOpts = {},
): Promise<OmRDetection> {
  const expectedCode = examCodeFor(assessment);
  const cfg = { ...assessment.sheetConfig, itemCount: assessment.itemCount, examCode: expectedCode };
  const layout = buildLayout(cfg);
  const canvas = await loadImageElement(source);
  const gray = toGrayscale(canvas);
  let corners = opts.corners ?? findFiducials(gray.data, gray.width, gray.height);
  if (!corners) {
    return fail(canvas, ["unreadable", "invalid_sheet", "needs_review"]);
  }

  const fid = {
    TL: layout.fiducials.find((f) => f.id === "TL")!,
    TR: layout.fiducials.find((f) => f.id === "TR")!,
    BR: layout.fiducials.find((f) => f.id === "BR")!,
    BL: layout.fiducials.find((f) => f.id === "BL")!,
  };
  const scale = 5;
  const outW = Math.round(layout.widthMm * scale);
  const outH = Math.round(layout.heightMm * scale);
  const mm = (xMm: number, yMm: number): Pt => ({
    x: (xMm / layout.widthMm) * outW,
    y: (yMm / layout.heightMm) * outH,
  });
  const dstPts: Pt[] = [
    mm(fid.TL.x + fid.TL.size / 2, fid.TL.y + fid.TL.size / 2),
    mm(fid.TR.x + fid.TR.size / 2, fid.TR.y + fid.TR.size / 2),
    mm(fid.BR.x + fid.BR.size / 2, fid.BR.y + fid.BR.size / 2),
    mm(fid.BL.x + fid.BL.size / 2, fid.BL.y + fid.BL.size / 2),
  ];

  if (!opts.corners) {
    corners = bestOrientation(gray.data, gray.width, gray.height, corners, dstPts, layout, outW, outH);
  }

  const srcPts: Pt[] = [corners.tl, corners.tr, corners.br, corners.bl];
  const hPx = solveHomography(srcPts, dstPts);
  if (!hPx) return fail(canvas, ["unreadable", "needs_review"]);

  const warped = warpToCanvas(canvas, hPx, outW, outH);
  const wctx = warped.getContext("2d", { willReadFrequently: true })!;
  const wimg = wctx.getImageData(0, 0, outW, outH);

  const ox = opts.offsetMm?.x ?? 0;
  const oy = opts.offsetMm?.y ?? 0;
  const darknessAt = (mmX: number, mmY: number, rMm: number) => {
    const cx = ((mmX + ox) / layout.widthMm) * outW;
    const cy = ((mmY + oy) / layout.heightMm) * outH;
    const r = Math.max(2, (rMm / layout.widthMm) * outW * 0.55);
    let dark = 0;
    let n = 0;
    const r2 = r * r;
    for (let y = -r; y <= r; y++) {
      for (let x = -r; x <= r; x++) {
        if (x * x + y * y > r2) continue;
        const px = (cx + x) | 0;
        const py = (cy + y) | 0;
        if (px < 0 || py < 0 || px >= outW || py >= outH) continue;
        const i = (py * outW + px) * 4;
        const g = wimg.data[i]! * 0.299 + wimg.data[i + 1]! * 0.587 + wimg.data[i + 2]! * 0.114;
        dark += (255 - g) / 255;
        n++;
      }
    }
    return n ? dark / n : 0;
  };

  const flags: ScanFlag[] = [];
  const barcodePx = {
    x: (layout.barcode.x / layout.widthMm) * outW,
    y: (layout.barcode.y / layout.heightMm) * outH,
    w: (layout.barcode.w / layout.widthMm) * outW,
    h: (layout.barcode.h / layout.heightMm) * outH,
  };
  const readCode = readExamCodeFromImage(wimg.data, outW, outH, barcodePx);
  if (!readCode) {
    flags.push("exam_unreadable");
  } else if (readCode !== expectedCode && !expectedCode.startsWith(readCode) && !readCode.startsWith(expectedCode)) {
    flags.push("wrong_exam");
  }
  let roll = "";
  let rollConf = 1;
  if (layout.rollBubbles.length) {
    const digits = cfg.rollDigits;
    const chars: string[] = [];
    for (let d = 0; d < digits; d++) {
      const col = layout.rollBubbles.filter((b) => b.digitIndex === d);
      const scores = col.map((b) => ({ v: b.value, s: darknessAt(b.cx, b.cy, b.r) }));
      scores.sort((a, b) => b.s - a.s);
      const top = scores[0]!;
      const second = scores[1] ?? { s: 0, v: 0 };
      if (top.s < 0.38) {
        chars.push("?");
        rollConf *= 0.4;
        flags.push("unclear_bubble");
      } else if (top.s - second.s < 0.12) {
        chars.push("?");
        rollConf *= 0.5;
        flags.push("unclear_bubble");
      } else {
        chars.push(String(top.v));
        rollConf *= Math.min(1, 0.55 + top.s);
      }
    }
    roll = chars.join("");
    if (roll.includes("?")) flags.push("unknown_roll");
  }

  const answers: DetectedAnswer[] = [];
  const byItem = new Map<number, typeof layout.answerBubbles>();
  for (const b of layout.answerBubbles) {
    const arr = byItem.get(b.item) ?? [];
    arr.push(b);
    byItem.set(b.item, arr);
  }
  let confAcc = 0;
  for (let i = 0; i < assessment.itemCount; i++) {
    const bubbles = byItem.get(i) ?? [];
    const fillRatios: Record<string, number> = {};
    const scored = bubbles.map((b) => {
      const s = darknessAt(b.cx, b.cy, b.r);
      fillRatios[b.choice] = s;
      return { choice: b.choice, s };
    });
    scored.sort((a, b) => b.s - a.s);
    const top = scored[0];
    const second = scored[1];
    let choice: string | null = null;
    let multiple = false;
    let unclear = false;
    let c = 0.9;
    if (!top || top.s < 0.34) {
      choice = null;
      c = 0.85;
    } else if (second && second.s > 0.34 && top.s - second.s < 0.1) {
      multiple = true;
      unclear = true;
      choice = top.choice;
      c = 0.35;
      flags.push("multiple_answers");
    } else if (top.s < 0.42) {
      unclear = true;
      choice = top.choice;
      c = 0.45;
      flags.push("unclear_bubble");
    } else {
      choice = top.choice;
      c = Math.min(0.99, 0.5 + top.s);
    }
    confAcc += c;
    answers.push({ item: i, choice, confidence: c, multiple, unclear, fillRatios });
  }

  const unique = Array.from(new Set(flags));
  if (unique.length) unique.push("needs_review");

  return {
    warped,
    rollNumber: roll.includes("?") ? roll : padRoll(roll, cfg.rollDigits),
    rollConfidence: rollConf,
    answers,
    flags: Array.from(new Set(unique)),
    confidence: answers.length ? confAcc / answers.length : 0,
    valid: true,
    examCode: readCode,
  };
}

function fail(canvas: HTMLCanvasElement, flags: ScanFlag[]): OmRDetection {
  return {
    warped: canvas,
    rollNumber: "",
    rollConfidence: 0,
    answers: [],
    flags,
    confidence: 0,
    valid: false,
    examCode: null,
  };
}

function bestOrientation(
  gray: Uint8ClampedArray,
  width: number,
  height: number,
  seed: Corners,
  dstPts: Pt[],
  layout: ReturnType<typeof buildLayout>,
  outW: number,
  outH: number,
): Corners {
  let best = seed;
  let bestScore = -Infinity;
  for (let t = 0; t < 4; t++) {
    const c = rotateCorners(seed, t);
    const s = scoreOrientation(gray, width, height, c, dstPts, layout, outW, outH);
    if (s > bestScore) {
      bestScore = s;
      best = c;
    }
  }
  return best;
}

function scoreOrientation(
  gray: Uint8ClampedArray,
  width: number,
  height: number,
  corners: Corners,
  dstPts: Pt[],
  layout: ReturnType<typeof buildLayout>,
  outW: number,
  outH: number,
): number {
  const srcPts: Pt[] = [corners.tl, corners.tr, corners.br, corners.bl];
  const h = solveHomography(srcPts, dstPts);
  if (!h) return -1e9;
  const inv = invertH(h);
  if (!inv) return -1e9;

  const sample = (mmX: number, mmY: number, rMm: number) => {
    const dx = (mmX / layout.widthMm) * outW;
    const dy = (mmY / layout.heightMm) * outH;
    const r = Math.max(2, (rMm / layout.widthMm) * outW);
    let dark = 0;
    let n = 0;
    for (let y = -r; y <= r; y += 2) {
      for (let x = -r; x <= r; x += 2) {
        const p = applyH(inv, dx + x, dy + y);
        const sx = p.x | 0;
        const sy = p.y | 0;
        if (sx < 0 || sy < 0 || sx >= width || sy >= height) continue;
        dark += (255 - gray[sy * width + sx]!) / 255;
        n++;
      }
    }
    return n ? dark / n : 0;
  };

  const bar = layout.orientationBar;
  const barDark = sample(bar.x + bar.w / 2, bar.y + bar.h / 2, Math.max(bar.h, 2));
  const tr = layout.fiducials.find((f) => f.id === "TR")!;
  const tl = layout.fiducials.find((f) => f.id === "TL")!;
  const trHole = 1 - sample(tr.x + tr.size / 2, tr.y + tr.size / 2, tr.size * 0.16);
  const tlSolid = sample(tl.x + tl.size / 2, tl.y + tl.size / 2, tl.size * 0.16);
  const paper = 1 - sample(layout.widthMm * 0.5, layout.heightMm * 0.2, 6);
  return barDark * 5 + tlSolid * 2.2 + trHole * 3.2 + paper;
}

export function scoreDetection(
  assessment: Assessment,
  detection: OmRDetection,
  students: Student[],
  existingRolls: string[],
): Omit<ScanResult, "id" | "originalBlobId" | "markedBlobId" | "createdAt" | "updatedAt"> {
  const flags = [...detection.flags];
  const key = keysForSet(assessment);
  const answers = detection.answers.map((a) => (a.multiple ? null : a.choice));
  let correct = 0;
  let wrong = 0;
  let blank = 0;
  for (let i = 0; i < assessment.itemCount; i++) {
    const a = answers[i] ?? null;
    const k = key[i];
    if (!a) blank++;
    else if (k && a === k) correct++;
    else wrong++;
  }
  const score = correct;
  const percentage = assessment.itemCount ? (correct / assessment.itemCount) * 100 : 0;
  const roll = detection.rollNumber.replace(/\?/g, "");
  const padded = padRoll(roll, assessment.sheetConfig.rollDigits);
  const inClass = students.filter(
    (s) => s.gradeLevel === assessment.gradeLevel && s.section === assessment.section,
  );
  const student = inClass.find((s) => padRoll(s.rollNumber, assessment.sheetConfig.rollDigits) === padded);
  if (!roll || detection.rollNumber.includes("?")) flags.push("unknown_roll");
  if (roll && !student) flags.push("missing_student");
  const existingPadded = existingRolls.map((r) => padRoll(r, assessment.sheetConfig.rollDigits));
  if (padded && existingPadded.includes(padded)) flags.push("duplicate_roll");

  let status: ScanStatus = "pending";
  const uniq = Array.from(new Set(flags));
  if (uniq.includes("wrong_exam")) status = "flagged";
  else if (uniq.includes("unreadable") || uniq.includes("invalid_sheet")) status = "flagged";
  else if (uniq.length) status = "flagged";
  else if (score >= assessment.passingScore) status = "passed";
  else status = "failed";

  return {
    assessmentId: assessment.id,
    studentId: student?.id ?? null,
    rollNumber: detection.rollNumber,
    answers,
    flags: uniq,
    score,
    correct,
    wrong,
    blank,
    percentage,
    status,
    confidence: detection.confidence,
    remarks: "",
    reviewed: false,
  };
}

export async function renderMarkedPaper(
  warped: HTMLCanvasElement,
  assessment: Assessment,
  result: Pick<ScanResult, "answers" | "score" | "percentage" | "correct" | "wrong" | "blank" | "rollNumber">,
  studentName?: string,
): Promise<HTMLCanvasElement> {
  const cfg = { ...assessment.sheetConfig, itemCount: assessment.itemCount };
  const layout = buildLayout(cfg);
  const key = keysForSet(assessment);
  const out = document.createElement("canvas");
  out.width = warped.width;
  out.height = warped.height;
  const ctx = out.getContext("2d")!;
  ctx.drawImage(warped, 0, 0);
  const sx = out.width / layout.widthMm;
  const sy = out.height / layout.heightMm;

  const byItem = new Map<number, typeof layout.answerBubbles>();
  for (const b of layout.answerBubbles) {
    const arr = byItem.get(b.item) ?? [];
    arr.push(b);
    byItem.set(b.item, arr);
  }
  for (let i = 0; i < assessment.itemCount; i++) {
    const studentAns = result.answers[i] ?? null;
    const k = key[i];
    const bubbles = byItem.get(i) ?? [];
    for (const b of bubbles) {
      const x = b.cx * sx;
      const y = b.cy * sy;
      const r = b.r * sx * 1.15;
      if (k && b.choice === k) {
        ctx.strokeStyle = "#1f6b4a";
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.stroke();
      }
      if (studentAns && b.choice === studentAns && studentAns !== k) {
        ctx.strokeStyle = "#9f2d2d";
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.moveTo(x - r, y - r);
        ctx.lineTo(x + r, y + r);
        ctx.moveTo(x + r, y - r);
        ctx.lineTo(x - r, y + r);
        ctx.stroke();
      }
    }
  }

  ctx.fillStyle = "rgba(28,25,23,0.9)";
  ctx.fillRect(0, 0, out.width, Math.max(48, out.height * 0.07));
  ctx.fillStyle = "#fbfaf6";
  ctx.font = `600 ${Math.round(out.width * 0.022)}px IBM Plex Sans, sans-serif`;
  const title = `${studentName || "Student"}  ·  Roll ${result.rollNumber}  ·  ${result.score}/${assessment.itemCount}  (${result.percentage.toFixed(0)}%)`;
  ctx.fillText(title, 16, Math.round(out.height * 0.045));
  ctx.font = `400 ${Math.round(out.width * 0.016)}px IBM Plex Sans, sans-serif`;
  ctx.fillText(
    `Correct ${result.correct}   Wrong ${result.wrong}   Blank ${result.blank}   ${assessment.name} Set ${assessment.testSet ?? "A"}`,
    16,
    Math.round(out.height * 0.062),
  );
  return out;
}

export function newScanId() {
  return uid("scan");
}

export { nowIso };
