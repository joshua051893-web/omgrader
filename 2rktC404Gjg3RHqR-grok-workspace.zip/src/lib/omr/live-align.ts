import type { Pt } from "@/lib/omr/geometry";
import { findFiducials } from "@/lib/omr/fiducials";
import { toGrayscale } from "@/lib/omr/image";

export type CornerId = "tl" | "tr" | "bl" | "br";

export interface GuideRect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface AlignFrame {
  corners: Record<CornerId, Pt | null>;
  hits: Record<CornerId, boolean>;
  locked: boolean;
  fill: number;
  message: string;
}

const ORDER: CornerId[] = ["tl", "tr", "br", "bl"];

export function videoLetterbox(
  videoW: number,
  videoH: number,
  canvasW: number,
  canvasH: number,
) {
  const scale = Math.min(canvasW / videoW, canvasH / videoH);
  const w = videoW * scale;
  const h = videoH * scale;
  return { x: (canvasW - w) / 2, y: (canvasH - h) / 2, w, h, scale };
}

export function paperGuide(box: { x: number; y: number; w: number; h: number }, paperW: number, paperH: number): GuideRect {
  const aspect = paperW / Math.max(1, paperH);
  let h = box.h * 0.97;
  let w = h * aspect;
  if (w > box.w * 0.97) {
    w = box.w * 0.97;
    h = w / aspect;
  }
  return { x: box.x + (box.w - w) / 2, y: box.y + (box.h - h) / 2, w, h };
}

export function markerSquares(g: GuideRect, paperW: number, paperH: number) {
  const margin = Math.max(8, Math.min(paperW, paperH) * 0.04);
  const fid = Math.max(8, Math.min(12, paperW * 0.045));
  const sx = g.w / paperW;
  const sy = g.h / paperH;
  const s = Math.max(40, fid * sx * 2.2);
  return {
    tl: { x: g.x + margin * sx - (s - fid * sx) / 2, y: g.y + margin * sy - (s - fid * sy) / 2, s },
    tr: { x: g.x + g.w - margin * sx - fid * sx - (s - fid * sx) / 2, y: g.y + margin * sy - (s - fid * sy) / 2, s },
    bl: { x: g.x + margin * sx - (s - fid * sx) / 2, y: g.y + g.h - margin * sy - fid * sy - (s - fid * sy) / 2, s },
    br: {
      x: g.x + g.w - margin * sx - fid * sx - (s - fid * sx) / 2,
      y: g.y + g.h - margin * sy - fid * sy - (s - fid * sy) / 2,
      s,
    },
  };
}

function squareCenter(sq: { x: number; y: number; s: number }): Pt {
  return { x: sq.x + sq.s / 2, y: sq.y + sq.s / 2 };
}

function insideSquare(p: Pt, sq: { x: number; y: number; s: number }, pad = 0.55) {
  const extra = sq.s * pad;
  return p.x >= sq.x - extra && p.x <= sq.x + sq.s + extra && p.y >= sq.y - extra && p.y <= sq.y + sq.s + extra;
}

function dist(a: Pt, b: Pt) {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return Math.hypot(dx, dy);
}

export function detectOnCanvas(canvas: HTMLCanvasElement) {
  const gray = toGrayscale(canvas);
  return findFiducials(gray.data, gray.width, gray.height, { orient: false });
}

export function scoreAlignment(
  found: { tl: Pt; tr: Pt; bl: Pt; br: Pt } | null,
  guide: GuideRect,
  paperW: number,
  paperH: number,
): AlignFrame {
  const squares = markerSquares(guide, paperW, paperH);
  const empty: AlignFrame = {
    corners: { tl: null, tr: null, bl: null, br: null },
    hits: { tl: false, tr: false, bl: false, br: false },
    locked: false,
    fill: 0,
    message: "Place each black corner square inside a target square",
  };
  if (!found) return empty;

  const detected = [
    { id: "tl" as const, p: found.tl },
    { id: "tr" as const, p: found.tr },
    { id: "bl" as const, p: found.bl },
    { id: "br" as const, p: found.br },
  ];
  const used = new Set<string>();
  const corners: Record<CornerId, Pt | null> = { tl: null, tr: null, bl: null, br: null };
  const hits: Record<CornerId, boolean> = { tl: false, tr: false, bl: false, br: false };

  for (const id of ORDER) {
    const target = squares[id];
    const center = squareCenter(target);
    let best: { p: Pt; d: number; id: string } | null = null;
    for (const d of detected) {
      if (used.has(d.id)) continue;
      const dd = dist(d.p, center);
      if (!best || dd < best.d) best = { p: d.p, d: dd, id: d.id };
    }
    if (best) {
      used.add(best.id);
      corners[id] = best.p;
      hits[id] = insideSquare(best.p, target);
    }
  }

  const hitCount = ORDER.filter((k) => hits[k]).length;
  const xs = [found.tl.x, found.tr.x, found.bl.x, found.br.x];
  const ys = [found.tl.y, found.tr.y, found.bl.y, found.br.y];
  const fillW = Math.max(...xs) - Math.min(...xs);
  const fillH = Math.max(...ys) - Math.min(...ys);
  const fill = (fillW * fillH) / Math.max(1, guide.w * guide.h);
  const tooSmall = fill < 0.22;
  const tooBig = fill > 2.4;
  let message = `${hitCount}/4 markers in the squares`;
  if (tooSmall) message = "Move closer — fill the large frame with the paper";
  else if (tooBig) message = "Move back a little";
  else if (hitCount < 4) message = `Slide the remaining ${4 - hitCount} marker${hitCount === 3 ? "" : "s"} into the squares`;
  else message = "Locked — capturing…";

  const locked = hitCount === 4 && !tooSmall && !tooBig;
  return { corners, hits, locked, fill, message };
}

export function captureVideoFrame(video: HTMLVideoElement): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = video.videoWidth || 1280;
  c.height = video.videoHeight || 720;
  c.getContext("2d")!.drawImage(video, 0, 0, c.width, c.height);
  return c;
}

export function downsampleVideo(video: HTMLVideoElement, maxW = 480): HTMLCanvasElement {
  const vw = video.videoWidth || 640;
  const vh = video.videoHeight || 480;
  const scale = Math.min(1, maxW / vw);
  const c = document.createElement("canvas");
  c.width = Math.max(1, Math.round(vw * scale));
  c.height = Math.max(1, Math.round(vh * scale));
  c.getContext("2d")!.drawImage(video, 0, 0, c.width, c.height);
  return c;
}
