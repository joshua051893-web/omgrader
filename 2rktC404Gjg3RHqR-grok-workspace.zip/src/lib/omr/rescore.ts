import type { Assessment, ScanResult, ScanStatus } from "@/lib/types";
import { keysForSet } from "@/lib/types";
import { db } from "@/lib/db/database";
import { saveScan } from "@/lib/db/repo";

const HOLD_FLAGS = new Set([
  "unreadable",
  "invalid_sheet",
  "unknown_roll",
  "missing_student",
  "multiple_answers",
  "unclear_bubble",
  "wrong_exam",
]);

export function rescoreScan(assessment: Assessment, scan: ScanResult): ScanResult {
  const key = keysForSet(assessment);
  const answers = Array.from({ length: assessment.itemCount }, (_, i) => scan.answers[i] ?? null);
  let correct = 0;
  let wrong = 0;
  let blank = 0;
  for (let i = 0; i < assessment.itemCount; i++) {
    const a = answers[i] ?? null;
    const k = key[i];
    if (!a) blank++;
    else if (k && a === k) correct++;
    else wrong++;
  }
  const score = correct;
  const percentage = assessment.itemCount ? (correct / assessment.itemCount) * 100 : 0;
  const hold = scan.flags.some((f) => HOLD_FLAGS.has(f));
  const status: ScanStatus = hold ? "flagged" : score >= assessment.passingScore ? "passed" : "failed";
  return {
    ...scan,
    answers,
    score,
    correct,
    wrong,
    blank,
    percentage,
    status,
  };
}

export async function rescoreAssessmentScans(assessment: Assessment) {
  const scans = await db.scans.where("assessmentId").equals(assessment.id).toArray();
  for (const scan of scans) {
    await saveScan(rescoreScan(assessment, scan));
  }
  return scans.length;
}
