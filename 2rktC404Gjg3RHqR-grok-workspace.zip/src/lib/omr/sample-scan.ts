import { applyH, invertH, solveHomography, type Pt } from "@/lib/omr/geometry";
import { renderSheetCanvas } from "@/lib/sheets/render-canvas";
import { examCodeFor } from "@/lib/sheets/exam-code";
import { keysForSet, type Assessment, type Student } from "@/lib/types";

function sample(src: ImageData, x: number, y: number): [number, number, number] {
  const x0 = Math.max(0, Math.min(src.width - 2, Math.floor(x)));
  const y0 = Math.max(0, Math.min(src.height - 2, Math.floor(y)));
  const fx = x - x0;
  const fy = y - y0;
  const at = (ix: number, iy: number) => {
    const i = (iy * src.width + ix) * 4;
    return [src.data[i]!, src.data[i + 1]!, src.data[i + 2]!] as const;
  };
  const a = at(x0, y0);
  const b = at(x0 + 1, y0);
  const c = at(x0, y0 + 1);
  const d = at(x0 + 1, y0 + 1);
  const mix = (p: number, q: number, t: number) => p + (q - p) * t;
  return [
    mix(mix(a[0], b[0], fx), mix(c[0], d[0], fx), fy),
    mix(mix(a[1], b[1], fx), mix(c[1], d[1], fx), fy),
    mix(mix(a[2], b[2], fx), mix(c[2], d[2], fx), fy),
  ];
}

/** Photograph a sheet on a desk: trapezoid perspective + gentle paper buckle. */
export function photographSheet(src: HTMLCanvasElement): HTMLCanvasElement {
  const sw = src.width;
  const sh = src.height;
  const W = Math.round(sw * 1.24);
  const H = Math.round(sh * 1.18);
  const out = document.createElement("canvas");
  out.width = W;
  out.height = H;
  const ctx = out.getContext("2d")!;
  const desk = ctx.createLinearGradient(0, 0, W, H);
  desk.addColorStop(0, "#6a5340");
  desk.addColorStop(0.55, "#4a3a2c");
  desk.addColorStop(1, "#3a2d22");
  ctx.fillStyle = desk;
  ctx.fillRect(0, 0, W, H);
  const n = ctx.getImageData(0, 0, W, H);
  for (let i = 0; i < n.data.length; i += 4) {
    const k = (Math.random() - 0.5) * 18;
    n.data[i] = Math.max(0, n.data[i]! + k);
    n.data[i + 1] = Math.max(0, n.data[i + 1]! + k * 0.9);
    n.data[i + 2] = Math.max(0, n.data[i + 2]! + k * 0.7);
  }
  ctx.putImageData(n, 0, 0);

  const tl: Pt = { x: W * 0.09, y: H * 0.07 };
  const tr: Pt = { x: W * 0.96, y: H * 0.045 };
  const br: Pt = { x: W * 0.93, y: H * 0.97 };
  const bl: Pt = { x: W * 0.045, y: H * 0.91 };

  ctx.save();
  ctx.fillStyle = "rgba(20,12,8,0.35)";
  ctx.beginPath();
  ctx.moveTo(tl.x + 18, tl.y + 22);
  ctx.lineTo(tr.x + 16, tr.y + 24);
  ctx.lineTo(br.x + 14, br.y + 18);
  ctx.lineTo(bl.x + 20, bl.y + 16);
  ctx.closePath();
  ctx.filter = "blur(10px)";
  ctx.fill();
  ctx.restore();

  const h = solveHomography(
    [
      { x: 0, y: 0 },
      { x: sw, y: 0 },
      { x: sw, y: sh },
      { x: 0, y: sh },
    ],
    [tl, tr, br, bl],
  );
  const inv = h ? invertH(h) : null;
  if (!inv) return src;

  const sctx = src.getContext("2d", { willReadFrequently: true })!;
  const srcData = sctx.getImageData(0, 0, sw, sh);
  const img = ctx.getImageData(0, 0, W, H);

  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      let p = applyH(inv, x, y);
      const nx = x / W;
      const ny = y / H;
      p = {
        x: p.x + Math.sin(ny * Math.PI * 2.1) * 11 + Math.sin(nx * Math.PI * 3.2) * 4,
        y: p.y + Math.sin(nx * Math.PI * 1.7) * 9 + Math.sin(ny * Math.PI * 2.6) * 3,
      };
      if (p.x < 1 || p.y < 1 || p.x >= sw - 2 || p.y >= sh - 2) continue;
      const [r, g, b] = sample(srcData, p.x, p.y);
      const shade = 0.86 + 0.18 * nx - 0.08 * ny;
      const i = (y * W + x) * 4;
      img.data[i] = Math.max(0, Math.min(255, r * shade + 6));
      img.data[i + 1] = Math.max(0, Math.min(255, g * shade + 4));
      img.data[i + 2] = Math.max(0, Math.min(255, b * shade));
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);

  const veil = ctx.createRadialGradient(W * 0.35, H * 0.2, 40, W * 0.5, H * 0.5, Math.max(W, H) * 0.75);
  veil.addColorStop(0, "rgba(255,248,230,0.08)");
  veil.addColorStop(1, "rgba(20,12,8,0.18)");
  ctx.fillStyle = veil;
  ctx.fillRect(0, 0, W, H);
  return out;
}

export function filledPracticeAnswers(assessment: Assessment, salt = 0) {
  const key = keysForSet(assessment);
  const choices = assessment.sheetConfig.choices;
  return key.map((k, idx) => {
    if (idx === 4 + (salt % 3)) return null;
    if (idx === 11 || idx === 16) {
      return choices[(choices.indexOf(k) + 1) % choices.length]!;
    }
    return k;
  });
}

export function renderWarpedSample(assessment: Assessment, student: Student) {
  const answers = filledPracticeAnswers(assessment);
  const { canvas } = renderSheetCanvas(
    { ...assessment.sheetConfig, testSet: assessment.testSet ?? "A", date: assessment.date, examCode: examCodeFor(assessment) },
    {
      student,
      fill: { answers, rollNumber: student.rollNumber },
      dpi: 140,
    },
  );
  return photographSheet(canvas);
}
