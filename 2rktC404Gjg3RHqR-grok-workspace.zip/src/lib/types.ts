export const ASSESSMENT_TYPES = [
  "Quiz",
  "Long Test",
  "Unit Test",
  "Periodical Test",
  "Pre-Test",
  "Post-Test",
  "Activity",
  "Other",
] as const;

export type AssessmentType = (typeof ASSESSMENT_TYPES)[number];

export const TEST_SETS = ["A", "B", "C"] as const;
export type TestSet = (typeof TEST_SETS)[number];

export const PAPER_SIZES = ["A6", "A5", "A4", "Letter", "Legal", "Custom"] as const;
export type PaperSizeName = (typeof PAPER_SIZES)[number];

export type ScanFlag =
  | "unknown_roll"
  | "duplicate_roll"
  | "missing_student"
  | "multiple_answers"
  | "unclear_bubble"
  | "invalid_sheet"
  | "item_mismatch"
  | "unreadable"
  | "needs_review"
  | "wrong_exam"
  | "exam_unreadable";

export type ScanStatus = "passed" | "failed" | "incomplete" | "flagged" | "pending";

export interface Student {
  id: string;
  rollNumber: string;
  lrn: string;
  firstName: string;
  middleName: string;
  lastName: string;
  fullName: string;
  gradeLevel: string;
  section: string;
  schoolYear: string;
  extra: string;
  createdAt: string;
  updatedAt: string;
}

export interface GradeCategory {
  id: string;
  name: string;
  weight: number;
  sortOrder: number;
}

export interface Assessment {
  id: string;
  name: string;
  subject: string;
  gradeLevel: string;
  section: string;
  teacher: string;
  schoolYear: string;
  date: string;
  itemCount: number;
  passingScore: number;
  instructions: string;
  answerKey: string[];
  answerKeys?: Partial<Record<TestSet, string[]>>;
  testSet: TestSet;
  timeLimitMinutes: number | null;
  type: AssessmentType;
  categoryId?: string;
  archived: boolean;
  examCode?: string;
  sheetConfig: SheetConfig;
  createdAt: string;
  updatedAt: string;
}

export interface SheetConfig {
  paper: PaperSizeName;
  customWidthMm: number;
  customHeightMm: number;
  orientation: "portrait" | "landscape";
  itemCount: number;
  choices: string[];
  quizName: string;
  subject: string;
  teacher: string;
  school: string;
  date: string;
  instructions: string;
  showRollBubbles: boolean;
  rollDigits: number;
  showName: boolean;
  showLrn: boolean;
  showSection: boolean;
  testSet?: TestSet;
  examCode?: string;
}

export interface SheetTemplate {
  id: string;
  name: string;
  config: SheetConfig;
  createdAt: string;
}

export interface ScanResult {
  id: string;
  assessmentId: string;
  studentId: string | null;
  rollNumber: string;
  answers: Array<string | null>;
  flags: ScanFlag[];
  score: number;
  correct: number;
  wrong: number;
  blank: number;
  percentage: number;
  status: ScanStatus;
  confidence: number;
  originalBlobId: string | null;
  markedBlobId: string | null;
  remarks: string;
  reviewed: boolean;
  scannedByUserId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BlobRecord {
  id: string;
  kind: "scan" | "marked" | "backup" | "other" | "photo";
  mime: string;
  name: string;
  bytes: ArrayBuffer;
  createdAt: string;
}

export interface AppSettings {
  id: "singleton";
  schoolName: string;
  schoolId: string;
  schoolAddress: string;
  teacherName: string;
  teacherFirstName: string;
  teacherLastName: string;
  position: string;
  contactNumber: string;
  email: string;
  photoBlobId: string | null;
  theme: "light" | "dark" | "system";
  defaultGrade: string;
  defaultSection: string;
  defaultSchoolYear: string;
  rollDigits: number;
  seeded: boolean;
  firebaseApiKey: string;
  firebaseAuthDomain: string;
  firebaseProjectId: string;
  firebaseStorageBucket: string;
  firebaseMessagingSenderId: string;
  firebaseAppId: string;
  firebaseEnabled: boolean;
  firebaseEmail: string;
  lastCloudSyncAt: string | null;
}

export interface BackupMeta {
  id: string;
  createdAt: string;
  note: string;
  size: number;
}

export type CellFormat = "general" | "number" | "percent" | "text";

export interface SheetCell {
  v: string;
  fmt?: CellFormat;
  bold?: boolean;
  italic?: boolean;
  align?: "left" | "center" | "right";
  bg?: string;
  color?: string;
}

export interface WorkbookSheet {
  id: string;
  name: string;
  kind: "scans" | "subject" | "grades" | "custom";
  subject?: string;
  rows: number;
  cols: number;
  cells: Record<string, SheetCell>;
  colWidths: Record<number, number>;
  autoCols: number;
  autoRows: number;
}

export interface GradeWorkbook {
  id: string;
  gradeLevel: string;
  section: string;
  name?: string;
  sheets: WorkbookSheet[];
  activeSheetId: string;
  createdAt: string;
  updatedAt: string;
}

export function emptyKey(n: number, choices = ["A"]): string[] {
  return Array.from({ length: n }, () => choices[0] ?? "A");
}

export function keysForSet(a: Assessment, set?: TestSet): string[] {
  const s = set ?? a.testSet ?? "A";
  const fromMap = a.answerKeys?.[s];
  if (fromMap && fromMap.length === a.itemCount) return fromMap;
  if ((a.testSet ?? "A") === s && a.answerKey?.length === a.itemCount) return a.answerKey;
  return emptyKey(a.itemCount, a.sheetConfig?.choices);
}

export type UserRole = "admin" | "teacher";
export type UserStatus = "pending" | "approved" | "rejected" | "suspended";

export interface AppUser {
  id: string;
  username: string;
  fullName: string;
  email: string;
  schoolName: string;
  contactNumber: string;
  passwordSalt: string;
  passwordHash: string;
  role: UserRole;
  status: UserStatus;
  expiresAt: string | null;
  maxScansPerMonth: number | null;
  maxScansPerYear: number | null;
  notes: string;
  createdAt: string;
  updatedAt: string;
  approvedAt: string | null;
}

export interface LicenseConfig {
  id: "singleton";
  expiresAt: string | null;
  maxScansPerDay: number | null;
  maxScansPerMonth: number | null;
  maxScansPerYear: number | null;
  maxScansTotal: number | null;
  message: string;
  updatedAt: string;
}
