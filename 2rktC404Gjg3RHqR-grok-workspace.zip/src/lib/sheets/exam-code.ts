/** Code 39: 1 = wide, 0 = narrow. 9 elements (bar space bar space bar space bar space bar). */
const PAT: Record<string, string> = {
  "0": "000110100",
  "1": "100100001",
  "2": "001100001",
  "3": "101100000",
  "4": "000110001",
  "5": "100110000",
  "6": "001110000",
  "7": "000100101",
  "8": "100100100",
  "9": "001100100",
  A: "100001001",
  B: "001001001",
  C: "101001000",
  D: "000011001",
  E: "100011000",
  F: "001011000",
  G: "000001101",
  H: "100001100",
  I: "001001100",
  J: "000011100",
  K: "100000011",
  L: "001000011",
  M: "101000010",
  N: "000010011",
  O: "100010010",
  P: "001010010",
  Q: "000000111",
  R: "100000110",
  S: "001000110",
  T: "000010110",
  U: "110000001",
  V: "011000001",
  W: "111000000",
  X: "010010001",
  Y: "110010000",
  Z: "011010000",
  "-": "010000101",
  ".": "110000100",
  " ": "011000100",
  "*": "010010100",
};

export function sanitizeExamCode(raw: string) {
  return raw
    .toUpperCase()
    .replace(/[^0-9A-Z\-]/g, "")
    .slice(0, 16);
}

export function examCodeFor(a: {
  id: string;
  gradeLevel: string;
  section: string;
  testSet?: string;
  examCode?: string;
}) {
  const g = sanitizeExamCode(a.gradeLevel).slice(0, 2) || "0";
  const s = sanitizeExamCode(a.section).slice(0, 3) || "X";
  const set = sanitizeExamCode(a.testSet || "A").slice(0, 1) || "A";
  const id = sanitizeExamCode(a.id.replace(/[^0-9A-Za-z]/g, "")).slice(-4) || "0000";
  return sanitizeExamCode(`QM-${g}${s}-${set}${id}`);
}

export interface BarUnit {
  bar: boolean;
  wide: boolean;
}

export function encodeCode39(text: string): BarUnit[] {
  const payload = `*${sanitizeExamCode(text)}*`;
  const out: BarUnit[] = [];
  for (let i = 0; i < payload.length; i++) {
    const p = PAT[payload[i]!] ?? PAT["-"]!;
    if (i > 0) out.push({ bar: false, wide: false });
    for (let k = 0; k < 9; k++) {
      out.push({ bar: k % 2 === 0, wide: p[k] === "1" });
    }
  }
  return out;
}

export function drawCode39Ladder(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  text: string,
) {
  const units = encodeCode39(text);
  const total = units.reduce((n, u) => n + (u.wide ? 3 : 1), 0);
  const unit = h / Math.max(1, total);
  let cy = y;
  ctx.fillStyle = "#1c1917";
  for (const u of units) {
    const hh = unit * (u.wide ? 3 : 1);
    if (u.bar) ctx.fillRect(x, cy, w, Math.max(0.25, hh));
    cy += hh;
  }
}

const INV: Record<string, string> = Object.fromEntries(Object.entries(PAT).map(([k, v]) => [v, k]));

function runsToBits(runs: number[]): string | null {
  if (runs.length < 10) return null;
  const sorted = runs.slice().sort((a, b) => a - b);
  const narrow = sorted[Math.floor(sorted.length * 0.3)] ?? sorted[0]!;
  const thresh = narrow * 2.05;
  return runs.map((r) => (r > thresh ? "1" : "0")).join("");
}

function decodeBits(bits: string): string | null {
  const chars: string[] = [];
  let i = 0;
  while (i + 9 <= bits.length) {
    const slice = bits.slice(i, i + 9);
    const ch = INV[slice];
    if (!ch) {
      i++;
      continue;
    }
    chars.push(ch);
    i += 9;
    if (i < bits.length) i += 1;
  }
  const joined = chars.join("");
  const a = joined.indexOf("*");
  const b = joined.indexOf("*", a + 1);
  if (a < 0 || b < 0) return null;
  return joined.slice(a + 1, b);
}

export function decodeCode39Runs(runs: number[]): string | null {
  const bits = runsToBits(runs);
  if (!bits) return null;
  return decodeBits(bits) ?? decodeBits([...bits].reverse().join(""));
}

export function profileToRuns(profile: number[]): number[] {
  if (!profile.length) return [];
  const sorted = profile.slice().sort((a, b) => a - b);
  const t = sorted[Math.floor(sorted.length * 0.55)] ?? 128;
  const bin = profile.map((v) => (v < t ? 1 : 0));
  const runs: number[] = [];
  let cur = bin[0]!;
  let n = 1;
  for (let i = 1; i < bin.length; i++) {
    if (bin[i] === cur) n++;
    else {
      runs.push(n);
      cur = bin[i]!;
      n = 1;
    }
  }
  runs.push(n);
  if (bin[0] === 0) runs.shift();
  if (bin[bin.length - 1] === 0 && runs.length) runs.pop();
  return runs;
}

export function readExamCodeFromImage(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  region: { x: number; y: number; w: number; h: number },
): string | null {
  const x0 = Math.max(0, Math.floor(region.x));
  const y0 = Math.max(0, Math.floor(region.y));
  const x1 = Math.min(width - 1, Math.ceil(region.x + region.w));
  const y1 = Math.min(height - 1, Math.ceil(region.y + region.h));
  if (x1 <= x0 || y1 <= y0) return null;
  const attempts = [0.35, 0.5, 0.65];
  for (const frac of attempts) {
    const profile: number[] = [];
    const cx = Math.round(x0 + (x1 - x0) * frac);
    for (let y = y0; y <= y1; y++) {
      let acc = 0;
      let n = 0;
      for (let x = Math.max(x0, cx - 2); x <= Math.min(x1, cx + 2); x++) {
        const i = (y * width + x) * 4;
        acc += data[i]! * 0.299 + data[i + 1]! * 0.587 + data[i + 2]! * 0.114;
        n++;
      }
      profile.push(n ? acc / n : 255);
    }
    const code = decodeCode39Runs(profileToRuns(profile));
    if (code && code.length >= 4) return sanitizeExamCode(code);
  }
  return null;
}
