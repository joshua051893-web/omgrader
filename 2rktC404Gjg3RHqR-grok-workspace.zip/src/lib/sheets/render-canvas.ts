import type { SheetConfig } from "@/lib/types";
import { buildLayout, type SheetLayout } from "@/lib/sheets/layout";
import { drawCode39Ladder } from "@/lib/sheets/exam-code";

export function mmToPx(mm: number) {
  return mm * (150 / 25.4);
}

export interface RenderStudent {
  fullName?: string;
  rollNumber?: string;
  lrn?: string;
  section?: string;
}

export interface FillSpec {
  answers: Array<string | null>;
  rollNumber?: string;
}

export function renderSheetCanvas(
  cfg: SheetConfig,
  opts: { student?: RenderStudent; fill?: FillSpec; dpi?: number } = {},
): { canvas: HTMLCanvasElement; layout: SheetLayout } {
  const layout = buildLayout(cfg);
  const scale = (opts.dpi ?? 150) / 25.4;
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(layout.widthMm * scale);
  canvas.height = Math.round(layout.heightMm * scale);
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#fbfaf6";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.scale(scale, scale);
  drawSheet(ctx, cfg, layout, opts.student, opts.fill);
  return { canvas, layout };
}

function drawSheet(
  ctx: CanvasRenderingContext2D,
  cfg: SheetConfig,
  layout: SheetLayout,
  student?: RenderStudent,
  fill?: FillSpec,
) {
  ctx.strokeStyle = "#1c1917";
  ctx.fillStyle = "#1c1917";
  ctx.lineWidth = 0.35;

  for (const f of layout.fiducials) {
    ctx.fillRect(f.x, f.y, f.size, f.size);
    if (f.id === "TR") {
      ctx.fillStyle = "#fbfaf6";
      ctx.fillRect(f.x + f.size * 0.28, f.y + f.size * 0.28, f.size * 0.44, f.size * 0.44);
      ctx.fillStyle = "#1c1917";
    }
  }
  ctx.fillRect(
    layout.orientationBar.x,
    layout.orientationBar.y,
    layout.orientationBar.w,
    layout.orientationBar.h,
  );

  const code = (cfg.examCode || "").toUpperCase();
  if (code) {
    drawCode39Ladder(ctx, layout.barcode.x, layout.barcode.y, layout.barcode.w, layout.barcode.h, code);
    ctx.save();
    ctx.translate(layout.barcode.x + layout.barcode.w + 3.2, layout.barcode.y + layout.barcode.h);
    ctx.rotate(-Math.PI / 2);
    ctx.font = "3.1px 'IBM Plex Sans', sans-serif";
    ctx.fillStyle = "#1c1917";
    ctx.fillText(code, 0, 0);
    ctx.restore();
  }

  ctx.font = "bold 5.2px 'IBM Plex Sans', sans-serif";
  ctx.fillText(cfg.school || "School", layout.nameBox.x, layout.headerY + 2);
  ctx.font = "bold 7.2px 'IBM Plex Sans', sans-serif";
  ctx.fillText(cfg.quizName || "Assessment", layout.nameBox.x, layout.headerY + 10);
  ctx.font = "3.8px 'IBM Plex Sans', sans-serif";
  const setLabel = `Set ${cfg.testSet || "A"}`;
  const meta = [cfg.subject, cfg.teacher, cfg.date ? `Date of test: ${cfg.date}` : "", setLabel]
    .filter(Boolean)
    .join("  ·  ");
  ctx.fillText(meta, layout.nameBox.x, layout.headerY + 16);

  ctx.font = "bold 8px 'IBM Plex Sans', sans-serif";
  ctx.fillText(setLabel, layout.nameBox.x + layout.nameBox.w - 22, layout.headerY + 10);

  ctx.font = "3.6px 'IBM Plex Sans', sans-serif";
  const nameY = layout.nameBox.y + 4;
  ctx.fillText("Name", layout.nameBox.x, nameY);
  ctx.strokeRect(layout.nameBox.x + 14, nameY - 3.5, layout.nameBox.w * 0.55, 6);
  if (cfg.showName && student?.fullName) {
    ctx.font = "4.2px 'IBM Plex Sans', sans-serif";
    ctx.fillText(student.fullName, layout.nameBox.x + 16, nameY + 0.8);
  }
  ctx.font = "3.6px 'IBM Plex Sans', sans-serif";
  if (cfg.showSection) {
    ctx.fillText("Section", layout.nameBox.x + layout.nameBox.w * 0.62, nameY);
    ctx.strokeRect(layout.nameBox.x + layout.nameBox.w * 0.74, nameY - 3.5, layout.nameBox.w * 0.24, 6);
    if (student?.section) {
      ctx.fillText(student.section, layout.nameBox.x + layout.nameBox.w * 0.76, nameY + 0.8);
    }
  }
  if (cfg.showLrn) {
    ctx.fillText("LRN", layout.nameBox.x, nameY + 8);
    ctx.strokeRect(layout.nameBox.x + 14, nameY + 4.5, 58, 6);
    if (student?.lrn) ctx.fillText(student.lrn, layout.nameBox.x + 16, nameY + 9);
  }
  ctx.font = "3.6px 'IBM Plex Sans', sans-serif";
  ctx.fillText("Roll", layout.nameBox.x + layout.nameBox.w * 0.62, nameY + 8);
  ctx.strokeRect(layout.nameBox.x + layout.nameBox.w * 0.74, nameY + 4.5, layout.nameBox.w * 0.24, 6);
  const rollText = (fill?.rollNumber ?? student?.rollNumber ?? "").replace(/\D/g, "");
  if (rollText) {
    ctx.font = "4.2px 'IBM Plex Sans', sans-serif";
    ctx.fillText(rollText.padStart(cfg.rollDigits, "0"), layout.nameBox.x + layout.nameBox.w * 0.76, nameY + 9);
  }

  if (layout.rollBubbles.length) {
    ctx.font = "bold 4px 'IBM Plex Sans', sans-serif";
    ctx.fillText("ROLL NUMBER", layout.nameBox.x, layout.rollBubbles[0]!.cy - 6);
    const digits = cfg.rollDigits;
    const rollSource = fill?.rollNumber ?? student?.rollNumber ?? "";
    const roll = rollSource.replace(/\D/g, "").padStart(digits, "0");
    const shadeRoll = Boolean(rollSource);
    for (const b of layout.rollBubbles) {
      const marked = shadeRoll && roll[b.digitIndex] === String(b.value);
      drawBubble(ctx, b.cx, b.cy, b.r, String(b.value), marked);
    }
  }

  ctx.font = "3.2px 'IBM Plex Sans', sans-serif";
  const wrap = wrapText(cfg.instructions, 90);
  let iy = layout.heightMm - 18;
  for (const line of wrap.slice(0, 2)) {
    ctx.fillText(line, layout.nameBox.x, iy);
    iy += 4;
  }

  const byItem = new Map<number, typeof layout.answerBubbles>();
  for (const b of layout.answerBubbles) {
    const arr = byItem.get(b.item) ?? [];
    arr.push(b);
    byItem.set(b.item, arr);
  }
  for (const [item, bubbles] of byItem) {
    const first = bubbles[0]!;
    ctx.font = "bold 3.6px 'IBM Plex Sans', sans-serif";
    ctx.fillStyle = "#1c1917";
    ctx.fillText(String(item + 1).padStart(2, "0"), first.cx - 9, first.cy + 1.3);
    const ans = fill?.answers[item] ?? null;
    for (const b of bubbles) {
      drawBubble(ctx, b.cx, b.cy, b.r, b.choice, ans === b.choice);
    }
  }
}

function drawBubble(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  label: string,
  filled: boolean,
) {
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  if (filled) {
    ctx.fillStyle = "#1c1917";
    ctx.fill();
    ctx.fillStyle = "#fbfaf6";
    ctx.font = `bold ${Math.max(2.4, r * 0.7)}px 'IBM Plex Sans', sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText(label, cx, cy + r * 0.35);
    ctx.textAlign = "left";
    ctx.fillStyle = "#1c1917";
  } else {
    ctx.strokeStyle = "#1c1917";
    ctx.lineWidth = 0.38;
    ctx.stroke();
    ctx.font = `${Math.max(2.4, r * 0.7)}px 'IBM Plex Sans', sans-serif`;
    ctx.textAlign = "center";
    ctx.fillStyle = "#1c1917";
    ctx.fillText(label, cx, cy + r * 0.35);
    ctx.textAlign = "left";
  }
}

function wrapText(text: string, maxChars: number): string[] {
  const words = (text || "").split(/\s+/);
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    const next = cur ? `${cur} ${w}` : w;
    if (next.length > maxChars) {
      if (cur) lines.push(cur);
      cur = w;
    } else cur = next;
  }
  if (cur) lines.push(cur);
  return lines;
}

export function canvasToBlob(canvas: HTMLCanvasElement, type = "image/png"): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("Could not export image"))), type);
  });
}
