import { PDFDocument, rgb, StandardFonts, type PDFFont, type PDFPage } from "pdf-lib";
import type { SheetConfig, Student } from "@/lib/types";
import { buildLayout } from "@/lib/sheets/layout";

const MM = 72 / 25.4;

export async function generateBubbleSheetPdf(
  cfg: SheetConfig,
  students?: Student[],
): Promise<Uint8Array> {
  const layout = buildLayout(cfg);
  const doc = await PDFDocument.create();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const fontBold = await doc.embedFont(StandardFonts.HelveticaBold);
  const pages = students && students.length ? students : [undefined];

  for (const student of pages) {
    const page = doc.addPage([layout.widthMm * MM, layout.heightMm * MM]);
    const H = layout.heightMm * MM;
    const ink = rgb(0.11, 0.1, 0.09);
    const paper = rgb(0.985, 0.98, 0.965);
    page.drawRectangle({ x: 0, y: 0, width: page.getWidth(), height: page.getHeight(), color: paper });

    const yFlip = (mmY: number) => H - mmY * MM;
    const mm = (n: number) => n * MM;

    for (const f of layout.fiducials) {
      page.drawRectangle({
        x: mm(f.x),
        y: yFlip(f.y + f.size),
        width: mm(f.size),
        height: mm(f.size),
        color: ink,
      });
      if (f.id === "TR") {
        page.drawRectangle({
          x: mm(f.x + f.size * 0.28),
          y: yFlip(f.y + f.size * 0.72),
          width: mm(f.size * 0.44),
          height: mm(f.size * 0.44),
          color: paper,
        });
      }
    }
    page.drawRectangle({
      x: mm(layout.orientationBar.x),
      y: yFlip(layout.orientationBar.y + layout.orientationBar.h),
      width: mm(layout.orientationBar.w),
      height: mm(layout.orientationBar.h),
      color: ink,
    });

    page.drawText(cfg.school || "School", {
      x: mm(layout.nameBox.x),
      y: yFlip(layout.headerY + 3.2),
      size: 8,
      font: fontBold,
      color: ink,
    });
    page.drawText(cfg.quizName || "Assessment", {
      x: mm(layout.nameBox.x),
      y: yFlip(layout.headerY + 11),
      size: 13,
      font: fontBold,
      color: ink,
    });
    page.drawText([cfg.subject, cfg.teacher, cfg.date].filter(Boolean).join("   ·   "), {
      x: mm(layout.nameBox.x),
      y: yFlip(layout.headerY + 16.5),
      size: 8,
      font,
      color: ink,
    });

    const nameY = layout.nameBox.y + 4;
    page.drawText("Name", { x: mm(layout.nameBox.x), y: yFlip(nameY + 1), size: 8, font, color: ink });
    page.drawRectangle({
      x: mm(layout.nameBox.x + 14),
      y: yFlip(nameY + 2.5),
      width: mm(layout.nameBox.w * 0.55),
      height: mm(6),
      borderColor: ink,
      borderWidth: 0.6,
    });
    if (cfg.showName && student?.fullName) {
      page.drawText(student.fullName, {
        x: mm(layout.nameBox.x + 16),
        y: yFlip(nameY + 1),
        size: 9,
        font,
        color: ink,
      });
    }

    if (layout.rollBubbles.length) {
      page.drawText("ROLL NUMBER", {
        x: mm(layout.nameBox.x),
        y: yFlip(layout.rollBubbles[0]!.cy - 6),
        size: 9,
        font: fontBold,
        color: ink,
      });
      for (const b of layout.rollBubbles) {
        drawPdfBubble(page, b.cx, b.cy, b.r, String(b.value), mm, yFlip, ink, font);
      }
    }

    const byItem = new Map<number, typeof layout.answerBubbles>();
    for (const b of layout.answerBubbles) {
      const arr = byItem.get(b.item) ?? [];
      arr.push(b);
      byItem.set(b.item, arr);
    }
    for (const [item, bubbles] of byItem) {
      const first = bubbles[0]!;
      page.drawText(String(item + 1).padStart(2, "0"), {
        x: mm(first.cx - 9),
        y: yFlip(first.cy + 1.2),
        size: 8,
        font: fontBold,
        color: ink,
      });
      for (const b of bubbles) {
        drawPdfBubble(page, b.cx, b.cy, b.r, b.choice, mm, yFlip, ink, font);
      }
    }

    if (cfg.instructions) {
      page.drawText(cfg.instructions.slice(0, 140), {
        x: mm(layout.nameBox.x),
        y: mm(10),
        size: 7,
        font,
        color: ink,
      });
    }
  }

  return doc.save();
}

function drawPdfBubble(
  page: PDFPage,
  cx: number,
  cy: number,
  r: number,
  label: string,
  mm: (n: number) => number,
  yFlip: (n: number) => number,
  ink: ReturnType<typeof rgb>,
  font: PDFFont,
) {
  const size = 6;
  page.drawCircle({
    x: mm(cx),
    y: yFlip(cy),
    size: mm(r),
    borderColor: ink,
    borderWidth: 0.7,
  });
  const tw = font.widthOfTextAtSize(label, size);
  page.drawText(label, {
    x: mm(cx) - tw / 2,
    y: yFlip(cy) - 2.2,
    size,
    font,
    color: ink,
  });
}
