import type { SheetConfig } from "@/lib/types";

export const PAPER_MM: Record<string, [number, number]> = {
  A6: [105, 148],
  A5: [148, 210],
  A4: [210, 297],
  Letter: [215.9, 279.4],
  Legal: [215.9, 355.6],
};

export interface PointBubble {
  item: number;
  choice: string;
  cx: number;
  cy: number;
  r: number;
}

export interface RollBubble {
  digitIndex: number;
  value: number;
  cx: number;
  cy: number;
  r: number;
}

export interface Fiducial {
  id: "TL" | "TR" | "BL" | "BR";
  x: number;
  y: number;
  size: number;
}

export interface SheetLayout {
  widthMm: number;
  heightMm: number;
  fiducials: Fiducial[];
  orientationBar: { x: number; y: number; w: number; h: number };
  rollBubbles: RollBubble[];
  answerBubbles: PointBubble[];
  nameBox: { x: number; y: number; w: number; h: number };
  barcode: { x: number; y: number; w: number; h: number };
  headerY: number;
  columns: number;
}

export function paperDims(cfg: SheetConfig): { widthMm: number; heightMm: number } {
  let [w, h] =
    cfg.paper === "Custom"
      ? [cfg.customWidthMm || 210, cfg.customHeightMm || 297]
      : PAPER_MM[cfg.paper] ?? PAPER_MM.A4;
  if (cfg.orientation === "landscape") {
    const t = w;
    w = h;
    h = t;
  }
  return { widthMm: w, heightMm: h };
}

export function buildLayout(cfg: SheetConfig): SheetLayout {
  const { widthMm, heightMm } = paperDims(cfg);
  const margin = Math.max(8, Math.min(widthMm, heightMm) * 0.04);
  const fid = Math.max(8, Math.min(12, widthMm * 0.045));
  const fiducials: Fiducial[] = [
    { id: "TL", x: margin, y: margin, size: fid },
    { id: "TR", x: widthMm - margin - fid, y: margin, size: fid },
    { id: "BL", x: margin, y: heightMm - margin - fid, size: fid },
    { id: "BR", x: widthMm - margin - fid, y: heightMm - margin - fid, size: fid },
  ];
  const orientationBar = {
    x: margin + fid + 4,
    y: margin + 1.5,
    w: Math.min(28, widthMm * 0.14),
    h: 3.2,
  };

  const contentLeft = margin + fid + 4;
  const barcodeW = Math.max(7.5, Math.min(11, widthMm * 0.042));
  const contentRight = widthMm - margin - fid - barcodeW - 4;
  const contentTop = margin + fid + 6;
  const contentBottom = heightMm - margin - fid - 4;
  const headerY = contentTop;
  const barcode = {
    x: contentRight + 2.2,
    y: contentTop + 2,
    w: barcodeW,
    h: Math.max(40, contentBottom - contentTop - 6),
  };

  let y = contentTop + 28;
  const nameBox = {
    x: contentLeft,
    y: y - 2,
    w: contentRight - contentLeft,
    h: 14,
  };
  y += 16;

  const rollBubbles: RollBubble[] = [];
  const digits = cfg.showRollBubbles ? cfg.rollDigits : 0;
  const rollR = 3.1;
  if (digits > 0) {
    const colGap = 9.5;
    const rowGap = 6.4;
    const blockW = digits * colGap;
    const startX = contentLeft + 28;
    const startY = y + 8;
    for (let d = 0; d < digits; d++) {
      for (let v = 0; v < 10; v++) {
        rollBubbles.push({
          digitIndex: d,
          value: v,
          cx: startX + d * colGap,
          cy: startY + v * rowGap,
          r: rollR,
        });
      }
    }
    y = startY + 10 * rowGap + 8;
    void blockW;
  } else {
    y += 4;
  }

  const items = Math.max(1, cfg.itemCount);
  const choices = cfg.choices.length ? cfg.choices : ["A", "B", "C", "D"];
  const bubbleR = 3.4;
  const choiceGap = 8.2;
  const rowGap = 8.4;
  const usableH = contentBottom - y - 4;
  const maxRows = Math.max(5, Math.floor(usableH / rowGap));
  const columns = Math.max(1, Math.ceil(items / maxRows));
  const colWidth = (contentRight - contentLeft) / columns;
  const answerBubbles: PointBubble[] = [];

  for (let i = 0; i < items; i++) {
    const col = Math.floor(i / maxRows);
    const row = i % maxRows;
    const baseX = contentLeft + col * colWidth + 12;
    const cy = y + row * rowGap + bubbleR;
    for (let c = 0; c < choices.length; c++) {
      answerBubbles.push({
        item: i,
        choice: choices[c]!,
        cx: baseX + c * choiceGap,
        cy,
        r: bubbleR,
      });
    }
  }

  return {
    widthMm,
    heightMm,
    fiducials,
    orientationBar,
    rollBubbles,
    answerBubbles,
    nameBox,
    barcode,
    headerY,
    columns,
  };
}
