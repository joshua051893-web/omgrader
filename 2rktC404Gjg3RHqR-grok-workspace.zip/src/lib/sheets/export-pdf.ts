import { PDFDocument } from "pdf-lib";
import { canvasToBlob } from "@/lib/sheets/render-canvas";

export async function canvasesToPdf(
  canvases: HTMLCanvasElement[],
  widthMm: number,
  heightMm: number,
): Promise<Blob> {
  const doc = await PDFDocument.create();
  const w = (widthMm * 72) / 25.4;
  const h = (heightMm * 72) / 25.4;
  for (const canvas of canvases) {
    const blob = await canvasToBlob(canvas, "image/png");
    const bytes = new Uint8Array(await blob.arrayBuffer());
    const img = await doc.embedPng(bytes);
    const page = doc.addPage([w, h]);
    page.drawImage(img, { x: 0, y: 0, width: w, height: h });
  }
  const saved = await doc.save();
  const copy = new Uint8Array(saved.byteLength);
  copy.set(saved);
  return new Blob([copy], { type: "application/pdf" });
}