import JSZip from "jszip";
import { db } from "@/lib/db/database";
import { downloadBlob, nowIso, uid } from "@/lib/utils";

export async function exportFullBackup(): Promise<void> {
  const zip = new JSZip();
  const payload = {
    version: 1,
    exportedAt: nowIso(),
    students: await db.students.toArray(),
    assessments: await db.assessments.toArray(),
    scans: await db.scans.toArray(),
    categories: await db.categories.toArray(),
    templates: await db.templates.toArray(),
    settings: await db.settings.toArray(),
    workbooks: await db.workbooks.toArray(),
  };
  zip.file("omg-db.json", JSON.stringify(payload));
  zip.file("quillmark-db.json", JSON.stringify(payload));
  const blobs = await db.blobs.toArray();
  for (const b of blobs) {
    zip.file(`files/${b.id}_${b.name}`, b.bytes);
  }
  const out = await zip.generateAsync({ type: "blob" });
  await db.backups.add({
    id: uid("bak"),
    createdAt: nowIso(),
    note: "Manual backup",
    size: out.size,
  });
  downloadBlob(out, `omg-backup-${new Date().toISOString().slice(0, 10)}.zip`);
}

export async function importFullBackup(file: Blob): Promise<void> {
  const zip = await JSZip.loadAsync(file);
  const dbFile = zip.file("omg-db.json") ?? zip.file("quillmark-db.json");
  if (!dbFile) throw new Error("This file is not an OMG backup.");
  const payload = JSON.parse(await dbFile.async("string")) as {
    students: unknown[];
    assessments: unknown[];
    scans: unknown[];
    categories: unknown[];
    templates: unknown[];
    settings: unknown[];
    workbooks?: unknown[];
  };
  await db.students.clear();
  await db.assessments.clear();
  await db.scans.clear();
  await db.categories.clear();
  await db.templates.clear();
  await db.settings.clear();
  await db.workbooks.clear();
  await db.blobs.clear();
  await db.students.bulkAdd(payload.students as never);
  await db.assessments.bulkAdd(payload.assessments as never);
  await db.scans.bulkAdd(payload.scans as never);
  await db.categories.bulkAdd(payload.categories as never);
  await db.templates.bulkAdd(payload.templates as never);
  await db.settings.bulkAdd(payload.settings as never);
  if (payload.workbooks?.length) await db.workbooks.bulkAdd(payload.workbooks as never);
  const files = Object.keys(zip.files).filter((k) => k.startsWith("files/") && !zip.files[k]!.dir);
  for (const path of files) {
    const name = path.slice("files/".length);
    const id = name.split("_")[0]!;
    const bytes = await zip.files[path]!.async("arraybuffer");
    await db.blobs.put({
      id,
      kind: "other",
      mime: "application/octet-stream",
      name: name.slice(id.length + 1) || name,
      bytes,
      createdAt: nowIso(),
    });
  }
}
