import type { AppSettings } from "@/lib/types";

export interface FirebaseWebConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
}

export function settingsToFirebaseConfig(s: AppSettings): FirebaseWebConfig | null {
  if (!s.firebaseApiKey || !s.firebaseProjectId || !s.firebaseAppId) return null;
  return {
    apiKey: s.firebaseApiKey.trim(),
    authDomain: s.firebaseAuthDomain.trim() || `${s.firebaseProjectId.trim()}.firebaseapp.com`,
    projectId: s.firebaseProjectId.trim(),
    storageBucket: s.firebaseStorageBucket.trim() || `${s.firebaseProjectId.trim()}.appspot.com`,
    messagingSenderId: s.firebaseMessagingSenderId.trim(),
    appId: s.firebaseAppId.trim(),
  };
}

export function parseFirebaseConfigPaste(raw: string): FirebaseWebConfig {
  const text = raw.trim();
  if (!text) throw new Error("Paste the firebaseConfig object from Project settings.");
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("Could not find a { ... } config object in that paste.");
  const body = text.slice(start, end + 1);
  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(body) as Record<string, unknown>;
  } catch {
    const jsonish = body
      .replace(/'/g, '"')
      .replace(/([,{]\s*)([A-Za-z0-9_]+)\s*:/g, '$1"$2":')
      .replace(/,(\s*[}\]])/g, "$1");
    try {
      parsed = JSON.parse(jsonish) as Record<string, unknown>;
    } catch {
      throw new Error("That did not look like a Firebase web config. Copy it from Project settings → Your apps.");
    }
  }
  const pick = (k: string) => String(parsed[k] ?? "").trim();
  const cfg: FirebaseWebConfig = {
    apiKey: pick("apiKey"),
    authDomain: pick("authDomain"),
    projectId: pick("projectId"),
    storageBucket: pick("storageBucket"),
    messagingSenderId: pick("messagingSenderId"),
    appId: pick("appId"),
  };
  if (!cfg.apiKey || !cfg.projectId || !cfg.appId) {
    throw new Error("apiKey, projectId, and appId are required.");
  }
  return cfg;
}

export function schoolPathId(schoolId: string, projectId: string) {
  const raw = (schoolId || projectId || "school").trim().replace(/[^\w.-]+/g, "_");
  return raw.slice(0, 64) || "school";
}

export const FIRESTORE_RULES = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /schools/{schoolId}/{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
`;

export const STORAGE_RULES = `rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /schools/{schoolId}/{allPaths=**} {
      allow read, write: if request.auth != null;
    }
  }
}
`;
