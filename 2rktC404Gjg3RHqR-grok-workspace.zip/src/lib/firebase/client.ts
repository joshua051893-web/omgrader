import { deleteApp, getApp, getApps, initializeApp, type FirebaseApp } from "firebase/app";
import { getAuth, type Auth } from "firebase/auth";
import { getFirestore, type Firestore } from "firebase/firestore";
import { getStorage, type FirebaseStorage } from "firebase/storage";
import { settingsToFirebaseConfig, type FirebaseWebConfig } from "@/lib/firebase/config";
import { getSettings } from "@/lib/db/repo";

let app: FirebaseApp | null = null;
let lastKey = "";

function configKey(c: FirebaseWebConfig) {
  return `${c.projectId}|${c.appId}|${c.apiKey}`;
}

export async function firebaseFromSettings() {
  const settings = await getSettings();
  const cfg = settingsToFirebaseConfig(settings);
  if (!cfg) throw new Error("Add your Firebase web config in Settings first.");
  return connectFirebase(cfg);
}

export async function connectFirebase(cfg: FirebaseWebConfig) {
  const key = configKey(cfg);
  if (app && lastKey === key) {
    return handles(app);
  }
  if (app) {
    await deleteApp(app).catch(() => undefined);
    app = null;
  }
  const existing = getApps()[0];
  if (existing) await deleteApp(existing).catch(() => undefined);
  app = initializeApp(cfg, "omg");
  lastKey = key;
  return handles(app);
}

function handles(instance: FirebaseApp) {
  const auth: Auth = getAuth(instance);
  const firestore: Firestore = getFirestore(instance);
  const storage: FirebaseStorage = getStorage(instance);
  return { app: instance, auth, firestore, storage };
}

export function currentFirebaseApp() {
  if (app) return app;
  try {
    return getApp("omg");
  } catch {
    return null;
  }
}
