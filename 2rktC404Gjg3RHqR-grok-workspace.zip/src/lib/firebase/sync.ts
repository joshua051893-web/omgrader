import {
  collection,
  doc,
  getDocs,
  setDoc,
} from "firebase/firestore";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, type User } from "firebase/auth";
import { db } from "@/lib/db/database";
import { getSettings, saveSettings } from "@/lib/db/repo";
import { connectFirebase, firebaseFromSettings } from "@/lib/firebase/client";
import { schoolPathId, settingsToFirebaseConfig, type FirebaseWebConfig } from "@/lib/firebase/config";
import { nowIso } from "@/lib/utils";
import type { Assessment, GradeWorkbook, ScanResult, Student } from "@/lib/types";

export interface SyncReport {
  pushed: number;
  pulled: number;
  files: number;
}

function stripUndefined<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

function newer(a?: string | null, b?: string | null) {
  return (a || "") > (b || "");
}

export async function cloudSignIn(email: string, password: string, create = false) {
  const { auth } = await firebaseFromSettings();
  const fn = create ? createUserWithEmailAndPassword : signInWithEmailAndPassword;
  const cred = await fn(auth, email.trim(), password);
  await saveSettings({ firebaseEmail: email.trim(), firebaseEnabled: true });
  return cred.user;
}

export async function cloudSignOut() {
  const { auth } = await firebaseFromSettings();
  await signOut(auth);
}

export async function currentCloudUser(): Promise<User | null> {
  try {
    const { auth } = await firebaseFromSettings();
    return auth.currentUser;
  } catch {
    return null;
  }
}

async function requireCloud() {
  const settings = await getSettings();
  const cfg = settingsToFirebaseConfig(settings);
  if (!cfg) throw new Error("Paste your Firebase config in Settings first.");
  const fb = await connectFirebase(cfg);
  if (!fb.auth.currentUser) {
    throw new Error("Sign in to Firebase in Settings before syncing.");
  }
  const schoolId = schoolPathId(settings.schoolId || settings.schoolName, cfg.projectId);
  return { ...fb, settings, cfg, schoolId };
}

export async function testFirebaseConnection(cfg: FirebaseWebConfig) {
  const fb = await connectFirebase(cfg);
  return { projectId: cfg.projectId, uid: fb.auth.currentUser?.uid ?? null };
}

export async function syncWithFirebase(): Promise<SyncReport> {
  const { firestore, schoolId, settings } = await requireCloud();
  let pushed = 0;
  let pulled = 0;
  const files = 0;
  const root = (name: string) => collection(firestore, "schools", schoolId, name);

  async function twoWay<T extends { id: string; updatedAt?: string }>(
    table: { toArray: () => Promise<T[]>; put: (row: T) => Promise<unknown> },
    col: string,
    clean: (row: T) => Record<string, unknown> = (row) => stripUndefined(row) as Record<string, unknown>,
    merge = (_local: T | undefined, remote: T) => remote,
  ) {
    const local = await table.toArray();
    const snap = await getDocs(root(col));
    const remote = new Map(snap.docs.map((d) => [d.id, { ...(d.data() as T), id: d.id }]));
    for (const row of local) {
      const r = remote.get(row.id);
      if (!r || !newer(r.updatedAt, row.updatedAt)) {
        await setDoc(doc(root(col), row.id), clean(row), { merge: true });
        pushed++;
      }
    }
    for (const [id, data] of remote) {
      const l = local.find((x) => x.id === id);
      if (!l || newer(data.updatedAt, l.updatedAt)) {
        await table.put(merge(l, { ...data, id }));
        pulled++;
      }
    }
  }

  await twoWay<Student>(db.students, "students");
  await twoWay<Assessment>(db.assessments, "assessments");
  await twoWay<ScanResult>(
    db.scans,
    "scans",
    (row) =>
      stripUndefined({
        ...row,
        originalBlobId: null,
        markedBlobId: null,
      }) as Record<string, unknown>,
    (local, remote) => ({
      ...remote,
      originalBlobId: local?.originalBlobId ?? null,
      markedBlobId: local?.markedBlobId ?? null,
    }),
  );
  await twoWay<GradeWorkbook>(db.workbooks, "workbooks");

  const publicSettings = {
    id: "singleton",
    schoolName: settings.schoolName,
    schoolId: settings.schoolId,
    schoolAddress: settings.schoolAddress,
    teacherName: settings.teacherName,
    teacherFirstName: settings.teacherFirstName,
    teacherLastName: settings.teacherLastName,
    position: settings.position,
    contactNumber: settings.contactNumber,
    email: settings.email,
    defaultGrade: settings.defaultGrade,
    defaultSection: settings.defaultSection,
    defaultSchoolYear: settings.defaultSchoolYear,
    rollDigits: settings.rollDigits,
    updatedAt: nowIso(),
  };
  await setDoc(doc(firestore, "schools", schoolId, "meta", "profile"), publicSettings, { merge: true });
  pushed++;

  await saveSettings({ lastCloudSyncAt: nowIso(), firebaseEnabled: true });
  return { pushed, pulled, files };
}
