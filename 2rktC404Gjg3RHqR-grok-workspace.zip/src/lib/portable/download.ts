import JSZip from "jszip";
import { downloadBlob } from "@/lib/utils";

function appUrl() {
  if (typeof window === "undefined") return "http://localhost:8080/";
  return `${window.location.origin}/`;
}

export async function downloadWindowsPortable() {
  const url = appUrl();
  const zip = new JSZip();
  zip.file(
    "README.txt",
    `OMG — Optical Media Grader
Windows portable launcher

1. Keep this folder on the computer (or a USB drive).
2. Double-click "Start OMG.bat".
3. Edge or Chrome opens OMG as its own window.

This launcher opens the OMG website in app mode. Student records stay in that browser profile (the OMG-profile folder next to the launcher).

To copy grades and scans to another PC, use Settings → Export database inside the app.

Developed by J.D.C. of SPCIHS, to support - 09197677274
App URL: ${url}
`,
  );
  zip.file(
    "Start OMG.bat",
    `@echo off
title OMG — Optical Media Grader
cd /d "%~dp0"
set "URL=${url}"
set "PROFILE=%~dp0OMG-profile"
if exist "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" (
  start "" "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" --app="%URL%" --user-data-dir="%PROFILE%"
  exit /b 0
)
if exist "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe" (
  start "" "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe" --app="%URL%" --user-data-dir="%PROFILE%"
  exit /b 0
)
if exist "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" (
  start "" "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" --app="%URL%" --user-data-dir="%PROFILE%"
  exit /b 0
)
if exist "%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe" (
  start "" "%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe" --app="%URL%" --user-data-dir="%PROFILE%"
  exit /b 0
)
start "" "%URL%"
`,
  );
  zip.file(
    "OMG.url",
    `[InternetShortcut]
URL=${url}
`,
  );
  const out = await zip.generateAsync({ type: "blob" });
  downloadBlob(out, "OMG-Windows-portable.zip");
}

export async function downloadAndroidPackage() {
  const url = appUrl();
  const zip = new JSZip();
  zip.file(
    "README.txt",
    `OMG — Optical Media Grader
Android install kit

A store APK cannot be compiled from the browser. Install OMG as a real app on your phone:

1. Open Chrome or Edge on the phone.
2. Go to: ${url}
3. Tap the menu (three dots) → Install app / Add to Home screen.
4. Open OMG from the home screen. It works offline after the first visit.

Student records stay on that phone. Use Settings → Export database to copy data.

Developed by J.D.C. of SPCIHS, to support - 09197677274
`,
  );
  zip.file(
    "install.html",
    `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#215c4a" />
  <title>Install OMG — Optical Media Grader</title>
  <style>
    body { font-family: system-ui, sans-serif; margin: 0; background: #f4efe6; color: #1c1917; }
    main { max-width: 32rem; margin: 2rem auto; padding: 1.5rem; background: #fffdf9; border-radius: 16px; }
    a.btn { display: inline-block; margin-top: 1rem; padding: .75rem 1rem; background: #215c4a; color: #f4efe6; text-decoration: none; border-radius: 8px; }
    p { line-height: 1.5; }
  </style>
</head>
<body>
  <main>
    <h1>Install OMG</h1>
    <p>Optical Media Grader on this phone.</p>
    <p>Tap the button, then use your browser menu to <strong>Install app</strong> or <strong>Add to Home screen</strong>.</p>
    <a class="btn" href="${url}">Open OMG</a>
    <p style="font-size:12px;color:#6b645b">Developed by J.D.C. of SPCIHS, to support - 09197677274</p>
  </main>
</body>
</html>
`,
  );
  zip.file(
    "omg.webmanifest",
    JSON.stringify(
      {
        name: "OMG — Optical Media Grader",
        short_name: "OMG",
        start_url: url,
        display: "standalone",
        background_color: "#f4efe6",
        theme_color: "#215c4a",
        description: "Offline-first bubble sheet grader and gradebook.",
      },
      null,
      2,
    ),
  );
  const out = await zip.generateAsync({ type: "blob" });
  downloadBlob(out, "OMG-Android-install-kit.zip");
}
