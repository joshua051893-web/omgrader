import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { db } from "@/lib/db/database";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { ASSESSMENT_TYPES, TEST_SETS, emptyKey, type Assessment, type AssessmentType, type TestSet } from "@/lib/types";
import { defaultSheetConfig } from "@/lib/db/defaults";
import { getSettings, saveAssessment, deleteAssessment } from "@/lib/db/repo";
import { formatDate, nowIso, uid } from "@/lib/utils";
import { examCodeFor } from "@/lib/sheets/exam-code";

export const Route = createFileRoute("/assessments")({ component: AssessmentsLayout });

function AssessmentsLayout() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  if (pathname !== "/assessments" && pathname.startsWith("/assessments/")) {
    return <Outlet />;
  }
  return <AssessmentsPage />;
}

function AssessmentsPage() {
  const list = useLiveQuery(() => db.assessments.orderBy("date").reverse().toArray()) ?? [];
  const students = useLiveQuery(() => db.students.toArray()) ?? [];
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [subject, setSubject] = useState("Mathematics");
  const [items, setItems] = useState(20);
  const [passing, setPassing] = useState(12);
  const [type, setType] = useState<AssessmentType>("Quiz");
  const [testSet, setTestSet] = useState<TestSet>("A");
  const [date, setDate] = useState(nowIso().slice(0, 10));
  const [instructions, setInstructions] = useState("Shade one bubble per item.");
  const [gradeLevel, setGradeLevel] = useState("");
  const [section, setSection] = useState("");

  const classes = useMemo(() => {
    const map = new Map<string, { gradeLevel: string; section: string }>();
    for (const s of students) {
      const key = `${s.gradeLevel}||${s.section}`;
      if (!map.has(key)) map.set(key, { gradeLevel: s.gradeLevel, section: s.section });
    }
    return Array.from(map.values()).sort(
      (a, b) => a.gradeLevel.localeCompare(b.gradeLevel) || a.section.localeCompare(b.section),
    );
  }, [students]);

  async function create() {
    const settings = await getSettings();
    const t = nowIso();
    const key = emptyKey(items);
    const a: Assessment = {
      id: uid("asm"),
      name: name || "Untitled assessment",
      subject,
      gradeLevel: gradeLevel || settings.defaultGrade,
      section: section || settings.defaultSection,
      teacher: settings.teacherName,
      schoolYear: settings.defaultSchoolYear,
      date,
      itemCount: items,
      passingScore: passing,
      instructions,
      answerKey: key,
      answerKeys: { A: key, B: emptyKey(items), C: emptyKey(items) },
      testSet,
      timeLimitMinutes: null,
      type,
      archived: false,
      examCode: "",
      sheetConfig: defaultSheetConfig({
        quizName: name || "Untitled assessment",
        subject,
        itemCount: items,
        teacher: settings.teacherName,
        school: settings.schoolName,
        instructions,
        rollDigits: settings.rollDigits,
        date,
        testSet,
      }),
      createdAt: t,
      updatedAt: t,
    };
    a.examCode = examCodeFor(a);
    a.sheetConfig.examCode = a.examCode;
    await saveAssessment(a);
    toast.success("Assessment saved. Open it to enter the answer key and print the sheet.");
    setOpen(false);
    setName("");
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl">Assessments</h1>
          <p className="text-sm text-muted">Create the test, enter the answer key, and download the bubble sheet in one place.</p>
        </div>
        <Button
          onClick={async () => {
            const settings = await getSettings();
            setGradeLevel(settings.defaultGrade);
            setSection(settings.defaultSection);
            setOpen(true);
          }}
        >
          Create assessment
        </Button>
      </header>
      <div className="grid gap-3">
        {list.map((a) => (
          <Card key={a.id} className="flex flex-wrap items-center justify-between gap-3 p-4 hover:border-line-strong">
            <Link to="/assessments/$id" params={{ id: a.id }} className="min-w-0 flex-1">
              <p className="font-medium">{a.name}</p>
              <p className="text-xs text-muted">
                {a.subject} · Grade {a.gradeLevel}-{a.section} · {a.itemCount} items · Date of test {formatDate(a.date)}
              </p>
            </Link>
            <div className="flex items-center gap-2">
              <Badge tone="accent">Set {a.testSet ?? "A"}</Badge>
              {a.archived ? <Badge>Archived</Badge> : <Badge>{a.type}</Badge>}
              <Link to="/assessments/$id" params={{ id: a.id }} className="text-sm text-accent underline">
                Open
              </Link>
              <button
                type="button"
                className="text-sm text-danger underline"
                onClick={async (e) => {
                  e.preventDefault();
                  if (!confirm(`Delete “${a.name}” and its scanned papers?`)) return;
                  await deleteAssessment(a.id);
                  toast.success("Assessment deleted.");
                }}
              >
                Delete
              </button>
            </div>
          </Card>
        ))}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogTitle>New assessment</DialogTitle>
          <div className="mt-4 space-y-3">
            <div>
              <Label>Name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Subject</Label>
                <Input value={subject} onChange={(e) => setSubject(e.target.value)} />
              </div>
              <div>
                <Label>Type</Label>
                <select
                  className="h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm"
                  value={type}
                  onChange={(e) => setType(e.target.value as AssessmentType)}
                >
                  {ASSESSMENT_TYPES.map((t) => (
                    <option key={t}>{t}</option>
                  ))}
                </select>
              </div>
              <div>
                <Label>Date of test</Label>
                <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
              </div>
              <div>
                <Label>Grade & section</Label>
                <select
                  className="h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm"
                  value={gradeLevel && section ? `${gradeLevel}||${section}` : ""}
                  onChange={(e) => {
                    const [g, s] = e.target.value.split("||");
                    setGradeLevel(g || "");
                    setSection(s || "");
                  }}
                >
                  <option value="">Choose a class…</option>
                  {classes.map((c) => (
                    <option key={`${c.gradeLevel}-${c.section}`} value={`${c.gradeLevel}||${c.section}`}>
                      Grade {c.gradeLevel} – {c.section}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label>Grade level</Label>
                <Input value={gradeLevel} onChange={(e) => setGradeLevel(e.target.value)} placeholder="9" />
              </div>
              <div>
                <Label>Section</Label>
                <Input value={section} onChange={(e) => setSection(e.target.value)} placeholder="A" />
              </div>
              <div>
                <Label>Set</Label>
                <select
                  className="h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm"
                  value={testSet}
                  onChange={(e) => setTestSet(e.target.value as TestSet)}
                >
                  {TEST_SETS.map((s) => (
                    <option key={s} value={s}>
                      Set {s}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label>Items</Label>
                <Input type="number" value={items} onChange={(e) => setItems(Number(e.target.value))} />
              </div>
              <div>
                <Label>Passing score</Label>
                <Input type="number" value={passing} onChange={(e) => setPassing(Number(e.target.value))} />
              </div>
            </div>
            <div>
              <Label>Instructions</Label>
              <Textarea value={instructions} onChange={(e) => setInstructions(e.target.value)} />
            </div>
            <p className="text-xs text-muted">After saving, open the assessment to enter the answer key and download the PNG bubble sheet.</p>
          </div>
          <div className="mt-4 flex justify-end gap-2">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={create}>Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
