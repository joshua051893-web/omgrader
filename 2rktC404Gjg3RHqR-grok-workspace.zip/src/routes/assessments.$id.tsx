import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import JSZip from "jszip";
import * as XLSX from "xlsx";
import { db } from "@/lib/db/database";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { deleteAssessment, deleteScan, saveAssessment } from "@/lib/db/repo";
import { rescoreAssessmentScans } from "@/lib/omr/rescore";
import { downloadBlob, nowIso, uid } from "@/lib/utils";
import { itemAnalysis, assessmentSummary } from "@/lib/gradebook/compute";
import { downloadAssessmentZip, resultsWorkbook } from "@/lib/reports/export";
import { renderSheetCanvas, canvasToBlob } from "@/lib/sheets/render-canvas";
import { canvasesToPdf } from "@/lib/sheets/export-pdf";
import { PAPER_SIZES, TEST_SETS, emptyKey, keysForSet, type Assessment } from "@/lib/types";
import { defaultSheetConfig } from "@/lib/db/defaults";
import { examCodeFor } from "@/lib/sheets/exam-code";

export const Route = createFileRoute("/assessments/$id")({ component: AssessmentDetail });

function AssessmentDetail() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const a = useLiveQuery(async () => (await db.assessments.get(id)) ?? null, [id]);
  const scans = useLiveQuery(() => db.scans.where("assessmentId").equals(id).toArray(), [id]) ?? [];
  const students = useLiveQuery(() => db.students.toArray()) ?? [];
  const [paste, setPaste] = useState("");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const summary = useMemo(() => (a ? assessmentSummary(a, scans) : null), [a, scans]);
  const items = useMemo(() => (a ? itemAnalysis(a, scans) : []), [a, scans]);

  if (a === undefined) return <p className="text-sm text-muted">Opening assessment…</p>;
  if (a === null) return <p className="text-muted">Assessment not found.</p>;
  const assessment: Assessment = {
    ...a,
    testSet: a.testSet ?? "A",
    answerKeys: a.answerKeys ?? { A: a.answerKey ?? emptyKey(a.itemCount || 20), B: emptyKey(a.itemCount || 20), C: emptyKey(a.itemCount || 20) },
    sheetConfig: a.sheetConfig ?? defaultSheetConfig({ quizName: a.name, itemCount: a.itemCount, date: a.date }),
    itemCount: a.itemCount || a.answerKey?.length || 20,
  };
  const activeSet = assessment.testSet;
  const key = keysForSet(assessment, activeSet);
  const choices = assessment.sheetConfig.choices;
  const cfg = {
    ...assessment.sheetConfig,
    itemCount: assessment.itemCount,
    quizName: assessment.name,
    date: assessment.date,
    testSet: activeSet,
    subject: assessment.subject,
    teacher: assessment.teacher,
    instructions: assessment.instructions,
    examCode: examCodeFor({ ...assessment, testSet: activeSet }),
  };

  async function persist(next: Assessment) {
    const k = keysForSet(next, next.testSet);
    await saveAssessment({
      ...next,
      answerKey: k,
      sheetConfig: { ...next.sheetConfig, date: next.date, testSet: next.testSet, itemCount: next.itemCount, quizName: next.name },
    });
  }

  async function setKey(next: string[], set = activeSet) {
    if (next.length !== assessment.itemCount) {
      toast.error("The answer key must have one answer for every item.");
      return;
    }
    const answerKeys = { ...(assessment.answerKeys ?? {}), [set]: next.map((x) => x.toUpperCase()) };
    const saved = {
      ...assessment,
      answerKeys,
      answerKey: answerKeys[assessment.testSet] ?? next,
      testSet: assessment.testSet,
    };
    await persist(saved);
    const n = await rescoreAssessmentScans(saved);
    toast.success(n ? `Answer key for Set ${set} saved. ${n} paper${n === 1 ? "" : "s"} rescored.` : `Answer key for Set ${set} saved.`);
  }

  async function downloadBlank() {
    const { canvas } = renderSheetCanvas(cfg, { dpi: 200 });
    const blob = await canvasToBlob(canvas);
    downloadBlob(blob, `${assessment.name.replace(/\s+/g, "-")}-set-${activeSet}.png`);
    setPreviewUrl(URL.createObjectURL(blob));
    toast.success("PNG saved.");
  }

  async function downloadPrefill() {
    const list = students.filter((s) => s.gradeLevel === assessment.gradeLevel && s.section === assessment.section);
    if (!list.length) {
      toast.error("No students in this class.");
      return;
    }
    const zip = new JSZip();
    for (const st of list) {
      const { canvas } = renderSheetCanvas(cfg, {
        student: st,
        fill: { answers: [], rollNumber: st.rollNumber },
        dpi: 200,
      });
      zip.file(`${st.rollNumber}-${st.fullName.replace(/\s+/g, "-")}.png`, await canvasToBlob(canvas));
    }
    downloadBlob(await zip.generateAsync({ type: "blob" }), `${assessment.name}-set-${activeSet}-png.zip`);
    toast.success(`Saved ${list.length} PNG sheets.`);
  }

  async function downloadBlankPdf() {
    const { canvas, layout } = renderSheetCanvas(cfg, { dpi: 160 });
    const blob = await canvasesToPdf([canvas], layout.widthMm, layout.heightMm);
    downloadBlob(blob, `${assessment.name.replace(/\s+/g, "-")}-set-${activeSet}.pdf`);
    toast.success("PDF saved.");
  }

  async function downloadPrefillPdf() {
    const list = students.filter((s) => s.gradeLevel === assessment.gradeLevel && s.section === assessment.section);
    if (!list.length) {
      toast.error("No students in this class.");
      return;
    }
    const canvases: HTMLCanvasElement[] = [];
    let widthMm = 210;
    let heightMm = 297;
    for (const st of list) {
      const { canvas, layout } = renderSheetCanvas(cfg, {
        student: st,
        fill: { answers: [], rollNumber: st.rollNumber },
        dpi: 150,
      });
      widthMm = layout.widthMm;
      heightMm = layout.heightMm;
      canvases.push(canvas);
    }
    const blob = await canvasesToPdf(canvases, widthMm, heightMm);
    downloadBlob(blob, `${assessment.name.replace(/\s+/g, "-")}-set-${activeSet}-prefilled.pdf`);
    toast.success(`Saved a ${list.length}-page PDF.`);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Link to="/assessments" className="text-sm text-muted">
            Assessments
          </Link>
          <h1 className="font-display mt-1 text-3xl">{assessment.name}</h1>
          <p className="text-sm text-muted">
            {assessment.subject} · Grade {assessment.gradeLevel}-{assessment.section} · {assessment.itemCount} items ·
            Passing {assessment.passingScore} · Date of test {assessment.date} · Set {activeSet}
          </p>
          <p className="mt-1 font-mono text-xs text-accent">Exam code {examCodeFor({ ...assessment, testSet: activeSet })}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link to="/scan" search={{ assessmentId: assessment.id }}>
            <Button>Scan papers</Button>
          </Link>
          <Button
            variant="outline"
            onClick={async () => {
              if (!confirm(`Delete “${assessment.name}” and all scanned papers for it? This cannot be undone.`)) return;
              await deleteAssessment(assessment.id);
              toast.success("Assessment deleted.");
              void navigate({ to: "/assessments" });
            }}
          >
            Delete assessment
          </Button>
        </div>
      </div>

      <Card className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <Label>Date of test</Label>
          <Input
            type="date"
            value={assessment.date}
            onChange={(e) => void persist({ ...assessment, date: e.target.value })}
          />
        </div>
        <div>
          <Label>Set (printed on the sheet)</Label>
          <div className="mt-1 flex gap-2">
            {TEST_SETS.map((s) => (
              <Button
                key={s}
                size="sm"
                variant={activeSet === s ? "default" : "outline"}
                onClick={() => void persist({ ...assessment, testSet: s })}
              >
                Set {s}
              </Button>
            ))}
          </div>
        </div>
        <div>
          <Label>Grade level</Label>
          <Input
            value={assessment.gradeLevel}
            onChange={(e) => void persist({ ...assessment, gradeLevel: e.target.value })}
          />
        </div>
        <div>
          <Label>Section</Label>
          <Input
            value={assessment.section}
            onChange={(e) => void persist({ ...assessment, section: e.target.value })}
          />
        </div>
        <div>
          <Label>Paper</Label>
          <select
            className="h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm"
            value={cfg.paper}
            onChange={(e) =>
              void persist({
                ...assessment,
                sheetConfig: { ...assessment.sheetConfig, paper: e.target.value as typeof cfg.paper },
              })
            }
          >
            {PAPER_SIZES.map((p) => (
              <option key={p}>{p}</option>
            ))}
          </select>
        </div>
        <div>
          <Label>Choices</Label>
          <select
            className="h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm"
            value={choices.join("")}
            onChange={(e) => {
              const map: Record<string, string[]> = {
                ABCD: ["A", "B", "C", "D"],
                ABCDE: ["A", "B", "C", "D", "E"],
                ABCDEF: ["A", "B", "C", "D", "E", "F"],
              };
              void persist({
                ...assessment,
                sheetConfig: { ...assessment.sheetConfig, choices: map[e.target.value] ?? ["A", "B", "C", "D"] },
              });
            }}
          >
            <option value="ABCD">A–D</option>
            <option value="ABCDE">A–E</option>
            <option value="ABCDEF">A–F</option>
          </select>
        </div>
      </Card>

      <Card>
        <CardTitle className="mb-1">Answer key — Set {activeSet}</CardTitle>
        <p className="mb-4 text-sm text-muted">
          This is where you put the correct answers. Switch Set A / B / C above to edit a different form. Scanning uses the set currently selected.
        </p>
        <div className="flex flex-wrap gap-2">
          {key.map((ans, i) => (
            <label key={i} className="flex flex-col items-center text-xs text-muted">
              {i + 1}
              <select
                className="mt-1 h-9 rounded-[var(--radius-sm)] border border-line bg-surface px-1 font-mono"
                value={ans}
                onChange={(e) => {
                  const next = [...key];
                  next[i] = e.target.value;
                  void setKey(next, activeSet);
                }}
              >
                {choices.map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </label>
          ))}
        </div>
        <Textarea
          className="mt-4"
          placeholder="Paste answers like A C B D A"
          value={paste}
          onChange={(e) => setPaste(e.target.value)}
        />
        <div className="mt-2 flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => void setKey(paste.trim().split(/[\s,;]+/).filter(Boolean), activeSet)}
          >
            Apply pasted key
          </Button>
          <input
            type="file"
            accept=".xlsx,.csv"
            className="text-sm"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              const wb = XLSX.read(await f.arrayBuffer(), { type: "array" });
              const sheet = wb.Sheets[wb.SheetNames[0]!];
              const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 }) as unknown[][];
              const answers = rows
                .map((r) => String(r[1] ?? r[0] ?? "").trim())
                .filter((x) => /^[A-Fa-f]$/.test(x));
              void setKey(answers, activeSet);
            }}
          />
        </div>
      </Card>

      <Card>
        <CardTitle className="mb-3">Bubble sheet</CardTitle>
        <p className="mb-3 text-sm text-muted">
          Blank or pre-filled sheets as PNG or PDF. Set {activeSet} and the date of test print on the header. Pre-filled sheets include name, section, and roll number.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={async () => {
              const st = students[0];
              const { canvas } = renderSheetCanvas(cfg, {
                student: st,
                fill: st ? { answers: [], rollNumber: st.rollNumber } : undefined,
                dpi: 150,
              });
              setPreviewUrl(URL.createObjectURL(await canvasToBlob(canvas)));
            }}
          >
            Preview
          </Button>
          <Button onClick={downloadBlank}>Download PNG</Button>
          <Button variant="outline" onClick={() => void downloadBlankPdf()}>
            Download PDF
          </Button>
          <Button variant="secondary" onClick={downloadPrefill}>
            Pre-filled class PNG
          </Button>
          <Button variant="secondary" onClick={() => void downloadPrefillPdf()}>
            Pre-filled class PDF
          </Button>
        </div>
        {previewUrl && (
          <img src={previewUrl} alt="Bubble sheet preview" className="mt-4 w-full max-w-xl rounded-[var(--radius-md)] border border-line" />
        )}
      </Card>

      <div className="grid gap-3 sm:grid-cols-4">
        <Mini label="Scanned" value={summary?.count ?? 0} />
        <Mini label="Average" value={summary ? summary.average.toFixed(1) : "—"} />
        <Mini label="Passed" value={summary?.passed ?? 0} />
        <Mini label="Did not meet" value={summary?.failed ?? 0} />
      </div>

      <Card className="overflow-x-auto p-0">
        <div className="flex items-center justify-between px-4 py-3">
          <CardTitle>Results</CardTitle>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                const buf = resultsWorkbook(assessment, scans, students);
                downloadBlob(
                  new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }),
                  `${assessment.name}-results.xlsx`,
                );
              }}
            >
              Download results
            </Button>
            <Button size="sm" variant="outline" onClick={() => downloadAssessmentZip(assessment)}>
              ZIP
            </Button>
          </div>
        </div>
        <table className="w-full min-w-[720px] text-sm">
          <thead className="text-left text-xs text-muted uppercase">
            <tr>
              <th className="px-4 py-2">Roll</th>
              <th>Student</th>
              <th>Score</th>
              <th>%</th>
              <th>Correct</th>
              <th>Wrong</th>
              <th>Blank</th>
              <th>Status</th>
              <th className="pr-4">Paper</th>
            </tr>
          </thead>
          <tbody>
            {scans.map((s) => {
              const st = students.find((x) => x.id === s.studentId);
              return (
                <tr key={s.id} className="border-t border-line">
                  <td className="px-4 py-2 font-mono">{s.rollNumber}</td>
                  <td>{st?.fullName ?? "Unknown"}</td>
                  <td>
                    {s.score}/{assessment.itemCount}
                  </td>
                  <td>{Math.round(s.percentage)}%</td>
                  <td>{s.correct}</td>
                  <td>{s.wrong}</td>
                  <td>{s.blank}</td>
                  <td>
                    <Badge tone={s.status === "passed" ? "ok" : s.status === "flagged" ? "warn" : "danger"}>
                      {s.status}
                    </Badge>
                  </td>
                  <td className="pr-4">
                    <div className="flex flex-wrap gap-2">
                      <Link to="/review/$id" params={{ id: s.id }} className="text-accent underline">
                        Review
                      </Link>
                      <button
                        type="button"
                        className="text-danger underline"
                        onClick={async () => {
                          if (!confirm(`Delete the scanned paper for roll ${s.rollNumber}?`)) return;
                          await deleteScan(s);
                          toast.success("Paper deleted.");
                        }}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {!scans.length && <p className="p-6 text-sm text-muted">No scanned papers yet. Scan a class, then review or delete each paper here.</p>}
      </Card>

      <Card className="overflow-x-auto p-0">
        <CardTitle className="px-4 py-3">Item analysis</CardTitle>
        <p className="px-4 pb-2 text-sm text-muted">
          Correct and wrong counts per item, plus how many students chose each letter.
        </p>
        <table className="w-full min-w-[720px] text-sm">
          <thead className="text-left text-xs text-muted uppercase">
            <tr>
              <th className="px-4 py-2">Item</th>
              <th>Key</th>
              <th>Correct</th>
              <th>Wrong</th>
              <th>Blank</th>
              {choices.map((c) => (
                <th key={c}>{c}</th>
              ))}
              <th>Difficulty</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it) => (
              <tr key={it.item} className="border-t border-line">
                <td className="px-4 py-2">{it.item + 1}</td>
                <td className="font-mono">{it.key}</td>
                <td>{it.correct}</td>
                <td>{it.wrong}</td>
                <td>{it.blank}</td>
                {choices.map((c) => (
                  <td key={c} className={c === it.key ? "font-medium text-ok" : ""}>
                    {it.optionCounts[c] ?? 0}
                  </td>
                ))}
                <td>{(it.difficulty * 100).toFixed(0)}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <div className="flex flex-wrap gap-2">
        <Button
          variant="outline"
          onClick={async () => {
            await persist({ ...assessment, archived: !assessment.archived });
            toast.success(assessment.archived ? "Restored." : "Archived.");
          }}
        >
          {assessment.archived ? "Restore" : "Archive"}
        </Button>
        <Button
          variant="outline"
          onClick={async () => {
            const copy: Assessment = {
              ...assessment,
              id: uid("asm"),
              name: `${assessment.name} (copy)`,
              date: nowIso().slice(0, 10),
              createdAt: nowIso(),
              archived: false,
            };
            await saveAssessment(copy);
            toast.success("Duplicated.");
          }}
        >
          Duplicate
        </Button>
      </div>
    </div>
  );
}

function Mini({ label, value }: { label: string; value: string | number }) {
  return (
    <Card className="p-4">
      <p className="text-xs text-muted uppercase">{label}</p>
      <p className="font-display mt-1 text-2xl tabular-nums">{value}</p>
    </Card>
  );
}
