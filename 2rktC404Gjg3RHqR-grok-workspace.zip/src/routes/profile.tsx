import { createFileRoute } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { db } from "@/lib/db/database";
import { DEFAULT_SETTINGS } from "@/lib/db/defaults";
import { blobUrl, putBlob, saveSettings } from "@/lib/db/repo";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { PhotoCropDialog } from "@/components/photo-crop";
import type { AppSettings } from "@/lib/types";

export const Route = createFileRoute("/profile")({ component: ProfilePage });

function ProfilePage() {
  const settings = useLiveQuery(() => db.settings.get("singleton")) ?? DEFAULT_SETTINGS;
  const [form, setForm] = useState<AppSettings>({ ...DEFAULT_SETTINGS, ...settings });
  const [photo, setPhoto] = useState<string | null>(null);
  const [cropSrc, setCropSrc] = useState<string | null>(null);
  const [cropOpen, setCropOpen] = useState(false);

  useEffect(() => {
    const merged = { ...DEFAULT_SETTINGS, ...settings };
    setForm(merged);
    void blobUrl(merged.photoBlobId).then(setPhoto);
  }, [settings]);

  function set<K extends keyof AppSettings>(k: K, v: AppSettings[K]) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl">Teacher profile</h1>
        <p className="text-sm text-muted">Shown on bubble sheets and reports. Stored only on this device.</p>
      </header>
      <Card className="grid gap-6 sm:grid-cols-[160px_minmax(0,1fr)]">
        <div className="space-y-3">
          <div className="aspect-square overflow-hidden rounded-[var(--radius-lg)] border border-line bg-bg">
            {photo ? (
              <img src={photo} alt="Profile" className="size-full object-cover" />
            ) : (
              <div className="flex size-full items-center justify-center text-sm text-muted">No photo</div>
            )}
          </div>
          <label className="block">
            <input
              type="file"
              accept="image/*"
              hidden
              onChange={(e) => {
                const f = e.target.files?.[0];
                e.target.value = "";
                if (!f) return;
                setCropSrc(URL.createObjectURL(f));
                setCropOpen(true);
              }}
            />
            <Button
              variant="outline"
              className="w-full"
              type="button"
              onClick={(e) => (e.currentTarget.previousElementSibling as HTMLInputElement)?.click()}
            >
              Upload photo
            </Button>
          </label>
          {photo && (
            <Button
              variant="ghost"
              className="w-full"
              type="button"
              onClick={() => {
                setCropSrc(photo);
                setCropOpen(true);
              }}
            >
              Crop photo
            </Button>
          )}
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="First name" value={form.teacherFirstName} onChange={(v) => set("teacherFirstName", v)} />
          <Field label="Last name" value={form.teacherLastName} onChange={(v) => set("teacherLastName", v)} />
          <Field label="Display name" value={form.teacherName} onChange={(v) => set("teacherName", v)} />
          <Field label="Position" value={form.position} onChange={(v) => set("position", v)} />
          <Field label="Contact number" value={form.contactNumber} onChange={(v) => set("contactNumber", v)} />
          <Field label="Email" value={form.email} onChange={(v) => set("email", v)} />
          <Field label="School name" value={form.schoolName} onChange={(v) => set("schoolName", v)} />
          <Field label="School ID" value={form.schoolId} onChange={(v) => set("schoolId", v)} />
          <div className="sm:col-span-2">
            <Label>School address</Label>
            <Textarea value={form.schoolAddress} onChange={(e) => set("schoolAddress", e.target.value)} />
          </div>
        </div>
      </Card>
      <Button
        onClick={async () => {
          const teacherName =
            form.teacherName || [form.teacherFirstName, form.teacherLastName].filter(Boolean).join(" ");
          await saveSettings({ ...form, teacherName });
          toast.success("Profile saved.");
        }}
      >
        Save profile
      </Button>
      <PhotoCropDialog
        open={cropOpen}
        src={cropSrc}
        onOpenChange={setCropOpen}
        onCropped={async (blob) => {
          const id = await putBlob("photo", blob, "profile.jpg");
          await saveSettings({ photoBlobId: id });
          const url = URL.createObjectURL(blob);
          setPhoto(url);
          setCropOpen(false);
          toast.success("Cropped photo saved.");
        }}
      />
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <Label>{label}</Label>
      <Input value={value ?? ""} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}
