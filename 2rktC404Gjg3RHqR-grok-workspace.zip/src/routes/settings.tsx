import { createFileRoute, Link } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { db } from "@/lib/db/database";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardTitle, CardDesc } from "@/components/ui/card";
import { DEFAULT_SETTINGS } from "@/lib/db/defaults";
import { saveSettings } from "@/lib/db/repo";
import { exportFullBackup, importFullBackup } from "@/lib/backup/backup";
import { ThemePicker } from "@/components/theme-toggle";
import { InstallCard } from "@/components/install-card";
import { FirebaseCard } from "@/components/firebase-card";
import { downloadAndroidPackage, downloadWindowsPortable } from "@/lib/portable/download";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const settings = useLiveQuery(() => db.settings.get("singleton")) ?? DEFAULT_SETTINGS;
  const backups = useLiveQuery(() => db.backups.orderBy("createdAt").reverse().toArray()) ?? [];
  const [form, setForm] = useState({ ...DEFAULT_SETTINGS, ...settings });

  useEffect(() => setForm({ ...DEFAULT_SETTINGS, ...settings }), [settings]);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl">Settings</h1>
        <p className="text-sm text-muted">Everything stays on this device. Export a backup before clearing the browser.</p>
      </header>

      <InstallCard />

      <Card className="space-y-3">
        <CardTitle>Download the app</CardTitle>
        <CardDesc>
          OMG is a web app, so a store-signed .exe or .apk cannot be compiled in the browser. These kits install it as its own window on Windows or as a home-screen app on Android. Use Backup if you move student records.
        </CardDesc>
        <div className="flex flex-wrap gap-2">
          <Button
            onClick={async () => {
              await downloadWindowsPortable();
              toast.success("Windows portable launcher downloaded.");
            }}
          >
            Download Windows app
          </Button>
          <Button
            variant="secondary"
            onClick={async () => {
              await downloadAndroidPackage();
              toast.success("Android install kit downloaded.");
            }}
          >
            Download Android app
          </Button>
        </div>
        <ol className="list-decimal space-y-1 pl-5 text-sm text-muted">
          <li>
            <strong className="text-ink">Windows:</strong> unzip the file, then double-click <em>Start OMG.bat</em>. Edge or Chrome opens OMG in its own window. Data is stored in the OMG-profile folder next to the launcher.
          </li>
          <li>
            <strong className="text-ink">Android:</strong> unzip, open <em>install.html</em> on the phone (or just open OMG in Chrome), then tap the menu → Install app / Add to Home screen.
          </li>
        </ol>
      </Card>

      <Card className="space-y-3">
        <CardTitle>Appearance</CardTitle>
        <CardDesc>Light and dark follow this device. System matches your phone or computer.</CardDesc>
        <ThemePicker />
      </Card>

      <Card className="space-y-3">
        <CardTitle>Class defaults</CardTitle>
        <CardDesc>
          Photo, school ID, and contact details are on{" "}
          <Link to="/profile" className="text-accent underline">
            Profile
          </Link>
          .
        </CardDesc>
        <div className="grid gap-3 sm:grid-cols-2">
          {(
            [
              ["defaultGrade", "Default grade"],
              ["defaultSection", "Default section"],
              ["defaultSchoolYear", "School year"],
            ] as const
          ).map(([k, label]) => (
            <div key={k}>
              <Label>{label}</Label>
              <Input value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
            </div>
          ))}
          <div>
            <Label>Roll digits</Label>
            <Input
              type="number"
              value={form.rollDigits}
              onChange={(e) => setForm({ ...form, rollDigits: Number(e.target.value) })}
            />
          </div>
        </div>
        <Button
          onClick={async () => {
            await saveSettings(form);
            toast.success("Saved.");
          }}
        >
          Save settings
        </Button>
      </Card>

      <FirebaseCard settings={{ ...DEFAULT_SETTINGS, ...settings }} />

      <Card className="space-y-3">
        <CardTitle>Backup & restore</CardTitle>
        <CardDesc>Creates a ZIP of the roster, assessments, scans, and marked papers. Use this to copy OMG to another computer.</CardDesc>
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => exportFullBackup()}>Export database</Button>
          <label>
            <input
              hidden
              type="file"
              accept=".zip"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                if (!confirm("Restore replaces current records on this device. Continue?")) return;
                try {
                  await importFullBackup(f);
                  toast.success("Backup restored.");
                } catch (err) {
                  toast.error(err instanceof Error ? err.message : "Restore failed.");
                }
              }}
            />
            <Button variant="outline" type="button" onClick={(e) => (e.currentTarget.previousElementSibling as HTMLInputElement)?.click()}>
              Import database
            </Button>
          </label>
        </div>
        <ul className="text-sm text-muted">
          {backups.map((b) => (
            <li key={b.id}>
              {new Date(b.createdAt).toLocaleString()} · {(b.size / 1024).toFixed(0)} KB
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
