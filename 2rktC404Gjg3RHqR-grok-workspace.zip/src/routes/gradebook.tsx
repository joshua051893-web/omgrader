import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import { ChevronRight, Table2 } from "lucide-react";
import { db } from "@/lib/db/database";
import { Card, CardDesc, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { encodeGid } from "@/lib/spreadsheet/records";

export const Route = createFileRoute("/gradebook")({ component: GradebookLayout });

function GradebookLayout() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  if (pathname !== "/gradebook" && pathname.startsWith("/gradebook/")) return <Outlet />;
  return <GradebookHome />;
}

function GradebookHome() {
  const students = useLiveQuery(() => db.students.toArray()) ?? [];
  const assessments = useLiveQuery(() => db.assessments.toArray()) ?? [];
  const scans = useLiveQuery(() => db.scans.toArray()) ?? [];

  const sections = new Map<
    string,
    { gradeLevel: string; section: string; students: number; subjects: string[]; tests: number; scanned: number }
  >();
  for (const st of students) {
    const key = `${st.gradeLevel}::${st.section}`;
    const cur = sections.get(key) ?? {
      gradeLevel: st.gradeLevel,
      section: st.section,
      students: 0,
      subjects: [],
      tests: 0,
      scanned: 0,
    };
    cur.students += 1;
    sections.set(key, cur);
  }
  for (const a of assessments.filter((x) => !x.archived)) {
    const key = `${a.gradeLevel}::${a.section}`;
    const cur = sections.get(key) ?? {
      gradeLevel: a.gradeLevel,
      section: a.section,
      students: 0,
      subjects: [],
      tests: 0,
      scanned: 0,
    };
    cur.tests += 1;
    if (a.subject && !cur.subjects.includes(a.subject)) cur.subjects.push(a.subject);
    sections.set(key, cur);
  }
  for (const s of scans) {
    const a = assessments.find((x) => x.id === s.assessmentId);
    if (!a) continue;
    const cur = sections.get(`${a.gradeLevel}::${a.section}`);
    if (cur) cur.scanned += 1;
  }

  const grouped = new Map<string, Array<ReturnType<typeof sections.get> & {}>>();
  for (const row of sections.values()) {
    const list = grouped.get(row.gradeLevel) ?? [];
    list.push(row);
    grouped.set(row.gradeLevel, list);
  }
  const grades = Array.from(grouped.keys()).sort();

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl">Gradebook</h1>
        <p className="text-sm text-muted">Open a section to work in a spreadsheet — formulas, formatting, print, and Excel download.</p>
      </header>
      {grades.map((g) => (
        <section key={g} className="space-y-3">
          <h2 className="font-display text-2xl">Grade {g}</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {(grouped.get(g) ?? [])
              .slice()
              .sort((a, b) => a!.section.localeCompare(b!.section))
              .map((row) => {
                const r = row!;
                return (
                  <Link key={`${r.gradeLevel}-${r.section}`} to="/gradebook/$gid" params={{ gid: encodeGid(r.gradeLevel, r.section) }}>
                    <Card className="h-full hover:border-line-strong">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <CardTitle>Section {r.section}</CardTitle>
                          <CardDesc className="mt-1">
                            {r.students} students · {r.tests} assessments · {r.scanned} scans
                          </CardDesc>
                        </div>
                        <ChevronRight className="size-4 text-muted" />
                      </div>
                      <div className="mt-3 flex flex-wrap gap-1">
                        {r.subjects.length ? (
                          r.subjects.map((sub) => (
                            <Badge key={sub} tone="accent">
                              {sub}
                            </Badge>
                          ))
                        ) : (
                          <Badge>No subjects yet</Badge>
                        )}
                      </div>
                      <p className="mt-3 flex items-center gap-2 text-xs text-muted">
                        <Table2 className="size-3.5" /> Spreadsheet with scanned tests
                      </p>
                    </Card>
                  </Link>
                );
              })}
          </div>
        </section>
      ))}
      {!grades.length && <p className="text-sm text-muted">Add students or assessments to see sections here.</p>}
    </div>
  );
}
