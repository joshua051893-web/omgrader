import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/admin")({
  component: function AdminRemoved() {
    return <Navigate to="/" />;
  },
});
