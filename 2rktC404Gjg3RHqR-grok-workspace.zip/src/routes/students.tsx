import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { db } from "@/lib/db/database";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  parseStudentFile,
  rowsToStudents,
  studentTemplateCsv,
  studentTemplateWorkbook,
  studentsToCsv,
  studentsToXlsx,
  validateImport,
  type ImportMode,
  type ImportRow,
} from "@/lib/students/import-export";
import { deleteStudent, upsertStudent } from "@/lib/db/repo";
import { downloadBlob } from "@/lib/utils";
import type { Student } from "@/lib/types";

export const Route = createFileRoute("/students")({ component: StudentsLayout });

function StudentsLayout() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  if (pathname !== "/students" && pathname.startsWith("/students/")) {
    return <Outlet />;
  }
  return <StudentsPage />;
}

function emptyForm(): Omit<Student, "id" | "createdAt" | "updatedAt"> {
  return {
    rollNumber: "",
    lrn: "",
    firstName: "",
    middleName: "",
    lastName: "",
    fullName: "",
    gradeLevel: "9",
    section: "A",
    schoolYear: "2026-2027",
    extra: "",
  };
}

function StudentsPage() {
  const students = useLiveQuery(() => db.students.toArray()) ?? [];
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Student | null>(null);
  const [form, setForm] = useState(emptyForm());
  const [importOpen, setImportOpen] = useState(false);
  const [preview, setPreview] = useState<ImportRow[] | null>(null);
  const [mode, setMode] = useState<ImportMode>("add");

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return students
      .filter((st) => {
        if (!s) return true;
        return [st.fullName, st.rollNumber, st.lrn, st.gradeLevel, st.section].join(" ").toLowerCase().includes(s);
      })
      .sort((a, b) => a.rollNumber.localeCompare(b.rollNumber));
  }, [students, q]);

  function startNew() {
    setEditing(null);
    setForm(emptyForm());
    setOpen(true);
  }
  function startEdit(st: Student) {
    setEditing(st);
    setForm({ ...st });
    setOpen(true);
  }

  async function save() {
    if (!form.rollNumber || !form.fullName.trim() || !form.gradeLevel || !form.section || !form.schoolYear) {
      toast.error("Roll number, full name, grade, section, and school year are required.");
      return;
    }
    const clash = students.find(
      (s) => s.rollNumber === form.rollNumber.padStart(3, "0") && s.id !== editing?.id,
    );
    if (clash) {
      toast.error("That roll number is already assigned.");
      return;
    }
    await upsertStudent({ ...form, id: editing?.id });
    toast.success(editing ? "Student updated." : "Student added.");
    setOpen(false);
  }

  async function onImportFile(file: File) {
    const buf = await file.arrayBuffer();
    const rows = validateImport(parseStudentFile(buf, file.name), students);
    setPreview(rows);
  }

  async function commitImport() {
    if (!preview) return;
    const next = rowsToStudents(preview, students, mode);
    if (mode === "replace") {
      await db.students.clear();
    }
    await db.students.bulkPut(next);
    toast.success("Student list updated.");
    setImportOpen(false);
    setPreview(null);
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl">Students</h1>
          <p className="text-sm text-muted">Roster for quizzes, scans, and the gradebook.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => {
              const buf = studentTemplateWorkbook();
              downloadBlob(new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }), "student-template.xlsx");
            }}
          >
            Download student template
          </Button>
          <Button
            variant="outline"
            onClick={() => downloadBlob(new Blob([studentTemplateCsv()], { type: "text/csv" }), "student-template.csv")}
          >
            CSV template
          </Button>
          <Button variant="outline" onClick={() => setImportOpen(true)}>
            Import
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              const buf = studentsToXlsx(students);
              downloadBlob(new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }), "students.xlsx");
            }}
          >
            Export Excel
          </Button>
          <Button onClick={startNew}>Add student</Button>
        </div>
      </header>

      <Input placeholder="Search name, roll, grade, section" value={q} onChange={(e) => setQ(e.target.value)} />

      <Card className="overflow-x-auto p-0">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="border-b border-line text-xs tracking-wide text-muted uppercase">
            <tr>
              <th className="px-4 py-3">Roll</th>
              <th>Full name</th>
              <th>Grade</th>
              <th>Section</th>
              <th>SY</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {filtered.map((st) => (
              <tr key={st.id} className="border-b border-line last:border-0">
                <td className="px-4 py-3 font-mono tabular-nums">{st.rollNumber}</td>
                <td>
                  <Link to="/students/$id" params={{ id: st.id }} className="font-medium hover:underline">
                    {st.fullName}
                  </Link>
                </td>
                <td>{st.gradeLevel}</td>
                <td>{st.section}</td>
                <td className="text-muted">{st.schoolYear}</td>
                <td className="px-3 text-right">
                  <Button variant="ghost" size="sm" onClick={() => startEdit(st)}>
                    Edit
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={async () => {
                      if (!confirm(`Remove ${st.fullName} from the roster?`)) return;
                      await deleteStudent(st.id);
                      toast.success("Student removed.");
                    }}
                  >
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!filtered.length && <p className="p-6 text-sm text-muted">No students match this search.</p>}
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogTitle>{editing ? "Edit student" : "Add student"}</DialogTitle>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {(
              [
                ["rollNumber", "Roll number"],
                ["fullName", "Full name"],
                ["gradeLevel", "Grade level"],
                ["section", "Section"],
                ["schoolYear", "School year"],
              ] as const
            ).map(([key, label]) => (
              <div key={key} className="space-y-1">
                <Label>{label}</Label>
                <Input value={form[key]} onChange={(e) => setForm({ ...form, [key]: e.target.value })} />
              </div>
            ))}
            <div className="space-y-1 sm:col-span-2">
              <Label>Notes</Label>
              <Textarea value={form.extra} onChange={(e) => setForm({ ...form, extra: e.target.value })} />
            </div>
          </div>
          <div className="mt-4 flex justify-end gap-2">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={save}>Save</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={importOpen} onOpenChange={setImportOpen}>
        <DialogContent className="max-w-3xl">
          <DialogTitle>Import students</DialogTitle>
          <p className="mt-1 text-sm text-muted">Existing records are not erased unless you choose Replace.</p>
          <input
            className="mt-4 text-sm"
            type="file"
            accept=".xlsx,.xls,.csv"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void onImportFile(f);
            }}
          />
          <div className="mt-3 flex flex-wrap gap-2">
            {(["add", "update", "replace"] as ImportMode[]).map((m) => (
              <Button key={m} size="sm" variant={mode === m ? "default" : "outline"} onClick={() => setMode(m)}>
                {m === "add" ? "Add new" : m === "update" ? "Update existing" : "Replace list"}
              </Button>
            ))}
          </div>
          {preview && (
            <div className="mt-4 max-h-72 overflow-auto text-sm">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-xs text-muted">
                    <th>Row</th>
                    <th>Roll</th>
                    <th>Name</th>
                    <th>Issues</th>
                  </tr>
                </thead>
                <tbody>
                  {preview.map((r) => (
                    <tr key={r.row} className="border-t border-line">
                      <td>{r.row}</td>
                      <td>{r.rollNumber}</td>
                      <td>
                        {r.fullName}
                      </td>
                      <td>
                        {r.errors.map((e) => (
                          <Badge key={e} tone="danger" className="mr-1">
                            {e}
                          </Badge>
                        ))}
                        {r.warnings.map((e) => (
                          <Badge key={e} tone="warn" className="mr-1">
                            {e}
                          </Badge>
                        ))}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div className="mt-4 flex justify-end gap-2">
            <Button variant="outline" onClick={() => setImportOpen(false)}>
              Cancel
            </Button>
            <Button disabled={!preview} onClick={commitImport}>
              Save import
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
