import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/register")({
  component: function RegisterDisabled() {
    return <Navigate to="/" />;
  },
});
