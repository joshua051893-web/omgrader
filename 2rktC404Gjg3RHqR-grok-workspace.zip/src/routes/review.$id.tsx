import { createFileRoute, Link } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { db } from "@/lib/db/database";
import { Button } from "@/components/ui/button";
import { Card, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { blobUrl, putBlob, saveScan } from "@/lib/db/repo";
import { keysForSet } from "@/lib/types";
import type { ScanResult, ScanStatus } from "@/lib/types";
import { AnchorAdjust } from "@/components/scan/anchor-adjust";
import { renderMarkedPaper, scoreDetection, type OmRDetection } from "@/lib/omr/scan";
import { canvasToBlob } from "@/lib/sheets/render-canvas";
import { padRoll } from "@/lib/utils";

export const Route = createFileRoute("/review/$id")({ component: ReviewPage });

function ReviewPage() {
  const { id } = Route.useParams();
  const scan = useLiveQuery(() => db.scans.get(id), [id]);
  const assessment = useLiveQuery(() => (scan ? db.assessments.get(scan.assessmentId) : undefined), [scan?.assessmentId]);
  const students = useLiveQuery(() => db.students.toArray()) ?? [];
  const [orig, setOrig] = useState<string | null>(null);
  const [marked, setMarked] = useState<string | null>(null);
  const [roll, setRoll] = useState("");
  const [answers, setAnswers] = useState<Array<string | null>>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!scan) return;
    setRoll(scan.rollNumber);
    setAnswers(scan.answers);
    void blobUrl(scan.originalBlobId).then(setOrig);
    void blobUrl(scan.markedBlobId).then(setMarked);
  }, [scan?.id]);

  if (!scan || !assessment) return <p className="text-muted">Sheet not found.</p>;
  const current: ScanResult = scan;
  const asm = assessment;
  const key = keysForSet(asm);

  async function apply() {
    const padded = padRoll(roll);
    const student = students.find((s) => s.rollNumber === padded || s.rollNumber === roll);
    const correct = answers.reduce((n, a, i) => n + (a && a === key[i] ? 1 : 0), 0);
    const blank = answers.filter((a) => !a).length;
    const wrong = asm.itemCount - correct - blank;
    const percentage = (correct / asm.itemCount) * 100;
    const status: ScanStatus = correct >= asm.passingScore ? "passed" : "failed";
    await saveScan({
      ...current,
      rollNumber: padded || roll,
      studentId: student?.id ?? null,
      answers,
      correct,
      wrong,
      blank,
      score: correct,
      percentage,
      status,
      flags: student ? current.flags.filter((f) => f !== "missing_student") : ["missing_student"],
      reviewed: true,
    });
    toast.success("Corrections saved.");
  }

  async function onReread(detection: OmRDetection) {
    setBusy(true);
    try {
      const peers = (await db.scans.where("assessmentId").equals(asm.id).toArray())
        .filter((s) => s.id !== current.id)
        .map((s) => s.rollNumber);
      const scored = scoreDetection(asm, detection, students, peers);
      const student = students.find((s) => s.id === scored.studentId);
      const markedCanvas = await renderMarkedPaper(detection.warped, asm, scored, student?.fullName);
      const blob = await canvasToBlob(markedCanvas);
      const markedBlobId = await putBlob("marked", blob, `${current.id}-marked.png`);
      await saveScan({
        ...current,
        ...scored,
        id: current.id,
        originalBlobId: current.originalBlobId,
        markedBlobId,
        createdAt: current.createdAt,
        reviewed: true,
      });
      setAnswers(scored.answers);
      setRoll(scored.rollNumber);
      setMarked(URL.createObjectURL(blob));
      toast.success(
        detection.valid
          ? `Re-read with your markers: ${scored.score}/${asm.itemCount} (${scored.percentage.toFixed(0)}%).`
          : "Those markers could not lock the sheet. Drag them onto the printed squares and try again.",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <Link to="/scan" className="text-sm text-muted">
          Scan papers
        </Link>
        <h1 className="font-display mt-1 text-3xl">Manual review</h1>
        <p className="text-sm text-muted">
          Set {asm.testSet ?? "A"} · Confidence {(current.confidence * 100).toFixed(0)}% · {current.flags.join(", ") || "No flags"}
        </p>
      </div>

      <Card>
        <CardTitle className="mb-2">Adjust markers</CardTitle>
        <p className="mb-3 text-sm text-muted">
          Drag TL, TR, BL, and BR onto the printed corner squares. Green circles are the answer-key bubbles. Nudge the grid if they sit off the circles, then re-read.
        </p>
        {orig ? (
          <AnchorAdjust src={orig} assessment={asm} busy={busy} onReread={onReread} />
        ) : (
          <p className="text-sm text-muted">No original image.</p>
        )}
      </Card>

      <Card>
        <CardTitle className="mb-2">Marked copy</CardTitle>
        {marked ? (
          <img src={marked} alt="Marked paper" className="w-full max-w-xl rounded-[var(--radius-md)]" />
        ) : (
          <p className="text-sm text-muted">No marked copy yet. Re-read after placing the markers.</p>
        )}
      </Card>

      <Card className="space-y-3">
        <CardTitle>Identification & answers</CardTitle>
        <Input value={roll} onChange={(e) => setRoll(e.target.value)} />
        <p className="text-sm text-muted">
          {students.find((s) => s.rollNumber === padRoll(roll) || s.rollNumber === roll)?.fullName ?? "No matching student"}
        </p>
        <div className="flex flex-wrap gap-2">
          {answers.map((ans, i) => (
            <label key={i} className="text-xs text-muted">
              {i + 1}
              <select
                className="ml-1 h-8 rounded border border-line bg-surface"
                value={ans ?? ""}
                onChange={(e) => {
                  const next = [...answers];
                  next[i] = e.target.value || null;
                  setAnswers(next);
                }}
              >
                <option value="">—</option>
                {asm.sheetConfig.choices.map((c) => (
                  <option key={c} value={c}>
                    {c}
                    {key[i] === c ? " ✓" : ""}
                  </option>
                ))}
              </select>
            </label>
          ))}
        </div>
        <Button onClick={() => void apply()}>Save corrections</Button>
      </Card>
    </div>
  );
}
