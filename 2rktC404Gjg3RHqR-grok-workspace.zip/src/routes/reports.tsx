import { createFileRoute, Link } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import { useMemo, useState } from "react";
import { db } from "@/lib/db/database";
import { Card, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { assessmentSummary, itemAnalysis } from "@/lib/gradebook/compute";
import { wrongAnswerSimilarity } from "@/lib/gradebook/similarity";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { downloadAssessmentZip } from "@/lib/reports/export";

export const Route = createFileRoute("/reports")({ component: ReportsPage });

function ReportsPage() {
  const assessments = useLiveQuery(() => db.assessments.toArray()) ?? [];
  const scans = useLiveQuery(() => db.scans.toArray()) ?? [];
  const students = useLiveQuery(() => db.students.toArray()) ?? [];
  const [aid, setAid] = useState<string>("");
  const latest = assessments.find((a) => a.id === aid) ?? assessments[0];
  const forA = latest ? scans.filter((s) => s.assessmentId === latest.id) : [];
  const summary = latest ? assessmentSummary(latest, forA) : null;
  const items = latest ? itemAnalysis(latest, forA) : [];
  const similarity = useMemo(
    () => (latest ? wrongAnswerSimilarity(latest, forA, students) : []),
    [latest, forA, students],
  );
  const dist = [0, 0, 0, 0, 0];
  for (const s of forA) {
    const b = Math.min(4, Math.floor(s.percentage / 20));
    dist[b]++;
  }
  const chart = ["0-19", "20-39", "40-59", "60-79", "80-100"].map((name, i) => ({ name, n: dist[i] }));
  const choices = latest?.sheetConfig.choices ?? ["A", "B", "C", "D"];

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl">Reports</h1>
        <p className="text-sm text-muted">Item analysis, score distribution, and wrong-answer similarity by section.</p>
      </header>
      {latest && summary ? (
        <>
          <div className="flex flex-wrap items-end gap-3">
            <div className="min-w-52 flex-1">
              <p className="text-xs font-medium tracking-wide text-muted uppercase">Assessment</p>
              <select
                className="mt-1 h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm"
                value={latest.id}
                onChange={(e) => setAid(e.target.value)}
              >
                {assessments.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name} · Set {a.testSet ?? "A"} · {a.date}
                  </option>
                ))}
              </select>
            </div>
            <Link className="text-sm text-accent underline" to="/assessments/$id" params={{ id: latest.id }}>
              Open assessment
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="Highest" value={summary.highest} />
            <Stat label="Lowest" value={summary.lowest} />
            <Stat label="Average" value={summary.average.toFixed(1)} />
            <Stat label="Median" value={summary.median} />
          </div>
          <Card className="h-64">
            <CardTitle className="mb-2">Score distribution</CardTitle>
            <ResponsiveContainer width="100%" height="80%">
              <BarChart data={chart}>
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="n" fill="#215c4a" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          <Card className="overflow-x-auto p-0">
            <CardTitle className="px-4 py-3">Item analysis</CardTitle>
            <table className="w-full min-w-[800px] text-sm">
              <thead className="text-left text-xs text-muted uppercase">
                <tr>
                  <th className="px-4 py-2">Item</th>
                  <th>Key</th>
                  <th>Correct</th>
                  <th>Wrong</th>
                  <th>Blank</th>
                  {choices.map((c) => (
                    <th key={c}>{c}</th>
                  ))}
                  <th>Correct %</th>
                </tr>
              </thead>
              <tbody>
                {items.map((it) => (
                  <tr key={it.item} className="border-t border-line">
                    <td className="px-4 py-2">{it.item + 1}</td>
                    <td className="font-mono">{it.key}</td>
                    <td>{it.correct}</td>
                    <td>{it.wrong}</td>
                    <td>{it.blank}</td>
                    {choices.map((c) => (
                      <td key={c} className={c === it.key ? "font-medium text-ok" : ""}>
                        {it.optionCounts[c] ?? 0}
                      </td>
                    ))}
                    <td>{(it.difficulty * 100).toFixed(0)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>

          <Card className="overflow-x-auto p-0">
            <div className="px-4 py-3">
              <CardTitle>Wrong-answer similarity by section</CardTitle>
              <p className="mt-1 text-sm text-muted">
                For each pair of students, the index is the share of items they both missed where they chose the same letter.
                Pairs at 60% or higher with at least 3 shared wrong items are flagged.
              </p>
            </div>
            {similarity.map((sec) => (
              <div key={sec.section} className="border-t border-line px-4 py-3">
                <div className="mb-2 flex flex-wrap items-center gap-2">
                  <p className="font-medium">Section {sec.section}</p>
                  <Badge>Average {sec.averageIndex.toFixed(0)}%</Badge>
                  {sec.highPairs > 0 && <Badge tone="warn">{sec.highPairs} high-similarity pairs</Badge>}
                </div>
                <table className="w-full min-w-[640px] text-sm">
                  <thead className="text-left text-xs text-muted uppercase">
                    <tr>
                      <th className="py-1">Student A</th>
                      <th>Student B</th>
                      <th>Same wrong answers</th>
                      <th>Both wrong</th>
                      <th>Similarity</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sec.pairs.slice(0, 20).map((p) => (
                      <tr key={`${p.aRoll}-${p.bRoll}`} className="border-t border-line">
                        <td className="py-2">
                          {p.aName} ({p.aRoll})
                        </td>
                        <td>
                          {p.bName} ({p.bRoll})
                        </td>
                        <td>{p.sharedWrong}</td>
                        <td>{p.bothWrong}</td>
                        <td>
                          <Badge tone={p.index >= 60 && p.bothWrong >= 3 ? "warn" : "neutral"}>{p.index}%</Badge>
                        </td>
                      </tr>
                    ))}
                    {!sec.pairs.length && (
                      <tr>
                        <td colSpan={5} className="py-3 text-muted">
                          Need at least two scanned papers in this section.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            ))}
            {!similarity.length && <p className="px-4 pb-4 text-sm text-muted">Scan papers to compute similarity.</p>}
          </Card>

          <Button variant="outline" onClick={() => downloadAssessmentZip(latest)}>
            Download assessment ZIP
          </Button>
        </>
      ) : (
        <p className="text-sm text-muted">Scan an assessment to populate reports.</p>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <Card className="p-4">
      <p className="text-xs text-muted uppercase">{label}</p>
      <p className="font-display mt-1 text-2xl tabular-nums">{value}</p>
    </Card>
  );
}
