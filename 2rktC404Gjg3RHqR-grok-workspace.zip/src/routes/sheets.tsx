import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/sheets")({
  component: function SheetsRedirect() {
    return <Navigate to="/assessments" />;
  },
});
