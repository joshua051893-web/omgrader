import { createFileRoute, Link } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { db } from "@/lib/db/database";
import { Button } from "@/components/ui/button";
import { Card, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LiveScanner } from "@/components/scan/live-scanner";
import { ScanPromptDialog, type ScanPrompt } from "@/components/scan/scan-prompt";
import { detectSheet, renderMarkedPaper, scoreDetection } from "@/lib/omr/scan";
import { findDuplicateScan, findStudentByRoll, matchScannedExam, matchingAssessmentForStudent, studentInClass } from "@/lib/omr/exam-match";
import { canvasToBlob, renderSheetCanvas } from "@/lib/sheets/render-canvas";
import { paperDims } from "@/lib/sheets/layout";
import { renderWarpedSample } from "@/lib/omr/sample-scan";
import { deleteScan, putBlob, saveScan } from "@/lib/db/repo";
import { downloadBlob, nowIso, padRoll, uid } from "@/lib/utils";
import { keysForSet, type Assessment, type ScanResult } from "@/lib/types";
import { loadImageElement } from "@/lib/omr/image";
import { pdfFileToCanvases } from "@/lib/omr/pdf-pages";
import { examCodeFor } from "@/lib/sheets/exam-code";
import { useAccess } from "@/lib/access/context";
import { assertCanScan } from "@/lib/access/policy";

type Search = { assessmentId?: string };

export const Route = createFileRoute("/scan")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    assessmentId: typeof s.assessmentId === "string" ? s.assessmentId : undefined,
  }),
  component: ScanPage,
});

function ScanPage() {
  const { assessmentId } = Route.useSearch();
  const { user } = useAccess();
  const assessments = useLiveQuery(() => db.assessments.toArray()) ?? [];
  const students = useLiveQuery(() => db.students.toArray()) ?? [];
  const [aid, setAid] = useState(assessmentId ?? "");
  const selected = assessments.find((a) => a.id === (aid || assessmentId)) ?? assessments[0];
  const scans =
    useLiveQuery(() => (selected ? db.scans.where("assessmentId").equals(selected.id).toArray() : []), [selected?.id]) ??
    [];
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");
  const [sampleUrl, setSampleUrl] = useState<string | null>(null);
  const [sampleCanvas, setSampleCanvas] = useState<HTMLCanvasElement | null>(null);
  const [prompt, setPrompt] = useState<ScanPrompt | null>(null);
  const selectedRef = useRef(selected);
  selectedRef.current = selected;
  const assessmentsRef = useRef(assessments);
  assessmentsRef.current = assessments;
  const studentsRef = useRef(students);
  studentsRef.current = students;

  function waitReroute(from: Assessment, to: Assessment, reason: "wrong_exam" | "wrong_section") {
    return new Promise<boolean>((resolve) => {
      setPrompt({
        type: "reroute",
        from,
        to,
        reason,
        resolve: (saveThere) => {
          setPrompt(null);
          resolve(saveThere);
        },
      });
    });
  }

  function waitUnknown(code: string, current: Assessment) {
    return new Promise<boolean>((resolve) => {
      setPrompt({
        type: "unknown",
        code,
        current,
        resolve: (keep) => {
          setPrompt(null);
          resolve(keep);
        },
      });
    });
  }

  function waitDuplicate(args: {
    assessment: Assessment;
    roll: string;
    studentName: string;
    previous: ScanResult;
    incomingScore: string;
  }) {
    return new Promise<boolean>((resolve) => {
      setPrompt({
        type: "duplicate",
        ...args,
        resolve: (replace) => {
          setPrompt(null);
          resolve(replace);
        },
      });
    });
  }

  function waitBlocked(message: string) {
    return new Promise<void>((resolve) => {
      setPrompt({
        type: "blocked",
        message,
        resolve: () => {
          setPrompt(null);
          resolve();
        },
      });
    });
  }

  async function processCanvas(canvas: HTMLCanvasElement, filename: string): Promise<ScanResult | null> {
    let assessment = selectedRef.current;
    if (!assessment) throw new Error("Choose an assessment first.");
    const roster = studentsRef.current;
    const list = assessmentsRef.current;
    const digits = assessment.sheetConfig.rollDigits;

    let detection = await detectSheet(canvas, assessment);
    const match = matchScannedExam(detection.examCode, assessment, list);

    if (match.kind === "wrong_exam" || match.kind === "wrong_section") {
      toast.warning(
        match.kind === "wrong_section"
          ? `This paper is for Grade ${match.assessment.gradeLevel}-${match.assessment.section}.`
          : `This paper is for ${match.assessment.name}.`,
      );
      const saveThere = await waitReroute(assessment, match.assessment, match.kind);
      if (!saveThere) {
        toast.message("Scan cancelled.");
        return null;
      }
      setAid(match.assessment.id);
      assessment = match.assessment;
      detection = await detectSheet(canvas, assessment);
    } else if (match.kind === "unknown") {
      const byRoll = findStudentByRoll(roster, detection.rollNumber, digits);
      if (byRoll && !studentInClass(byRoll, assessment)) {
        const dest = matchingAssessmentForStudent(byRoll, assessment, list);
        if (!dest || dest.id === assessment.id) {
          await waitBlocked(
            `Roll ${padRoll(detection.rollNumber, digits)} belongs to Grade ${byRoll.gradeLevel}-${byRoll.section}. There is no matching test for that section, so this sheet was not saved.`,
          );
          return null;
        }
        const saveThere = await waitReroute(assessment, dest, "wrong_section");
        if (!saveThere) {
          toast.message("Scan cancelled.");
          return null;
        }
        setAid(dest.id);
        assessment = dest;
        detection = await detectSheet(canvas, assessment);
      } else {
        toast.warning(`Exam code ${match.code} is not on file.`);
        const keep = await waitUnknown(match.code, assessment);
        if (!keep) return null;
      }
    } else if (match.kind === "none" || match.kind === "ok") {
      const byRoll = findStudentByRoll(roster, detection.rollNumber, digits, assessment);
      if (byRoll && !studentInClass(byRoll, assessment)) {
        const dest =
          (match.kind === "ok" ? match.assessment : null) ?? matchingAssessmentForStudent(byRoll, assessment, list);
        if (!dest || dest.id === assessment.id) {
          await waitBlocked(
            `This paper is for Grade ${byRoll.gradeLevel}-${byRoll.section}, not Grade ${assessment.gradeLevel}-${assessment.section}. It was not saved on the selected class.`,
          );
          return null;
        }
        toast.warning(`Wrong section — this paper is for Grade ${dest.gradeLevel}-${dest.section}.`);
        const saveThere = await waitReroute(assessment, dest, "wrong_section");
        if (!saveThere) {
          toast.message("Scan cancelled.");
          return null;
        }
        setAid(dest.id);
        assessment = dest;
        detection = await detectSheet(canvas, assessment);
      }
    }

    const existing = await db.scans.where("assessmentId").equals(assessment.id).toArray();
    const scored = scoreDetection(
      assessment,
      detection,
      roster,
      existing.map((s) => s.rollNumber),
    );
    scored.assessmentId = assessment.id;
    const student = roster.find((s) => s.id === scored.studentId);
    if (student && !studentInClass(student, assessment)) {
      await waitBlocked(
        `This paper belongs to Grade ${student.gradeLevel}-${student.section}. It was not saved under Grade ${assessment.gradeLevel}-${assessment.section}.`,
      );
      return null;
    }

    const dup = findDuplicateScan(existing, assessment.id, scored.rollNumber, scored.studentId, digits);
    if (dup) {
      toast.warning(`Already scanned: roll ${padRoll(scored.rollNumber, digits) || scored.rollNumber}.`);
      const replace = await waitDuplicate({
        assessment,
        roll: padRoll(scored.rollNumber, digits) || scored.rollNumber,
        studentName: student?.fullName ?? "",
        previous: dup,
        incomingScore: `${scored.score}/${assessment.itemCount} (${Math.round(scored.percentage)}%)`,
      });
      if (!replace) {
        toast.message("Scan cancelled. Previous paper kept.");
        return null;
      }
      await deleteScan(dup);
      scored.flags = scored.flags.filter((f) => f !== "duplicate_roll");
      if (!scored.flags.length) {
        scored.status = scored.score >= assessment.passingScore ? "passed" : "failed";
      }
    } else if (user) {
      await assertCanScan(user, 1);
    }

    const blob = await canvasToBlob(canvas, "image/jpeg");
    const marked = await renderMarkedPaper(detection.warped, assessment, scored, student?.fullName);
    const markedBlob = await canvasToBlob(marked, "image/png");
    const originalBlobId = await putBlob("scan", blob, filename);
    const markedBlobId = await putBlob("marked", markedBlob, filename.replace(/\.\w+$/, "") + "-marked.png");
    const rec: ScanResult = {
      ...scored,
      id: uid("scan"),
      originalBlobId,
      markedBlobId,
      scannedByUserId: user?.id,
      createdAt: nowIso(),
      updatedAt: nowIso(),
    };
    await saveScan(rec);
    return rec;
  }

  async function onFiles(files: FileList | null) {
    if (!files?.length || !selected) return;
    setBusy(true);
    let saved = 0;
    let skipped = 0;
    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i]!;
        setProgress(`Reading ${file.name} (${i + 1}/${files.length})`);
        if (file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf")) {
          const pages = await pdfFileToCanvases(file);
          for (let p = 0; p < pages.length; p++) {
            setProgress(`PDF ${file.name} · page ${p + 1}/${pages.length}`);
            const rec = await processCanvas(pages[p]!, `${file.name.replace(/\.pdf$/i, "")}-p${p + 1}.jpg`);
            if (rec) saved++;
            else skipped++;
          }
          continue;
        }
        const c = await loadImageElement(file);
        const rec = await processCanvas(c, file.name);
        if (rec) saved++;
        else skipped++;
      }
      toast.success(`Scanning finished. ${saved} saved${skipped ? `, ${skipped} skipped` : ""}.`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "The answer sheet could not be processed.");
    } finally {
      setBusy(false);
      setProgress("");
    }
  }

  async function makeSample() {
    if (!selected) return null;
    const classStudents = students.filter(
      (s) => s.gradeLevel === selected.gradeLevel && s.section === selected.section,
    );
    const st = classStudents[0] ?? students[0];
    if (!st) {
      toast.error("Add a student first so the sample sheet can be pre-filled.");
      return null;
    }
    setBusy(true);
    setProgress("Photographing a slightly skewed sheet…");
    try {
      await new Promise((r) => setTimeout(r, 30));
      const photo = renderWarpedSample(selected, st);
      setSampleCanvas(photo);
      const blob = await canvasToBlob(photo, "image/jpeg");
      const url = URL.createObjectURL(blob);
      setSampleUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev);
        return url;
      });
      return { photo, blob, student: st };
    } finally {
      setBusy(false);
      setProgress("");
    }
  }

  async function downloadSample() {
    const made = sampleCanvas
      ? { photo: sampleCanvas, blob: await canvasToBlob(sampleCanvas, "image/jpeg") }
      : await makeSample();
    if (!made) return;
    downloadBlob(made.blob, `sample-scan-${selected?.name.replace(/\s+/g, "-") ?? "quiz"}.jpg`);
    toast.success("Warped sample scan downloaded.");
  }

  async function scanSample() {
    const made = sampleCanvas ? { photo: sampleCanvas } : await makeSample();
    if (!made || !selected) return;
    setBusy(true);
    try {
      const rec = await processCanvas(made.photo, "sample-warped-scan.jpg");
      if (rec) toast.success("Sample scan processed. Check the processing table.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Sample scan failed.");
    } finally {
      setBusy(false);
    }
  }

  async function simulateClass() {
    if (!selected) return;
    const classStudents = students.filter(
      (s) => s.gradeLevel === selected.gradeLevel && s.section === selected.section,
    );
    if (!classStudents.length) {
      toast.error("Add students before running a class scan.");
      return;
    }
    setBusy(true);
    try {
      let saved = 0;
      for (let i = 0; i < classStudents.length; i++) {
        const st = classStudents[i]!;
        setProgress(`Scanning ${st.fullName} (${i + 1}/${classStudents.length})`);
        const key = keysForSet(selected);
        const answers = key.map((k, idx) => {
          if (idx % 9 === i % 9)
            return selected.sheetConfig.choices[(selected.sheetConfig.choices.indexOf(k) + 1) % selected.sheetConfig.choices.length]!;
          if (idx === 17 && i % 4 === 0) return null;
          return k;
        });
        const { canvas } = renderSheetCanvas(
          {
            ...selected.sheetConfig,
            testSet: selected.testSet ?? "A",
            date: selected.date,
            examCode: examCodeFor(selected),
          },
          {
            student: st,
            fill: { answers, rollNumber: st.rollNumber },
          },
        );
        const rec = await processCanvas(canvas, `${st.rollNumber}.png`);
        if (rec) saved++;
      }
      toast.success(`Class set processed (${saved} saved).`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Bulk scan failed.");
    } finally {
      setBusy(false);
      setProgress("");
    }
  }

  const paper = selected ? paperDims(selected.sheetConfig) : { widthMm: 210, heightMm: 297 };

  return (
    <div className="space-y-6">
      <ScanPromptDialog prompt={prompt} />
      <header>
        <h1 className="font-display text-3xl">Scan papers</h1>
        <p className="text-sm text-muted">
          A paper from another section is never saved on this class — you choose to save it on their actual section or cancel.
          If that exam is already scanned, replace or cancel.
        </p>
      </header>
      <Card className="flex flex-wrap items-end gap-3">
        <div className="min-w-52 flex-1">
          <p className="text-xs font-medium tracking-wide text-muted uppercase">Assessment</p>
          <select
            className="mt-1 h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm"
            value={selected?.id ?? ""}
            onChange={(e) => setAid(e.target.value)}
          >
            {assessments.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name} · G{a.gradeLevel}-{a.section}
                {a.testSet ? ` · Set ${a.testSet}` : ""}
              </option>
            ))}
          </select>
        </div>
        <label>
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp,application/pdf"
            multiple
            hidden
            onChange={(e) => void onFiles(e.target.files)}
          />
          <Button variant="outline" type="button" onClick={(e) => (e.currentTarget.previousElementSibling as HTMLInputElement)?.click()}>
            Upload images
          </Button>
        </label>
        <Button onClick={simulateClass} disabled={busy}>
          Scan sample class
        </Button>
      </Card>

      <Card>
        <LiveScanner
          paperWidthMm={paper.widthMm}
          paperHeightMm={paper.heightMm}
          busy={busy}
          onCapture={async (canvas) => {
            setBusy(true);
            try {
              const rec = await processCanvas(canvas, `live-${Date.now()}.jpg`);
              if (rec) toast.success(`Recorded roll ${rec.rollNumber} · ${rec.score}/${rec.answers.length}`);
              else toast.message("Sheet not recorded.");
            } finally {
              setBusy(false);
            }
          }}
        />
      </Card>

      <Card className="grid gap-4 sm:grid-cols-[minmax(0,1fr)_220px]">
        <div>
          <CardTitle>Sample test scan</CardTitle>
          <p className="mt-1 text-sm text-muted">
            A pre-filled sheet photographed on a desk — slightly off-angle, with a mild paper warp. Use it to test the
            scanner without a printer.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button variant="outline" disabled={busy} onClick={() => void makeSample()}>
              Generate sample
            </Button>
            <Button variant="outline" disabled={busy} onClick={() => void downloadSample()}>
              Download JPEG
            </Button>
            <Button disabled={busy} onClick={() => void scanSample()}>
              Scan this sample
            </Button>
          </div>
        </div>
        <div className="overflow-hidden rounded-[var(--radius-md)] border border-line bg-bg">
          {sampleUrl ? (
            <img src={sampleUrl} alt="Warped sample bubble sheet" className="w-full object-cover" />
          ) : (
            <p className="flex aspect-[3/4] items-center justify-center px-3 text-center text-xs text-muted">
              Generate a sample to preview the skewed paper
            </p>
          )}
        </div>
      </Card>
      {busy && <p className="text-sm text-muted">{progress || "Working…"}</p>}

      <Card className="overflow-x-auto p-0">
        <div className="px-4 py-3">
          <CardTitle>Processing table</CardTitle>
        </div>
        <table className="w-full min-w-[800px] text-sm">
          <thead className="text-left text-xs tracking-wide text-muted uppercase">
            <tr>
              <th className="px-4 py-2">Roll</th>
              <th>Student</th>
              <th>Score</th>
              <th>%</th>
              <th>Correct</th>
              <th>Wrong</th>
              <th>Blank</th>
              <th>Status</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {scans.map((s) => {
              const st = students.find((x) => x.id === s.studentId);
              return (
                <tr key={s.id} className="border-t border-line">
                  <td className="px-4 py-2 font-mono">{s.rollNumber}</td>
                  <td>{st?.fullName ?? "Unknown"}</td>
                  <td>
                    {s.score}/{selected?.itemCount}
                  </td>
                  <td>{Math.round(s.percentage)}%</td>
                  <td>{s.correct}</td>
                  <td>{s.wrong}</td>
                  <td>{s.blank}</td>
                  <td>
                    <Badge tone={s.status === "passed" ? "ok" : s.status === "flagged" ? "warn" : "danger"}>
                      {s.status}
                    </Badge>
                  </td>
                  <td className="pr-3">
                    <Link to="/review/$id" params={{ id: s.id }} className="text-accent underline">
                      Review
                    </Link>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {!scans.length && <p className="p-6 text-sm text-muted">No sheets yet for this assessment.</p>}
      </Card>
    </div>
  );
}
