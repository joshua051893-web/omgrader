import { createFileRoute, Link } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "@/lib/db/database";
import { Card, CardDesc, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScanLine, Users, ClipboardList, BookOpen, BarChart3, Settings, UserRound } from "lucide-react";
import { formatDate } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const students = useLiveQuery(() => db.students.toArray()) ?? [];
  const assessments = useLiveQuery(() => db.assessments.toArray()) ?? [];
  const scans = useLiveQuery(() => db.scans.orderBy("createdAt").reverse().limit(8).toArray()) ?? [];
  const review = scans.filter((s) => s.flags.length && !s.reviewed).length;
  const avg =
    scans.length === 0 ? null : scans.reduce((p, s) => p + s.percentage, 0) / Math.max(1, scans.length);

  const actions = [
    { to: "/students", label: "Students", icon: Users },
    { to: "/assessments", label: "Create assessment", icon: ClipboardList },
    { to: "/scan", label: "Scan papers", icon: ScanLine },
    { to: "/gradebook", label: "Gradebook", icon: BookOpen },
    { to: "/reports", label: "Results", icon: BarChart3 },
    { to: "/profile", label: "Profile", icon: UserRound },
    { to: "/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="space-y-8">
      <header>
        <p className="text-xs font-medium tracking-widest text-muted uppercase">Teacher workspace</p>
        <h1 className="font-display mt-1 text-4xl tracking-tight">OMG</h1>
        <p className="mt-1 text-sm font-medium tracking-wide text-accent">Optical Media Grader</p>
        <p className="mt-2 max-w-xl text-muted">
          Keep the roster, print bubble sheets, scan a whole class, and update the gradebook — all stored on this device.
        </p>
      </header>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Students" value={students.length} />
        <Stat label="Assessments" value={assessments.length} />
        <Stat label="Class average" value={avg == null ? "—" : `${avg.toFixed(0)}%`} />
        <Stat label="Needs review" value={review} warn={review > 0} />
      </section>

      <section className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {actions.map((a) => {
          const Icon = a.icon;
          return (
            <Link key={a.to} to={a.to}>
              <Button variant="outline" className="h-auto w-full flex-col items-start gap-3 p-4 text-left">
                <Icon className="size-4 text-accent" />
                <span>{a.label}</span>
              </Button>
            </Link>
          );
        })}
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardTitle>Recent assessments</CardTitle>
          <CardDesc className="mb-4">Open an assessment to edit the key or print the sheet.</CardDesc>
          <ul className="space-y-2">
            {assessments.slice(0, 5).map((a) => (
              <li key={a.id}>
                <Link to="/assessments/$id" params={{ id: a.id }} className="flex items-center justify-between rounded-[var(--radius-md)] px-2 py-2 hover:bg-bg">
                  <div>
                    <p className="text-sm font-medium">{a.name}</p>
                    <p className="text-xs text-muted">
                      {a.subject} · {formatDate(a.date)} · Set {a.testSet ?? "A"} · {a.itemCount} items
                    </p>
                  </div>
                  {a.archived ? <Badge>Archived</Badge> : <Badge tone="accent">{a.type}</Badge>}
                </Link>
              </li>
            ))}
            {!assessments.length && <p className="text-sm text-muted">No assessments yet.</p>}
          </ul>
        </Card>
        <Card>
          <CardTitle>Latest scans</CardTitle>
          <CardDesc className="mb-4">Flagged sheets wait here until you confirm them.</CardDesc>
          <ul className="space-y-2">
            {scans.map((s) => (
              <li key={s.id} className="flex items-center justify-between text-sm">
                <Link to="/review/$id" params={{ id: s.id }} className="text-accent underline-offset-2 hover:underline">
                  Roll {s.rollNumber} · {s.score} pts
                </Link>
                <Badge tone={s.status === "passed" ? "ok" : s.status === "flagged" ? "warn" : "danger"}>
                  {s.status}
                </Badge>
              </li>
            ))}
            {!scans.length && <p className="text-sm text-muted">No scans yet. Try Scan papers.</p>}
          </ul>
        </Card>
      </div>
    </div>
  );
}

function Stat({ label, value, warn }: { label: string; value: string | number; warn?: boolean }) {
  return (
    <Card className="p-4">
      <p className="text-xs tracking-wide text-muted uppercase">{label}</p>
      <p className={`mt-2 font-display text-3xl tabular-nums ${warn ? "text-warn" : ""}`}>{value}</p>
    </Card>
  );
}
