import { createFileRoute, Link } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "@/lib/db/database";
import { Card, CardTitle } from "@/components/ui/card";
import { formatDate } from "@/lib/utils";
import {
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export const Route = createFileRoute("/students/$id")({ component: StudentHistory });

function StudentHistory() {
  const { id } = Route.useParams();
  const student = useLiveQuery(() => db.students.get(id), [id]);
  const scans = useLiveQuery(() => db.scans.where("studentId").equals(id).toArray(), [id]) ?? [];
  const assessments = useLiveQuery(() => db.assessments.toArray()) ?? [];

  if (!student) return <p className="text-muted">Student not found.</p>;

  const rows = scans
    .map((s) => {
      const a = assessments.find((x) => x.id === s.assessmentId);
      return { scan: s, assessment: a };
    })
    .filter((x) => x.assessment)
    .sort((a, b) => (a.assessment!.date > b.assessment!.date ? 1 : -1));

  const chart = rows.map((r) => ({
    name: r.assessment!.name.slice(0, 12),
    pct: Math.round(r.scan.percentage),
  }));

  return (
    <div className="space-y-6">
      <div>
        <Link to="/students" className="text-sm text-muted hover:text-ink">
          Students
        </Link>
        <h1 className="font-display mt-2 text-3xl">{student.fullName}</h1>
        <p className="text-sm text-muted">
          Roll {student.rollNumber} · Grade {student.gradeLevel}-{student.section} · SY {student.schoolYear}
        </p>
      </div>
      <Card className="h-64">
        <CardTitle className="mb-3">Progress</CardTitle>
        {chart.length ? (
          <ResponsiveContainer width="100%" height="80%">
            <LineChart data={chart}>
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} />
              <Tooltip />
              <Line type="monotone" dataKey="pct" stroke="#215c4a" strokeWidth={2} dot />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-sm text-muted">No scored assessments yet.</p>
        )}
      </Card>
      <Card className="overflow-x-auto p-0">
        <table className="w-full text-sm">
          <thead className="text-left text-xs tracking-wide text-muted uppercase">
            <tr>
              <th className="px-4 py-3">Assessment</th>
              <th>Score</th>
              <th>%</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.scan.id} className="border-t border-line">
                <td className="px-4 py-2">{r.assessment!.name}</td>
                <td>
                  {r.scan.score}/{r.assessment!.itemCount}
                </td>
                <td>{Math.round(r.scan.percentage)}%</td>
                <td>{formatDate(r.assessment!.date)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
