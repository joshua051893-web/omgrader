import { createFileRoute, Link } from "@tanstack/react-router";
import { useLiveQuery } from "dexie-react-hooks";
import { useEffect, useMemo, useRef, useState } from "react";
import { db } from "@/lib/db/database";
import { SpreadsheetEditor } from "@/components/spreadsheet/grid";
import { parseGid, syncWorkbook } from "@/lib/spreadsheet/records";
import type { GradeWorkbook } from "@/lib/types";

export const Route = createFileRoute("/gradebook/$gid")({ component: SectionWorkbook });

function SectionWorkbook() {
  const { gid } = Route.useParams();
  const { gradeLevel, section } = parseGid(gid);
  const students = useLiveQuery(() => db.students.toArray());
  const assessments = useLiveQuery(() => db.assessments.toArray());
  const scans = useLiveQuery(() => db.scans.toArray());
  const stored = useLiveQuery(() => db.workbooks.get(`wb:${gradeLevel}:${section}`), [gradeLevel, section]);
  const [book, setBook] = useState<GradeWorkbook | null>(null);
  const timer = useRef<number | null>(null);
  const loading = students == null || assessments == null || scans == null;

  const fingerprint = useMemo(() => {
    if (loading) return "";
    return [
      students.map((s) => `${s.id}:${s.rollNumber}:${s.fullName}`).join("|"),
      assessments.map((a) => `${a.id}:${a.name}:${a.subject}:${a.date}`).join("|"),
      scans.map((s) => `${s.id}:${s.assessmentId}:${s.studentId}:${s.rollNumber}:${s.score}:${s.percentage}`).join("|"),
    ].join("::");
  }, [loading, students, assessments, scans]);

  useEffect(() => {
    if (loading) return;
    const next = syncWorkbook(stored, gradeLevel, section, students, assessments, scans);
    setBook(next);
    void db.workbooks.put(next);
  }, [loading, stored?.id, gradeLevel, section, fingerprint]);

  function persist(next: GradeWorkbook) {
    setBook(next);
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => {
      void db.workbooks.put(next);
    }, 350);
  }

  if (loading || !book) return <p className="text-sm text-muted">Opening gradebook…</p>;

  return (
    <div className="space-y-4">
      <div className="no-print">
        <Link to="/gradebook" className="text-sm text-muted">
          Gradebook
        </Link>
        <h1 className="font-display mt-1 text-3xl">
          Grade {gradeLevel} · Section {section}
        </h1>
        <p className="text-sm text-muted">
          Scanned Tests lists every scored paper for this section. Subject tabs hold per-subject scores. Type = in a cell
          for formulas. Enter saves. Download Excel for a real spreadsheet file.
        </p>
      </div>
      <p className="hidden print:block font-display text-2xl">
        Grade {gradeLevel} Section {section}
      </p>
      <SpreadsheetEditor book={book} onChange={persist} />
    </div>
  );
}
