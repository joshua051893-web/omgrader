//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-tz-i_oQW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/assessments",
			"/gradebook",
			"/reports",
			"/scan",
			"/settings",
			"/sheets",
			"/students",
			"/review/$id"
		],
		preloads: [
			"/assets/index-BELKznGH.js",
			"/assets/utils-DToPaVow.js",
			"/assets/link-D7adyNrH.js",
			"/assets/preload-helper-DLQmKGev.js",
			"/assets/createLucideIcon-CDJsRmE4.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BELKznGH.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-C-o8szNE.js",
			"/assets/card-CSIF8Efp.js",
			"/assets/button-IOt3qsHs.js",
			"/assets/badge-Bcl7lMH9.js"
		]
	},
	"/assessments": {
		filePath: "/workspace/src/routes/assessments.tsx",
		children: ["/assessments/$id"],
		preloads: [
			"/assets/assessments-BYETpK5n.js",
			"/assets/dialog-BHsupJv7.js",
			"/assets/card-CSIF8Efp.js",
			"/assets/button-IOt3qsHs.js",
			"/assets/input-DVIRXz3a.js",
			"/assets/badge-Bcl7lMH9.js",
			"/assets/repo-Dc3axYJx.js",
			"/assets/label-CZgVu7gE.js",
			"/assets/types-CuFRsVvi.js"
		]
	},
	"/gradebook": {
		filePath: "/workspace/src/routes/gradebook.tsx",
		children: void 0,
		preloads: [
			"/assets/gradebook-D5SU_qKp.js",
			"/assets/card-CSIF8Efp.js",
			"/assets/button-IOt3qsHs.js",
			"/assets/compute-JIPXdwJd.js",
			"/assets/xlsx-AJ6vIL1h.js"
		]
	},
	"/reports": {
		filePath: "/workspace/src/routes/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-B_yiaKJW.js",
			"/assets/card-CSIF8Efp.js",
			"/assets/button-IOt3qsHs.js",
			"/assets/compute-JIPXdwJd.js",
			"/assets/export-CNRoPoka.js",
			"/assets/generateCategoricalChart-Csoo7bAx.js"
		]
	},
	"/scan": {
		filePath: "/workspace/src/routes/scan.tsx",
		children: void 0,
		preloads: [
			"/assets/scan-0v_mIc3R.js",
			"/assets/card-CSIF8Efp.js",
			"/assets/button-IOt3qsHs.js",
			"/assets/badge-Bcl7lMH9.js",
			"/assets/repo-Dc3axYJx.js",
			"/assets/render-canvas-BzX6b0Nw.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-Dv97-BGu.js",
			"/assets/card-CSIF8Efp.js",
			"/assets/button-IOt3qsHs.js",
			"/assets/input-DVIRXz3a.js",
			"/assets/repo-Dc3axYJx.js",
			"/assets/jszip.min-BiE7W408.js",
			"/assets/label-CZgVu7gE.js"
		]
	},
	"/sheets": {
		filePath: "/workspace/src/routes/sheets.tsx",
		children: void 0,
		preloads: [
			"/assets/sheets-CRYgBJXJ.js",
			"/assets/card-CSIF8Efp.js",
			"/assets/button-IOt3qsHs.js",
			"/assets/input-DVIRXz3a.js",
			"/assets/repo-Dc3axYJx.js",
			"/assets/label-CZgVu7gE.js",
			"/assets/types-CuFRsVvi.js",
			"/assets/render-canvas-BzX6b0Nw.js"
		]
	},
	"/students": {
		filePath: "/workspace/src/routes/students.tsx",
		children: ["/students/$id"],
		preloads: [
			"/assets/students-DEOEkcrR.js",
			"/assets/dialog-BHsupJv7.js",
			"/assets/card-CSIF8Efp.js",
			"/assets/button-IOt3qsHs.js",
			"/assets/input-DVIRXz3a.js",
			"/assets/badge-Bcl7lMH9.js",
			"/assets/repo-Dc3axYJx.js",
			"/assets/xlsx-AJ6vIL1h.js",
			"/assets/label-CZgVu7gE.js"
		]
	},
	"/assessments/$id": {
		filePath: "/workspace/src/routes/assessments.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/assessments._id-BSWBp9_k.js",
			"/assets/compute-JIPXdwJd.js",
			"/assets/xlsx-AJ6vIL1h.js",
			"/assets/export-CNRoPoka.js"
		]
	},
	"/review/$id": {
		filePath: "/workspace/src/routes/review.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/review._id-DlEOlyd_.js",
			"/assets/card-CSIF8Efp.js",
			"/assets/button-IOt3qsHs.js",
			"/assets/input-DVIRXz3a.js",
			"/assets/repo-Dc3axYJx.js"
		]
	},
	"/students/$id": {
		filePath: "/workspace/src/routes/students.$id.tsx",
		children: void 0,
		preloads: ["/assets/students._id-DDnrJqQp.js", "/assets/generateCategoricalChart-Csoo7bAx.js"]
	}
} });
//#endregion
export { tsrStartManifest };
