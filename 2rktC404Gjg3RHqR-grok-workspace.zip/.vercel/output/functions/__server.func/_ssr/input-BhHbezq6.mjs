import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-DYXV9Fl_.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/input-BhHbezq6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Input = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	ref,
	className: cn("h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-3 text-sm text-ink placeholder:text-subtle", className),
	...props
}));
Input.displayName = "Input";
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	ref,
	className: cn("min-h-24 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-3 py-2 text-sm text-ink placeholder:text-subtle", className),
	...props
}));
Textarea.displayName = "Textarea";
//#endregion
export { Textarea as n, Input as t };
