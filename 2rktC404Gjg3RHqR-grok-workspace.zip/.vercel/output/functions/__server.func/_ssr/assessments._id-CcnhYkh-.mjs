import { i as __toESM } from "../_runtime.mjs";
import { c as uid, n as db, o as nowIso, r as downloadBlob } from "./utils-DYXV9Fl_.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Route$2 } from "./router-CLqpKR0U.mjs";
import { t as Button } from "./button-BW_xqhyX.mjs";
import { n as Textarea } from "./input-BhHbezq6.mjs";
import { r as CardTitle, t as Card } from "./card-BL1KPyKC.mjs";
import { t as Badge } from "./badge-PKkwSRI6.mjs";
import { a as saveAssessment } from "./repo-DVWp7U09.mjs";
import { t as useLiveQuery } from "../_libs/dexie-react-hooks.mjs";
import { r as itemAnalysis, t as assessmentSummary } from "./compute-CC-6icko.mjs";
import { n as utils, t as readSync } from "../_libs/xlsx.mjs";
import { n as resultsWorkbook, t as downloadAssessmentZip } from "./export-DbUeoy2m.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assessments._id-CcnhYkh-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AssessmentDetail() {
	const { id } = Route$2.useParams();
	const a = useLiveQuery(() => db.assessments.get(id), [id]);
	const scans = useLiveQuery(() => db.scans.where("assessmentId").equals(id).toArray(), [id]) ?? [];
	const students = useLiveQuery(() => db.students.toArray()) ?? [];
	const [paste, setPaste] = (0, import_react.useState)("");
	const summary = (0, import_react.useMemo)(() => a ? assessmentSummary(a, scans) : null, [a, scans]);
	const items = (0, import_react.useMemo)(() => a ? itemAnalysis(a, scans) : [], [a, scans]);
	if (!a) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Assessment not found."
	});
	const assessment = a;
	async function setKey(next) {
		if (next.length !== assessment.itemCount) {
			toast.error("The answer key must have one answer for every item.");
			return;
		}
		await saveAssessment({
			...assessment,
			answerKey: next.map((x) => x.toUpperCase())
		});
		toast.success("Answer key saved.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/assessments",
						className: "text-sm text-muted",
						children: "Assessments"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-1 text-3xl",
						children: assessment.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							assessment.subject,
							" · ",
							assessment.itemCount,
							" items · Passing ",
							assessment.passingScore
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/sheets",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							children: "Bubble sheets"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/scan",
						search: { assessmentId: assessment.id },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Scan papers" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Scanned",
						value: summary?.count ?? 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Average",
						value: summary ? summary.average.toFixed(1) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Passed",
						value: summary?.passed ?? 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Did not meet",
						value: summary?.failed ?? 0
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "mb-3",
					children: "Answer key"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: assessment.answerKey.map((ans, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col items-center text-xs text-muted",
						children: [i + 1, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "mt-1 h-9 rounded-[var(--radius-sm)] border border-line bg-surface px-1 font-mono",
							value: ans,
							onChange: (e) => {
								const next = [...assessment.answerKey];
								next[i] = e.target.value;
								setKey(next);
							},
							children: assessment.sheetConfig.choices.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
						})]
					}, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					className: "mt-4",
					placeholder: "Paste answers like A C B D A",
					value: paste,
					onChange: (e) => setPaste(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => {
							setKey(paste.trim().split(/[\s,;]+/).filter(Boolean));
						},
						children: "Apply pasted key"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "Import key"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: ".xlsx,.csv",
							className: "text-sm",
							onChange: async (e) => {
								const f = e.target.files?.[0];
								if (!f) return;
								const wb = readSync(await f.arrayBuffer(), { type: "array" });
								const sheet = wb.Sheets[wb.SheetNames[0]];
								setKey(utils.sheet_to_json(sheet, { header: 1 }).map((r) => String(r[1] ?? r[0] ?? "").trim()).filter((x) => /^[A-Fa-f]$/.test(x)));
							}
						})]
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "overflow-x-auto p-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Results" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => {
								const buf = resultsWorkbook(assessment, scans, students);
								downloadBlob(new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }), `${assessment.name}-results.xlsx`);
							},
							children: "Download all results"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => downloadAssessmentZip(assessment),
							children: "Download marked papers (ZIP)"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[720px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs text-muted uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-2",
								children: "Roll"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Student" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Score" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "%" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Correct" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Wrong" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Blank" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Status" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: scans.map((s) => {
						const st = students.find((x) => x.id === s.studentId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-line",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2 font-mono",
									children: s.rollNumber
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: st?.fullName ?? "Unknown" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [
									s.score,
									"/",
									assessment.itemCount
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [Math.round(s.percentage), "%"] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: s.correct }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: s.wrong }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: s.blank }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: s.status === "passed" ? "ok" : s.status === "flagged" ? "warn" : "danger",
									children: s.status
								}) })
							]
						}, s.id);
					}) })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "overflow-x-auto p-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "px-4 py-3",
					children: "Item analysis"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs text-muted uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-2",
								children: "Item"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Correct" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Wrong" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Blank" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Difficulty" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Common wrong" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2",
								children: it.item + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: it.correct }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: it.wrong }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: it.blank }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [(it.difficulty * 100).toFixed(0), "%"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: it.mostWrong ?? "—" })
						]
					}, it.item)) })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: async () => {
							await saveAssessment({
								...assessment,
								archived: !assessment.archived
							});
							toast.success(assessment.archived ? "Restored." : "Archived.");
						},
						children: assessment.archived ? "Restore" : "Archive"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: async () => {
							const copy = {
								...assessment,
								id: uid("asm"),
								name: `${assessment.name} (copy)`,
								date: nowIso().slice(0, 10),
								createdAt: nowIso(),
								archived: false
							};
							await saveAssessment(copy);
							toast.success("Duplicated. Update the answer key if needed.");
						},
						children: "Duplicate"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: async () => {
							if (!confirm("Delete this assessment and its scans? This cannot be undone.")) return;
							await db.scans.where("assessmentId").equals(assessment.id).delete();
							await db.assessments.delete(assessment.id);
							toast.success("Assessment deleted.");
							history.back();
						},
						children: "Delete"
					})
				]
			})
		]
	});
}
function Mini({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display mt-1 text-2xl tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { AssessmentDetail as component };
