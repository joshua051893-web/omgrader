import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as downloadBlob } from "./utils-DYXV9Fl_.mjs";
import { r as itemAnalysis, t as assessmentSummary } from "./compute-CC-6icko.mjs";
import { n as utils, r as writeSync } from "../_libs/xlsx.mjs";
import { t as require_lib } from "../_libs/jszip+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/export-DbUeoy2m.js
var import_lib = /* @__PURE__ */ __toESM(require_lib());
function resultsWorkbook(assessment, scans, students) {
	const rows = scans.map((s) => {
		const st = students.find((x) => x.id === s.studentId);
		return {
			"Roll No.": s.rollNumber,
			Student: st?.fullName ?? "",
			Score: `${s.score}/${assessment.itemCount}`,
			Percentage: Math.round(s.percentage),
			Correct: s.correct,
			Wrong: s.wrong,
			Blank: s.blank,
			Status: s.status,
			Flags: s.flags.join(", ")
		};
	});
	const ws = utils.json_to_sheet(rows);
	const itemRows = itemAnalysis(assessment, scans).map((st) => ({
		Item: st.item + 1,
		Correct: st.correct,
		Wrong: st.wrong,
		Blank: st.blank,
		Difficulty: Math.round(st.difficulty * 100) / 100,
		"Most frequent wrong": st.mostWrong ?? ""
	}));
	const ws2 = utils.json_to_sheet(itemRows);
	const summary = assessmentSummary(assessment, scans);
	const ws3 = utils.json_to_sheet([summary]);
	const wb = utils.book_new();
	utils.book_append_sheet(wb, ws, "Results");
	utils.book_append_sheet(wb, ws2, "Item Analysis");
	utils.book_append_sheet(wb, ws3, "Summary");
	return writeSync(wb, {
		type: "array",
		bookType: "xlsx"
	});
}
async function downloadAssessmentZip(assessment) {
	const zip = new import_lib.default();
	const scans = await db.scans.where("assessmentId").equals(assessment.id).toArray();
	const xlsx = resultsWorkbook(assessment, scans, await db.students.toArray());
	zip.file("results.xlsx", xlsx);
	const originals = zip.folder("Original Scans");
	const marked = zip.folder("Marked Papers");
	for (const s of scans) {
		if (s.originalBlobId) {
			const b = await db.blobs.get(s.originalBlobId);
			if (b) originals?.file(b.name || `${s.rollNumber}.png`, b.bytes);
		}
		if (s.markedBlobId) {
			const b = await db.blobs.get(s.markedBlobId);
			if (b) marked?.file(b.name || `${s.rollNumber}-marked.png`, b.bytes);
		}
	}
	const out = await zip.generateAsync({ type: "blob" });
	downloadBlob(out, `${assessment.name.replace(/\s+/g, "-")}-results.zip`);
}
//#endregion
export { resultsWorkbook as n, downloadAssessmentZip as t };
