import { n as db } from "./utils-DYXV9Fl_.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-BW_xqhyX.mjs";
import { r as CardTitle, t as Card } from "./card-BL1KPyKC.mjs";
import { t as useLiveQuery } from "../_libs/dexie-react-hooks.mjs";
import { r as itemAnalysis, t as assessmentSummary } from "./compute-CC-6icko.mjs";
import { t as downloadAssessmentZip } from "./export-DbUeoy2m.mjs";
import { c as Tooltip, i as XAxis, o as Bar, r as YAxis, s as ResponsiveContainer, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-Q6IcrqF_.js
var import_jsx_runtime = require_jsx_runtime();
function ReportsPage() {
	const assessments = useLiveQuery(() => db.assessments.toArray()) ?? [];
	const scans = useLiveQuery(() => db.scans.toArray()) ?? [];
	const latest = assessments[0];
	const forA = latest ? scans.filter((s) => s.assessmentId === latest.id) : [];
	const summary = latest ? assessmentSummary(latest, forA) : null;
	const items = latest ? itemAnalysis(latest, forA) : [];
	const dist = [
		0,
		0,
		0,
		0,
		0
	];
	for (const s of forA) {
		const b = Math.min(4, Math.floor(s.percentage / 20));
		dist[b]++;
	}
	const chart = [
		"0-19",
		"20-39",
		"40-59",
		"60-79",
		"80-100"
	].map((name, i) => ({
		name,
		n: dist[i]
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "Reports"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Class performance and item difficulty for the selected assessment."
		})] }), latest && summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"Showing ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: latest.name }),
					".",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						className: "text-accent underline",
						to: "/assessments/$id",
						params: { id: latest.id },
						children: "Open assessment"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Highest",
						value: summary.highest
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Lowest",
						value: summary.lowest
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Average",
						value: summary.average.toFixed(1)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Median",
						value: summary.median
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "h-64",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "mb-2",
					children: "Score distribution"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "80%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: chart,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "name",
								tick: { fontSize: 11 }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								allowDecimals: false,
								tick: { fontSize: 11 }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "n",
								fill: "#215c4a",
								radius: [
									4,
									4,
									0,
									0
								]
							})
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "overflow-x-auto p-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "px-4 py-3",
					children: "Difficult items"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-2",
								children: "Item"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Correct %" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Common wrong" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.slice().sort((a, b) => a.difficulty - b.difficulty).slice(0, 8).map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2",
								children: it.item + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [(it.difficulty * 100).toFixed(0), "%"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: it.mostWrong ?? "—" })
						]
					}, it.item)) })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => downloadAssessmentZip(latest),
				children: "Download assessment ZIP"
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Scan an assessment to populate reports."
		})]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display mt-1 text-2xl tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { ReportsPage as component };
