import { i as __toESM } from "../_runtime.mjs";
import { a as fullName, c as uid, n as db, o as nowIso, s as padRoll, t as cn } from "./utils-DYXV9Fl_.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as createRootRoute, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as ScanLine, c as ClipboardList, i as Settings, l as ChartColumn, n as Users, o as Printer, r as TriangleAlert, s as LayoutDashboard, u as BookOpen } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CLqpKR0U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var DEFAULT_SETTINGS = {
	id: "singleton",
	schoolName: "Riverside National High School",
	teacherName: "Ms. Reyes",
	defaultGrade: "9",
	defaultSection: "A",
	defaultSchoolYear: "2026-2027",
	rollDigits: 3,
	seeded: false
};
function defaultCategories() {
	return [
		{
			id: uid("cat"),
			name: "Written Works",
			weight: 30,
			sortOrder: 0
		},
		{
			id: uid("cat"),
			name: "Performance Tasks",
			weight: 50,
			sortOrder: 1
		},
		{
			id: uid("cat"),
			name: "Quarterly Assessment",
			weight: 20,
			sortOrder: 2
		}
	];
}
function defaultSheetConfig(partial = {}) {
	return {
		paper: "A4",
		customWidthMm: 210,
		customHeightMm: 297,
		orientation: "portrait",
		itemCount: 20,
		choices: [
			"A",
			"B",
			"C",
			"D"
		],
		quizName: "Quiz",
		subject: "Mathematics",
		teacher: DEFAULT_SETTINGS.teacherName,
		school: DEFAULT_SETTINGS.schoolName,
		date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
		instructions: "Use a dark pen or pencil. Shade each bubble fully. Erase completely to change an answer.",
		showRollBubbles: true,
		rollDigits: 3,
		showName: true,
		showLrn: true,
		showSection: true,
		...partial
	};
}
var SAMPLE_NAMES = [
	[
		"Juan",
		"P",
		"Dela Cruz"
	],
	[
		"Maria",
		"L",
		"Santos"
	],
	[
		"Andres",
		"R",
		"Reyes"
	],
	[
		"Ana",
		"M",
		"Garcia"
	],
	[
		"Jose",
		"D",
		"Ramos"
	],
	[
		"Liza",
		"C",
		"Torres"
	],
	[
		"Miguel",
		"A",
		"Cruz"
	],
	[
		"Sofia",
		"N",
		"Mendoza"
	],
	[
		"Carlo",
		"B",
		"Villanueva"
	],
	[
		"Patricia",
		"S",
		"Lopez"
	],
	[
		"Diego",
		"F",
		"Navarro"
	],
	[
		"Elena",
		"T",
		"Bautista"
	]
];
function sampleStudents() {
	const t = nowIso();
	return SAMPLE_NAMES.map(([first, middle, last], i) => {
		const roll = padRoll(String(i + 1), 3);
		return {
			id: uid("stu"),
			rollNumber: roll,
			lrn: `13690000${String(1e3 + i)}`,
			firstName: first,
			middleName: middle,
			lastName: last,
			fullName: fullName(first, middle, last),
			gradeLevel: "9",
			section: "A",
			schoolYear: "2026-2027",
			extra: "",
			createdAt: t,
			updatedAt: t
		};
	});
}
async function ensureSeeded() {
	if ((await db.settings.get("singleton"))?.seeded) return;
	const cats = defaultCategories();
	const students = sampleStudents();
	const t = nowIso();
	const assessment = {
		id: uid("asm"),
		name: "Fractions Quiz 1",
		subject: "Mathematics",
		gradeLevel: "9",
		section: "A",
		teacher: DEFAULT_SETTINGS.teacherName,
		schoolYear: "2026-2027",
		date: t.slice(0, 10),
		itemCount: 20,
		passingScore: 12,
		instructions: "Shade one answer per item. Use a dark pen.",
		answerKey: [
			"A",
			"C",
			"B",
			"D",
			"A",
			"B",
			"C",
			"A",
			"D",
			"B",
			"A",
			"A",
			"C",
			"D",
			"B",
			"C",
			"A",
			"B",
			"D",
			"A"
		],
		timeLimitMinutes: 30,
		type: "Quiz",
		categoryId: cats[0].id,
		archived: false,
		sheetConfig: defaultSheetConfig({
			quizName: "Fractions Quiz 1",
			subject: "Mathematics",
			itemCount: 20,
			date: t.slice(0, 10)
		}),
		createdAt: t,
		updatedAt: t
	};
	await db.transaction("rw", db.settings, db.categories, db.students, db.assessments, db.templates, async () => {
		if ((await db.settings.get("singleton"))?.seeded) return;
		await db.settings.put({
			...DEFAULT_SETTINGS,
			seeded: true
		});
		await db.categories.bulkAdd(cats);
		await db.students.bulkAdd(students);
		await db.assessments.add(assessment);
		await db.templates.bulkAdd([
			{
				id: uid("tpl"),
				name: "Grade 9 – 20 Item Quiz",
				config: defaultSheetConfig({
					itemCount: 20,
					quizName: "20-Item Quiz"
				}),
				createdAt: t
			},
			{
				id: uid("tpl"),
				name: "Grade 10 – 50 Item Test",
				config: defaultSheetConfig({
					itemCount: 50,
					quizName: "50-Item Test",
					choices: [
						"A",
						"B",
						"C",
						"D",
						"E"
					]
				}),
				createdAt: t
			},
			{
				id: uid("tpl"),
				name: "Quarterly Exam – 60 Items",
				config: defaultSheetConfig({
					itemCount: 60,
					quizName: "Quarterly Examination",
					paper: "Legal"
				}),
				createdAt: t
			}
		]);
	});
}
function BootGate({ children }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		ensureSeeded().then(() => setReady(true)).catch((e) => setError(e instanceof Error ? e.message : "Could not open the local database."));
	}, []);
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center p-8 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-md text-sm text-muted",
			children: error
		})
	});
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Opening local records…"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var NAV = [
	{
		to: "/",
		label: "Dashboard",
		icon: LayoutDashboard
	},
	{
		to: "/students",
		label: "Students",
		icon: Users
	},
	{
		to: "/assessments",
		label: "Assessments",
		icon: ClipboardList
	},
	{
		to: "/sheets",
		label: "Bubble sheets",
		icon: Printer
	},
	{
		to: "/scan",
		label: "Scan papers",
		icon: ScanLine
	},
	{
		to: "/gradebook",
		label: "Gradebook",
		icon: BookOpen
	},
	{
		to: "/reports",
		label: "Reports",
		icon: ChartColumn
	},
	{
		to: "/settings",
		label: "Settings",
		icon: Settings
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-[1400px] gap-0 md:gap-6 md:px-6 md:py-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-screen w-56 shrink-0 flex-col py-2 md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-3 pb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl tracking-tight",
						children: "Quillmark"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Local gradebook & OMR"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-1 flex-col gap-1",
					children: NAV.map((item) => {
						const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex items-center gap-2 rounded-[var(--radius-md)] px-3 py-2 text-sm", active ? "bg-accent text-accent-fg" : "text-muted hover:bg-accent-soft hover:text-accent"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
						}, item.to);
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-h-screen flex-1 px-4 pt-5 pb-24 md:rounded-[var(--radius-xl)] md:border md:border-line md:bg-bg-elevated md:px-8 md:py-8 md:pb-8",
				children
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "fixed inset-x-0 bottom-0 z-40 flex justify-around border-t border-line bg-surface/95 px-1 py-2 backdrop-blur md:hidden",
			children: NAV.slice(0, 5).map((item) => {
				const Icon = item.icon;
				const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					className: cn("flex min-w-12 flex-col items-center gap-1 px-2 py-1 text-[10px]", active ? "text-accent" : "text-muted"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label.split(" ")[0]]
				}, item.to);
			})
		})]
	});
}
var styles_default = "/assets/styles-ByiChk7A.css";
var APP_NAME = "Quillmark";
var Route$11 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#215c4a"
			},
			{
				name: "description",
				content: "Offline-first teacher gradebook with bubble sheet generator and OMR scanner."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=IBM+Plex+Sans:wght@400;500;600&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				richColors: true,
				position: "top-right"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$10 = () => import("./routes-Fa0YY-GJ.mjs");
var Route$10 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./assessments-CMzADzY2.mjs");
var Route$9 = createFileRoute("/assessments")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./gradebook-B4w6LFhD.mjs");
var Route$8 = createFileRoute("/gradebook")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./reports-Q6IcrqF_.mjs");
var Route$7 = createFileRoute("/reports")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./scan-Gcqb98aC.mjs");
var Route$6 = createFileRoute("/scan")({
	validateSearch: (s) => ({ assessmentId: typeof s.assessmentId === "string" ? s.assessmentId : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./settings-Dx3Cj49E.mjs");
var Route$5 = createFileRoute("/settings")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./sheets-CzXuxWiK.mjs");
var Route$4 = createFileRoute("/sheets")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./students-BWwLj-qi.mjs");
var Route$3 = createFileRoute("/students")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./assessments._id-CcnhYkh-.mjs");
var Route$2 = createFileRoute("/assessments/$id")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./review._id-ogkvrePX.mjs");
var Route$1 = createFileRoute("/review/$id")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./students._id-CXtBJKp0.mjs");
var Route = createFileRoute("/students/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$10.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$11
});
var AssessmentsRoute = Route$9.update({
	id: "/assessments",
	path: "/assessments",
	getParentRoute: () => Route$11
});
var GradebookRoute = Route$8.update({
	id: "/gradebook",
	path: "/gradebook",
	getParentRoute: () => Route$11
});
var ReportsRoute = Route$7.update({
	id: "/reports",
	path: "/reports",
	getParentRoute: () => Route$11
});
var ScanRoute = Route$6.update({
	id: "/scan",
	path: "/scan",
	getParentRoute: () => Route$11
});
var SettingsRoute = Route$5.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => Route$11
});
var SheetsRoute = Route$4.update({
	id: "/sheets",
	path: "/sheets",
	getParentRoute: () => Route$11
});
var StudentsRoute = Route$3.update({
	id: "/students",
	path: "/students",
	getParentRoute: () => Route$11
});
var AssessmentsIdRoute = Route$2.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AssessmentsRoute
});
var ReviewIdRoute = Route$1.update({
	id: "/review/$id",
	path: "/review/$id",
	getParentRoute: () => Route$11
});
var StudentsIdRoute = Route.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => StudentsRoute
});
var AssessmentsRouteChildren = { AssessmentsIdRoute };
var AssessmentsRouteWithChildren = AssessmentsRoute._addFileChildren(AssessmentsRouteChildren);
var StudentsRouteChildren = { StudentsIdRoute };
var rootRouteChildren = {
	IndexRoute,
	AssessmentsRoute: AssessmentsRouteWithChildren,
	GradebookRoute,
	ReportsRoute,
	ScanRoute,
	SettingsRoute,
	SheetsRoute,
	StudentsRoute: StudentsRoute._addFileChildren(StudentsRouteChildren),
	ReviewIdRoute
};
var routeTree = Route$11._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Route$6 as a, Route$2 as i, Route as n, DEFAULT_SETTINGS as o, Route$1 as r, defaultSheetConfig as s, router_exports as t };
