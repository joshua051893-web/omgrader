import { a as fullName, c as uid, n as db, o as nowIso, s as padRoll } from "./utils-DYXV9Fl_.mjs";
import { o as DEFAULT_SETTINGS } from "./router-CLqpKR0U.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/repo-DVWp7U09.js
async function getSettings() {
	return await db.settings.get("singleton") ?? DEFAULT_SETTINGS;
}
async function saveSettings(patch) {
	const cur = await getSettings();
	await db.settings.put({
		...cur,
		...patch,
		id: "singleton"
	});
}
async function upsertStudent(input) {
	const t = nowIso();
	const existing = input.id ? await db.students.get(input.id) : void 0;
	const student = {
		id: existing?.id ?? uid("stu"),
		rollNumber: padRoll(input.rollNumber),
		lrn: input.lrn,
		firstName: input.firstName,
		middleName: input.middleName,
		lastName: input.lastName,
		fullName: fullName(input.firstName, input.middleName, input.lastName),
		gradeLevel: input.gradeLevel,
		section: input.section,
		schoolYear: input.schoolYear,
		extra: input.extra ?? "",
		createdAt: existing?.createdAt ?? t,
		updatedAt: t
	};
	await db.students.put(student);
	return student;
}
async function deleteStudent(id) {
	await db.students.delete(id);
}
async function saveAssessment(a) {
	await db.assessments.put({
		...a,
		updatedAt: nowIso()
	});
}
async function saveScan(scan) {
	await db.scans.put({
		...scan,
		updatedAt: nowIso()
	});
}
async function putBlob(kind, blob, name) {
	const id = uid("blob");
	const bytes = await blob.arrayBuffer();
	await db.blobs.put({
		id,
		kind,
		mime: blob.type || "image/png",
		name,
		bytes,
		createdAt: nowIso()
	});
	return id;
}
async function blobUrl(id) {
	if (!id) return null;
	const rec = await db.blobs.get(id);
	if (!rec) return null;
	return URL.createObjectURL(new Blob([rec.bytes], { type: rec.mime }));
}
//#endregion
export { saveAssessment as a, upsertStudent as c, putBlob as i, deleteStudent as n, saveScan as o, getSettings as r, saveSettings as s, blobUrl as t };
