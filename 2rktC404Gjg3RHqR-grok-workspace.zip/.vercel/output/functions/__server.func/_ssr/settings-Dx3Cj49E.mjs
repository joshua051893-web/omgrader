import { i as __toESM } from "../_runtime.mjs";
import { c as uid, n as db, o as nowIso, r as downloadBlob } from "./utils-DYXV9Fl_.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as DEFAULT_SETTINGS } from "./router-CLqpKR0U.mjs";
import { t as Button } from "./button-BW_xqhyX.mjs";
import { t as Input } from "./input-BhHbezq6.mjs";
import { n as CardDesc, r as CardTitle, t as Card } from "./card-BL1KPyKC.mjs";
import { s as saveSettings } from "./repo-DVWp7U09.mjs";
import { t as Label } from "./label-ZkCXXQbY.mjs";
import { t as useLiveQuery } from "../_libs/dexie-react-hooks.mjs";
import { t as require_lib } from "../_libs/jszip+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-Dx3Cj49E.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
async function exportFullBackup() {
	const zip = new import_lib.default();
	const payload = {
		version: 1,
		exportedAt: nowIso(),
		students: await db.students.toArray(),
		assessments: await db.assessments.toArray(),
		scans: await db.scans.toArray(),
		categories: await db.categories.toArray(),
		templates: await db.templates.toArray(),
		settings: await db.settings.toArray()
	};
	zip.file("quillmark-db.json", JSON.stringify(payload));
	const blobs = await db.blobs.toArray();
	for (const b of blobs) zip.file(`files/${b.id}_${b.name}`, b.bytes);
	const out = await zip.generateAsync({ type: "blob" });
	await db.backups.add({
		id: uid("bak"),
		createdAt: nowIso(),
		note: "Manual backup",
		size: out.size
	});
	downloadBlob(out, `quillmark-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.zip`);
}
async function importFullBackup(file) {
	const zip = await import_lib.default.loadAsync(file);
	const dbFile = zip.file("quillmark-db.json");
	if (!dbFile) throw new Error("This file is not a Quillmark backup.");
	const payload = JSON.parse(await dbFile.async("string"));
	await db.students.clear();
	await db.assessments.clear();
	await db.scans.clear();
	await db.categories.clear();
	await db.templates.clear();
	await db.settings.clear();
	await db.blobs.clear();
	await db.students.bulkAdd(payload.students);
	await db.assessments.bulkAdd(payload.assessments);
	await db.scans.bulkAdd(payload.scans);
	await db.categories.bulkAdd(payload.categories);
	await db.templates.bulkAdd(payload.templates);
	await db.settings.bulkAdd(payload.settings);
	const files = Object.keys(zip.files).filter((k) => k.startsWith("files/") && !zip.files[k].dir);
	for (const path of files) {
		const name = path.slice(6);
		const id = name.split("_")[0];
		const bytes = await zip.files[path].async("arraybuffer");
		await db.blobs.put({
			id,
			kind: "other",
			mime: "application/octet-stream",
			name: name.slice(id.length + 1) || name,
			bytes,
			createdAt: nowIso()
		});
	}
}
function SettingsPage() {
	const settings = useLiveQuery(() => db.settings.get("singleton")) ?? DEFAULT_SETTINGS;
	const cats = useLiveQuery(() => db.categories.toArray()) ?? [];
	const backups = useLiveQuery(() => db.backups.orderBy("createdAt").reverse().toArray()) ?? [];
	const [form, setForm] = (0, import_react.useState)(settings);
	(0, import_react.useEffect)(() => setForm(settings), [settings]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Settings"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Everything stays on this device. Export a backup before clearing the browser."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "School" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [[
							["schoolName", "School / institution"],
							["teacherName", "Teacher"],
							["defaultGrade", "Default grade"],
							["defaultSection", "Default section"],
							["defaultSchoolYear", "School year"]
						].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form[k],
							onChange: (e) => setForm({
								...form,
								[k]: e.target.value
							})
						})] }, k)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Roll digits" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: form.rollDigits,
							onChange: (e) => setForm({
								...form,
								rollDigits: Number(e.target.value)
							})
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: async () => {
							await saveSettings(form);
							toast.success("Saved.");
						},
						children: "Save settings"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Grading weights" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: "Percentages should total 100. They are used for the gradebook average." }),
					cats.slice().sort((a, b) => a.sortOrder - b.sortOrder).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: c.name,
							onChange: (e) => db.categories.update(c.id, { name: e.target.value })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "w-24",
							type: "number",
							value: c.weight,
							onChange: (e) => db.categories.update(c.id, { weight: Number(e.target.value) })
						})]
					}, c.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => db.categories.add({
							id: uid("cat"),
							name: "New category",
							weight: 0,
							sortOrder: cats.length
						}),
						children: "Add category"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Backup & restore" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: "Creates a ZIP of the roster, assessments, scans, and marked papers." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => exportFullBackup(),
							children: "Export database"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							hidden: true,
							type: "file",
							accept: ".zip",
							onChange: async (e) => {
								const f = e.target.files?.[0];
								if (!f) return;
								if (!confirm("Restore replaces current records on this device. Continue?")) return;
								try {
									await importFullBackup(f);
									toast.success("Backup restored.");
								} catch (err) {
									toast.error(err instanceof Error ? err.message : "Restore failed.");
								}
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							type: "button",
							onClick: (e) => e.currentTarget.previousElementSibling?.click(),
							children: "Import database"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "text-sm text-muted",
						children: backups.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							new Date(b.createdAt).toLocaleString(),
							" · ",
							(b.size / 1024).toFixed(0),
							" KB"
						] }, b.id))
					})
				]
			})
		]
	});
}
//#endregion
export { SettingsPage as component };
