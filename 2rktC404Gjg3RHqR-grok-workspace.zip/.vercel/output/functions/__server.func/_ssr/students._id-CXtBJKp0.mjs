import { i as formatDate, n as db } from "./utils-DYXV9Fl_.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as Route } from "./router-CLqpKR0U.mjs";
import { r as CardTitle, t as Card } from "./card-BL1KPyKC.mjs";
import { t as useLiveQuery } from "../_libs/dexie-react-hooks.mjs";
import { a as Line, c as Tooltip, i as XAxis, n as LineChart, r as YAxis, s as ResponsiveContainer } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/students._id-CXtBJKp0.js
var import_jsx_runtime = require_jsx_runtime();
function StudentHistory() {
	const { id } = Route.useParams();
	const student = useLiveQuery(() => db.students.get(id), [id]);
	const scans = useLiveQuery(() => db.scans.where("studentId").equals(id).toArray(), [id]) ?? [];
	const assessments = useLiveQuery(() => db.assessments.toArray()) ?? [];
	if (!student) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Student not found."
	});
	const rows = scans.map((s) => {
		return {
			scan: s,
			assessment: assessments.find((x) => x.id === s.assessmentId)
		};
	}).filter((x) => x.assessment).sort((a, b) => a.assessment.date > b.assessment.date ? 1 : -1);
	const chart = rows.map((r) => ({
		name: r.assessment.name.slice(0, 12),
		pct: Math.round(r.scan.percentage)
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/students",
					className: "text-sm text-muted hover:text-ink",
					children: "Students"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-2 text-3xl",
					children: student.fullName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Roll ",
						student.rollNumber,
						" · LRN ",
						student.lrn || "—",
						" · Grade ",
						student.gradeLevel,
						"-",
						student.section
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "h-64",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "mb-3",
					children: "Progress"
				}), chart.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "80%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
						data: chart,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "name",
								tick: { fontSize: 11 }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								domain: [0, 100],
								tick: { fontSize: 11 }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								type: "monotone",
								dataKey: "pct",
								stroke: "#215c4a",
								strokeWidth: 2,
								dot: true
							})
						]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "No scored assessments yet."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "overflow-x-auto p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs tracking-wide text-muted uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Assessment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Score" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "%" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Date" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2",
								children: r.assessment.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [
								r.scan.score,
								"/",
								r.assessment.itemCount
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [Math.round(r.scan.percentage), "%"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: formatDate(r.assessment.date) })
						]
					}, r.scan.id)) })]
				})
			})
		]
	});
}
//#endregion
export { StudentHistory as component };
