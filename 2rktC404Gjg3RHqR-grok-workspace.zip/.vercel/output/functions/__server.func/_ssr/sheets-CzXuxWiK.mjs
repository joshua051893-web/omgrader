import { i as __toESM } from "../_runtime.mjs";
import { c as uid, n as db, o as nowIso, r as downloadBlob } from "./utils-DYXV9Fl_.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { s as defaultSheetConfig } from "./router-CLqpKR0U.mjs";
import { t as Button } from "./button-BW_xqhyX.mjs";
import { n as Textarea, t as Input } from "./input-BhHbezq6.mjs";
import { r as CardTitle, t as Card } from "./card-BL1KPyKC.mjs";
import { a as saveAssessment, r as getSettings } from "./repo-DVWp7U09.mjs";
import { t as Label } from "./label-ZkCXXQbY.mjs";
import { n as PAPER_SIZES } from "./types-wE3ipxpv.mjs";
import { t as useLiveQuery } from "../_libs/dexie-react-hooks.mjs";
import { n as canvasToBlob, r as renderSheetCanvas, t as buildLayout } from "./render-canvas-JAwDJkbQ.mjs";
import { n as StandardFonts, r as rgb, t as PDFDocument } from "../_libs/pdf-lib.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sheets-CzXuxWiK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MM = 72 / 25.4;
async function generateBubbleSheetPdf(cfg, students) {
	const layout = buildLayout(cfg);
	const doc = await PDFDocument.create();
	const font = await doc.embedFont(StandardFonts.Helvetica);
	const fontBold = await doc.embedFont(StandardFonts.HelveticaBold);
	const pages = students && students.length ? students : [void 0];
	for (const student of pages) {
		const page = doc.addPage([layout.widthMm * MM, layout.heightMm * MM]);
		const H = layout.heightMm * MM;
		const ink = rgb(.11, .1, .09);
		const paper = rgb(.985, .98, .965);
		page.drawRectangle({
			x: 0,
			y: 0,
			width: page.getWidth(),
			height: page.getHeight(),
			color: paper
		});
		const yFlip = (mmY) => H - mmY * MM;
		const mm = (n) => n * MM;
		for (const f of layout.fiducials) {
			page.drawRectangle({
				x: mm(f.x),
				y: yFlip(f.y + f.size),
				width: mm(f.size),
				height: mm(f.size),
				color: ink
			});
			if (f.id === "TR") page.drawRectangle({
				x: mm(f.x + f.size * .28),
				y: yFlip(f.y + f.size * .72),
				width: mm(f.size * .44),
				height: mm(f.size * .44),
				color: paper
			});
		}
		page.drawRectangle({
			x: mm(layout.orientationBar.x),
			y: yFlip(layout.orientationBar.y + layout.orientationBar.h),
			width: mm(layout.orientationBar.w),
			height: mm(layout.orientationBar.h),
			color: ink
		});
		page.drawText(cfg.school || "School", {
			x: mm(layout.nameBox.x),
			y: yFlip(layout.headerY + 3.2),
			size: 8,
			font: fontBold,
			color: ink
		});
		page.drawText(cfg.quizName || "Assessment", {
			x: mm(layout.nameBox.x),
			y: yFlip(layout.headerY + 11),
			size: 13,
			font: fontBold,
			color: ink
		});
		page.drawText([
			cfg.subject,
			cfg.teacher,
			cfg.date
		].filter(Boolean).join("   ·   "), {
			x: mm(layout.nameBox.x),
			y: yFlip(layout.headerY + 16.5),
			size: 8,
			font,
			color: ink
		});
		const nameY = layout.nameBox.y + 4;
		page.drawText("Name", {
			x: mm(layout.nameBox.x),
			y: yFlip(nameY + 1),
			size: 8,
			font,
			color: ink
		});
		page.drawRectangle({
			x: mm(layout.nameBox.x + 14),
			y: yFlip(nameY + 2.5),
			width: mm(layout.nameBox.w * .55),
			height: mm(6),
			borderColor: ink,
			borderWidth: .6
		});
		if (cfg.showName && student?.fullName) page.drawText(student.fullName, {
			x: mm(layout.nameBox.x + 16),
			y: yFlip(nameY + 1),
			size: 9,
			font,
			color: ink
		});
		if (layout.rollBubbles.length) {
			page.drawText("ROLL NUMBER", {
				x: mm(layout.nameBox.x),
				y: yFlip(layout.rollBubbles[0].cy - 6),
				size: 9,
				font: fontBold,
				color: ink
			});
			for (const b of layout.rollBubbles) drawPdfBubble(page, b.cx, b.cy, b.r, String(b.value), mm, yFlip, ink, font);
		}
		const byItem = /* @__PURE__ */ new Map();
		for (const b of layout.answerBubbles) {
			const arr = byItem.get(b.item) ?? [];
			arr.push(b);
			byItem.set(b.item, arr);
		}
		for (const [item, bubbles] of byItem) {
			const first = bubbles[0];
			page.drawText(String(item + 1).padStart(2, "0"), {
				x: mm(first.cx - 9),
				y: yFlip(first.cy + 1.2),
				size: 8,
				font: fontBold,
				color: ink
			});
			for (const b of bubbles) drawPdfBubble(page, b.cx, b.cy, b.r, b.choice, mm, yFlip, ink, font);
		}
		if (cfg.instructions) page.drawText(cfg.instructions.slice(0, 140), {
			x: mm(layout.nameBox.x),
			y: mm(10),
			size: 7,
			font,
			color: ink
		});
	}
	return doc.save();
}
function drawPdfBubble(page, cx, cy, r, label, mm, yFlip, ink, font) {
	const size = 6;
	page.drawCircle({
		x: mm(cx),
		y: yFlip(cy),
		size: mm(r),
		borderColor: ink,
		borderWidth: .7
	});
	const tw = font.widthOfTextAtSize(label, size);
	page.drawText(label, {
		x: mm(cx) - tw / 2,
		y: yFlip(cy) - 2.2,
		size,
		font,
		color: ink
	});
}
function SheetsPage() {
	const assessments = useLiveQuery(() => db.assessments.toArray()) ?? [];
	const templates = useLiveQuery(() => db.templates.toArray()) ?? [];
	const students = useLiveQuery(() => db.students.toArray()) ?? [];
	const [aid, setAid] = (0, import_react.useState)("");
	const selected = assessments.find((a) => a.id === aid) ?? assessments[0];
	const [cfg, setCfg] = (0, import_react.useState)(defaultSheetConfig());
	const [previewUrl, setPreviewUrl] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (selected) setCfg({
			...selected.sheetConfig,
			itemCount: selected.itemCount,
			quizName: selected.name
		});
	}, [selected?.id]);
	function patch(p) {
		setCfg((c) => ({
			...c,
			...p
		}));
	}
	async function preview() {
		const { canvas } = renderSheetCanvas(cfg, { student: students[0] ? {
			fullName: students[0].fullName,
			rollNumber: students[0].rollNumber,
			lrn: students[0].lrn,
			section: students[0].section
		} : void 0 });
		const blob = await canvasToBlob(canvas);
		setPreviewUrl(URL.createObjectURL(blob));
	}
	async function downloadBlank() {
		const bytes = await generateBubbleSheetPdf(cfg);
		downloadBlob(new Blob([bytes], { type: "application/pdf" }), `${cfg.quizName || "sheet"}.pdf`);
	}
	async function downloadPrefill() {
		const list = students.filter((s) => !selected || s.gradeLevel === selected.gradeLevel && s.section === selected.section);
		if (!list.length) {
			toast.error("No students in this class.");
			return;
		}
		const bytes = await generateBubbleSheetPdf(cfg, list);
		downloadBlob(new Blob([bytes], { type: "application/pdf" }), `${cfg.quizName}-prefilled.pdf`);
		toast.success(`Printed names for ${list.length} students.`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "Bubble sheets"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Registration marks are printed on every corner so scans can be aligned."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Assessment" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm",
						value: selected?.id ?? "",
						onChange: (e) => setAid(e.target.value),
						children: assessments.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: a.id,
							children: a.name
						}, a.id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Paper" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm",
								value: cfg.paper,
								onChange: (e) => patch({ paper: e.target.value }),
								children: PAPER_SIZES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: p }, p))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Orientation" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm",
								value: cfg.orientation,
								onChange: (e) => patch({ orientation: e.target.value }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "portrait",
									children: "Portrait"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "landscape",
									children: "Landscape"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Items" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: cfg.itemCount,
								onChange: (e) => patch({ itemCount: Number(e.target.value) })
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Choices" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm",
								value: cfg.choices.join(""),
								onChange: (e) => {
									patch({ choices: {
										ABCD: [
											"A",
											"B",
											"C",
											"D"
										],
										ABCDE: [
											"A",
											"B",
											"C",
											"D",
											"E"
										],
										ABCDEF: [
											"A",
											"B",
											"C",
											"D",
											"E",
											"F"
										]
									}[e.target.value] ?? [
										"A",
										"B",
										"C",
										"D"
									] });
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "ABCD",
										children: "A–D"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "ABCDE",
										children: "A–E"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "ABCDEF",
										children: "A–F"
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Roll digits" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: cfg.rollDigits,
								onChange: (e) => patch({ rollDigits: Number(e.target.value) })
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "School" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: cfg.school,
								onChange: (e) => patch({ school: e.target.value })
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Quiz name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: cfg.quizName,
						onChange: (e) => patch({ quizName: e.target.value })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Instructions" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: cfg.instructions,
						onChange: (e) => patch({ instructions: e.target.value })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: cfg.showRollBubbles,
							onChange: (e) => patch({ showRollBubbles: e.target.checked })
						}), "Roll number bubbles"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: cfg.showName,
							onChange: (e) => patch({ showName: e.target.checked })
						}), "Name area"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2 pt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: preview,
								children: "Preview"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: downloadBlank,
								children: "Download PDF"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: downloadPrefill,
								children: "Pre-filled class PDF"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: async () => {
									if (selected) await saveAssessment({
										...selected,
										sheetConfig: cfg,
										itemCount: cfg.itemCount
									});
									const schoolSettings = await getSettings();
									await db.templates.add({
										id: uid("tpl"),
										name: `${cfg.quizName || "Sheet"} – ${cfg.itemCount} items`,
										config: {
											...cfg,
											school: schoolSettings.schoolName
										},
										createdAt: nowIso()
									});
									toast.success("Template saved.");
								},
								children: "Save as template"
							})
						]
					}),
					templates.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Templates" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-2",
						children: templates.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setCfg(t.config),
							children: t.name
						}, t.id))
					})] })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "mb-3",
				children: "Preview"
			}), previewUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: previewUrl,
				alt: "Bubble sheet preview",
				className: "w-full rounded-[var(--radius-md)] border border-line"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Generate a preview to inspect alignment marks and bubble size."
			})] })]
		})]
	});
}
//#endregion
export { SheetsPage as component };
