import { t as Dexie } from "../_libs/dexie.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-DYXV9Fl_.js
var QuillmarkDB = class extends Dexie {
	students;
	assessments;
	scans;
	categories;
	templates;
	blobs;
	settings;
	backups;
	constructor() {
		super("quillmark-local");
		this.version(1).stores({
			students: "id, rollNumber, lrn, lastName, fullName, gradeLevel, section, schoolYear",
			assessments: "id, name, subject, gradeLevel, section, schoolYear, date, archived, categoryId",
			scans: "id, assessmentId, studentId, rollNumber, status, createdAt",
			categories: "id, sortOrder",
			templates: "id, name",
			blobs: "id, kind, createdAt",
			settings: "id",
			backups: "id, createdAt"
		});
	}
};
var db = new QuillmarkDB();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "") {
	const id = typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
	return prefix ? `${prefix}_${id}` : id;
}
function nowIso() {
	return (/* @__PURE__ */ new Date()).toISOString();
}
function formatDate(iso) {
	if (!iso) return "—";
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return iso;
	return d.toLocaleDateString(void 0, {
		year: "numeric",
		month: "short",
		day: "numeric"
	});
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
function fullName(first, middle, last) {
	return [
		first,
		middle,
		last
	].filter((p) => p && p.trim()).join(" ").replace(/\s+/g, " ").trim();
}
function padRoll(roll, digits = 3) {
	const t = String(roll ?? "").replace(/\D/g, "");
	if (!t) return "";
	return t.padStart(digits, "0");
}
//#endregion
export { fullName as a, uid as c, formatDate as i, db as n, nowIso as o, downloadBlob as r, padRoll as s, cn as t };
