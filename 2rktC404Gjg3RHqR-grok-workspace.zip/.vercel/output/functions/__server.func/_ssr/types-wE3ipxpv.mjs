//#region node_modules/.nitro/vite/services/ssr/assets/types-wE3ipxpv.js
var ASSESSMENT_TYPES = [
	"Quiz",
	"Long Test",
	"Unit Test",
	"Periodical Test",
	"Pre-Test",
	"Post-Test",
	"Activity",
	"Other"
];
var PAPER_SIZES = [
	"A6",
	"A5",
	"A4",
	"Letter",
	"Legal",
	"Custom"
];
//#endregion
export { PAPER_SIZES as n, ASSESSMENT_TYPES as t };
