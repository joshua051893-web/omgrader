//#region node_modules/.nitro/vite/services/ssr/assets/render-canvas-JAwDJkbQ.js
var PAPER_MM = {
	A6: [105, 148],
	A5: [148, 210],
	A4: [210, 297],
	Letter: [215.9, 279.4],
	Legal: [215.9, 355.6]
};
function paperDims(cfg) {
	let [w, h] = cfg.paper === "Custom" ? [cfg.customWidthMm || 210, cfg.customHeightMm || 297] : PAPER_MM[cfg.paper] ?? PAPER_MM.A4;
	if (cfg.orientation === "landscape") {
		const t = w;
		w = h;
		h = t;
	}
	return {
		widthMm: w,
		heightMm: h
	};
}
function buildLayout(cfg) {
	const { widthMm, heightMm } = paperDims(cfg);
	const margin = Math.max(8, Math.min(widthMm, heightMm) * .04);
	const fid = Math.max(8, Math.min(12, widthMm * .045));
	const fiducials = [
		{
			id: "TL",
			x: margin,
			y: margin,
			size: fid
		},
		{
			id: "TR",
			x: widthMm - margin - fid,
			y: margin,
			size: fid
		},
		{
			id: "BL",
			x: margin,
			y: heightMm - margin - fid,
			size: fid
		},
		{
			id: "BR",
			x: widthMm - margin - fid,
			y: heightMm - margin - fid,
			size: fid
		}
	];
	const orientationBar = {
		x: margin + fid + 4,
		y: margin + 1.5,
		w: Math.min(28, widthMm * .14),
		h: 3.2
	};
	const contentLeft = margin + fid + 4;
	const contentRight = widthMm - margin - fid - 4;
	const contentTop = margin + fid + 6;
	const contentBottom = heightMm - margin - fid - 4;
	const headerY = contentTop;
	let y = contentTop + 28;
	const nameBox = {
		x: contentLeft,
		y: y - 2,
		w: contentRight - contentLeft,
		h: 14
	};
	y += 16;
	const rollBubbles = [];
	const digits = cfg.showRollBubbles ? cfg.rollDigits : 0;
	const rollR = 3.1;
	if (digits > 0) {
		const colGap = 9.5;
		const rowGap = 6.4;
		digits * colGap;
		const startX = contentLeft + 28;
		const startY = y + 8;
		for (let d = 0; d < digits; d++) for (let v = 0; v < 10; v++) rollBubbles.push({
			digitIndex: d,
			value: v,
			cx: startX + d * colGap,
			cy: startY + v * rowGap,
			r: rollR
		});
		y = startY + 10 * rowGap + 8;
	} else y += 4;
	const items = Math.max(1, cfg.itemCount);
	const choices = cfg.choices.length ? cfg.choices : [
		"A",
		"B",
		"C",
		"D"
	];
	const bubbleR = 3.4;
	const choiceGap = 8.2;
	const rowGap = 8.4;
	const usableH = contentBottom - y - 4;
	const maxRows = Math.max(5, Math.floor(usableH / rowGap));
	const columns = Math.max(1, Math.ceil(items / maxRows));
	const colWidth = (contentRight - contentLeft) / columns;
	const answerBubbles = [];
	for (let i = 0; i < items; i++) {
		const col = Math.floor(i / maxRows);
		const row = i % maxRows;
		const baseX = contentLeft + col * colWidth + 12;
		const cy = y + row * rowGap + bubbleR;
		for (let c = 0; c < choices.length; c++) answerBubbles.push({
			item: i,
			choice: choices[c],
			cx: baseX + c * choiceGap,
			cy,
			r: bubbleR
		});
	}
	return {
		widthMm,
		heightMm,
		fiducials,
		orientationBar,
		rollBubbles,
		answerBubbles,
		nameBox,
		headerY,
		columns
	};
}
function renderSheetCanvas(cfg, opts = {}) {
	const layout = buildLayout(cfg);
	const scale = (opts.dpi ?? 150) / 25.4;
	const canvas = document.createElement("canvas");
	canvas.width = Math.round(layout.widthMm * scale);
	canvas.height = Math.round(layout.heightMm * scale);
	const ctx = canvas.getContext("2d");
	ctx.fillStyle = "#fbfaf6";
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	ctx.scale(scale, scale);
	drawSheet(ctx, cfg, layout, opts.student, opts.fill);
	return {
		canvas,
		layout
	};
}
function drawSheet(ctx, cfg, layout, student, fill) {
	ctx.strokeStyle = "#1c1917";
	ctx.fillStyle = "#1c1917";
	ctx.lineWidth = .35;
	for (const f of layout.fiducials) {
		ctx.fillRect(f.x, f.y, f.size, f.size);
		if (f.id === "TR") {
			ctx.fillStyle = "#fbfaf6";
			ctx.fillRect(f.x + f.size * .28, f.y + f.size * .28, f.size * .44, f.size * .44);
			ctx.fillStyle = "#1c1917";
		}
	}
	ctx.fillRect(layout.orientationBar.x, layout.orientationBar.y, layout.orientationBar.w, layout.orientationBar.h);
	ctx.font = "bold 5.2px 'IBM Plex Sans', sans-serif";
	ctx.fillText(cfg.school || "School", layout.nameBox.x, layout.headerY + 2);
	ctx.font = "bold 7.2px 'IBM Plex Sans', sans-serif";
	ctx.fillText(cfg.quizName || "Assessment", layout.nameBox.x, layout.headerY + 10);
	ctx.font = "3.8px 'IBM Plex Sans', sans-serif";
	const meta = [
		cfg.subject,
		cfg.teacher,
		cfg.date
	].filter(Boolean).join("  ·  ");
	ctx.fillText(meta, layout.nameBox.x, layout.headerY + 16);
	ctx.font = "3.6px 'IBM Plex Sans', sans-serif";
	const nameY = layout.nameBox.y + 4;
	ctx.fillText("Name", layout.nameBox.x, nameY);
	ctx.strokeRect(layout.nameBox.x + 14, nameY - 3.5, layout.nameBox.w * .55, 6);
	if (cfg.showName && student?.fullName) {
		ctx.font = "4.2px 'IBM Plex Sans', sans-serif";
		ctx.fillText(student.fullName, layout.nameBox.x + 16, nameY + .8);
	}
	ctx.font = "3.6px 'IBM Plex Sans', sans-serif";
	if (cfg.showSection) {
		ctx.fillText("Section", layout.nameBox.x + layout.nameBox.w * .62, nameY);
		ctx.strokeRect(layout.nameBox.x + layout.nameBox.w * .74, nameY - 3.5, layout.nameBox.w * .24, 6);
		if (student?.section) ctx.fillText(student.section, layout.nameBox.x + layout.nameBox.w * .76, nameY + .8);
	}
	if (cfg.showLrn) {
		ctx.fillText("LRN", layout.nameBox.x, nameY + 8);
		ctx.strokeRect(layout.nameBox.x + 14, nameY + 4.5, 70, 6);
		if (student?.lrn) ctx.fillText(student.lrn, layout.nameBox.x + 16, nameY + 9);
	}
	if (layout.rollBubbles.length) {
		ctx.font = "bold 4px 'IBM Plex Sans', sans-serif";
		ctx.fillText("ROLL NUMBER", layout.nameBox.x, layout.rollBubbles[0].cy - 6);
		const digits = cfg.rollDigits;
		const roll = (fill?.rollNumber ?? student?.rollNumber ?? "").replace(/\D/g, "").padStart(digits, "0");
		for (const b of layout.rollBubbles) {
			const marked = fill?.rollNumber != null && roll[b.digitIndex] === String(b.value);
			drawBubble(ctx, b.cx, b.cy, b.r, String(b.value), marked);
		}
	}
	ctx.font = "3.2px 'IBM Plex Sans', sans-serif";
	const wrap = wrapText(cfg.instructions, 90);
	let iy = layout.heightMm - 18;
	for (const line of wrap.slice(0, 2)) {
		ctx.fillText(line, layout.nameBox.x, iy);
		iy += 4;
	}
	cfg.choices;
	const byItem = /* @__PURE__ */ new Map();
	for (const b of layout.answerBubbles) {
		const arr = byItem.get(b.item) ?? [];
		arr.push(b);
		byItem.set(b.item, arr);
	}
	for (const [item, bubbles] of byItem) {
		const first = bubbles[0];
		ctx.font = "bold 3.6px 'IBM Plex Sans', sans-serif";
		ctx.fillStyle = "#1c1917";
		ctx.fillText(String(item + 1).padStart(2, "0"), first.cx - 9, first.cy + 1.3);
		const ans = fill?.answers[item] ?? null;
		for (const b of bubbles) drawBubble(ctx, b.cx, b.cy, b.r, b.choice, ans === b.choice);
	}
}
function drawBubble(ctx, cx, cy, r, label, filled) {
	ctx.beginPath();
	ctx.arc(cx, cy, r, 0, Math.PI * 2);
	if (filled) {
		ctx.fillStyle = "#1c1917";
		ctx.fill();
		ctx.fillStyle = "#fbfaf6";
		ctx.font = `bold ${Math.max(2.4, r * .7)}px 'IBM Plex Sans', sans-serif`;
		ctx.textAlign = "center";
		ctx.fillText(label, cx, cy + r * .35);
		ctx.textAlign = "left";
		ctx.fillStyle = "#1c1917";
	} else {
		ctx.strokeStyle = "#1c1917";
		ctx.lineWidth = .38;
		ctx.stroke();
		ctx.font = `${Math.max(2.4, r * .7)}px 'IBM Plex Sans', sans-serif`;
		ctx.textAlign = "center";
		ctx.fillStyle = "#1c1917";
		ctx.fillText(label, cx, cy + r * .35);
		ctx.textAlign = "left";
	}
}
function wrapText(text, maxChars) {
	const words = (text || "").split(/\s+/);
	const lines = [];
	let cur = "";
	for (const w of words) {
		const next = cur ? `${cur} ${w}` : w;
		if (next.length > maxChars) {
			if (cur) lines.push(cur);
			cur = w;
		} else cur = next;
	}
	if (cur) lines.push(cur);
	return lines;
}
function canvasToBlob(canvas, type = "image/png") {
	return new Promise((resolve, reject) => {
		canvas.toBlob((b) => b ? resolve(b) : reject(/* @__PURE__ */ new Error("Could not export image")), type);
	});
}
//#endregion
export { canvasToBlob as n, renderSheetCanvas as r, buildLayout as t };
