import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./utils-DYXV9Fl_.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as Route$1 } from "./router-CLqpKR0U.mjs";
import { t as Button } from "./button-BW_xqhyX.mjs";
import { t as Input } from "./input-BhHbezq6.mjs";
import { r as CardTitle, t as Card } from "./card-BL1KPyKC.mjs";
import { o as saveScan, t as blobUrl } from "./repo-DVWp7U09.mjs";
import { t as useLiveQuery } from "../_libs/dexie-react-hooks.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/review._id-ogkvrePX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReviewPage() {
	const { id } = Route$1.useParams();
	const scan = useLiveQuery(() => db.scans.get(id), [id]);
	const assessment = useLiveQuery(() => scan ? db.assessments.get(scan.assessmentId) : void 0, [scan?.assessmentId]);
	const students = useLiveQuery(() => db.students.toArray()) ?? [];
	const [orig, setOrig] = (0, import_react.useState)(null);
	const [marked, setMarked] = (0, import_react.useState)(null);
	const [roll, setRoll] = (0, import_react.useState)("");
	const [answers, setAnswers] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (!scan) return;
		setRoll(scan.rollNumber);
		setAnswers(scan.answers);
		blobUrl(scan.originalBlobId).then(setOrig);
		blobUrl(scan.markedBlobId).then(setMarked);
	}, [scan?.id]);
	if (!scan || !assessment) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Sheet not found."
	});
	const current = scan;
	const asm = assessment;
	async function apply() {
		const student = students.find((s) => s.rollNumber === roll);
		const correct = answers.reduce((n, a, i) => n + (a && a === asm.answerKey[i] ? 1 : 0), 0);
		const blank = answers.filter((a) => !a).length;
		const wrong = asm.itemCount - correct - blank;
		const percentage = correct / asm.itemCount * 100;
		const status = correct >= asm.passingScore ? "passed" : "failed";
		await saveScan({
			...current,
			rollNumber: roll,
			studentId: student?.id ?? null,
			answers,
			correct,
			wrong,
			blank,
			score: correct,
			percentage,
			status,
			flags: student ? [] : ["missing_student"],
			reviewed: true
		});
		toast.success("Corrections saved.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/scan",
					className: "text-sm text-muted",
					children: "Scan papers"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-1 text-3xl",
					children: "Manual review"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Confidence ",
						(current.confidence * 100).toFixed(0),
						"% · ",
						current.flags.join(", ") || "No flags"
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "mb-2",
					children: "Original"
				}), orig ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: orig,
					alt: "Original scan",
					className: "w-full rounded-[var(--radius-md)]"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "No original image."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "mb-2",
					children: "Marked copy"
				}), marked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: marked,
					alt: "Marked paper",
					className: "w-full rounded-[var(--radius-md)]"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "No marked copy yet."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Identification" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: roll,
						onChange: (e) => setRoll(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: students.find((s) => s.rollNumber === roll)?.fullName ?? "No matching student"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: answers.map((ans, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs text-muted",
							children: [i + 1, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "ml-1 h-8 rounded border border-line bg-surface",
								value: ans ?? "",
								onChange: (e) => {
									const next = [...answers];
									next[i] = e.target.value || null;
									setAnswers(next);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "—"
								}), asm.sheetConfig.choices.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: c,
									children: [c, asm.answerKey[i] === c ? " ✓" : ""]
								}, c))]
							})]
						}, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: apply,
						children: "Save corrections"
					})
				]
			})
		]
	});
}
//#endregion
export { ReviewPage as component };
