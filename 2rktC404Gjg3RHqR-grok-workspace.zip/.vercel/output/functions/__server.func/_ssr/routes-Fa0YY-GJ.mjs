import { i as formatDate, n as db } from "./utils-DYXV9Fl_.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as ScanLine, c as ClipboardList, i as Settings, l as ChartColumn, n as Users, o as Printer, u as BookOpen } from "../_libs/lucide-react.mjs";
import { t as Button } from "./button-BW_xqhyX.mjs";
import { n as CardDesc, r as CardTitle, t as Card } from "./card-BL1KPyKC.mjs";
import { t as Badge } from "./badge-PKkwSRI6.mjs";
import { t as useLiveQuery } from "../_libs/dexie-react-hooks.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Fa0YY-GJ.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const students = useLiveQuery(() => db.students.toArray()) ?? [];
	const assessments = useLiveQuery(() => db.assessments.toArray()) ?? [];
	const scans = useLiveQuery(() => db.scans.orderBy("createdAt").reverse().limit(8).toArray()) ?? [];
	const review = scans.filter((s) => s.flags.length && !s.reviewed).length;
	const avg = scans.length === 0 ? null : scans.reduce((p, s) => p + s.percentage, 0) / Math.max(1, scans.length);
	const actions = [
		{
			to: "/students",
			label: "Students",
			icon: Users
		},
		{
			to: "/assessments",
			label: "Create assessment",
			icon: ClipboardList
		},
		{
			to: "/sheets",
			label: "Generate bubble sheets",
			icon: Printer
		},
		{
			to: "/scan",
			label: "Scan papers",
			icon: ScanLine
		},
		{
			to: "/gradebook",
			label: "Gradebook",
			icon: BookOpen
		},
		{
			to: "/reports",
			label: "Results",
			icon: ChartColumn
		},
		{
			to: "/settings",
			label: "Settings",
			icon: Settings
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-muted uppercase",
					children: "Teacher workspace"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-1 text-4xl tracking-tight",
					children: "Quillmark"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-muted",
					children: "Keep the roster, print bubble sheets, scan a whole class, and update the gradebook — all stored on this device."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Students",
						value: students.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Assessments",
						value: assessments.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Class average",
						value: avg == null ? "—" : `${avg.toFixed(0)}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Needs review",
						value: review,
						warn: review > 0
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: actions.map((a) => {
					const Icon = a.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: a.to,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							className: "h-auto w-full flex-col items-start gap-3 p-4 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a.label })]
						})
					}, a.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Recent assessments" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, {
						className: "mb-4",
						children: "Open an assessment to edit the key or scan papers."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-2",
						children: [assessments.slice(0, 5).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/assessments/$id",
							params: { id: a.id },
							className: "flex items-center justify-between rounded-[var(--radius-md)] px-2 py-2 hover:bg-bg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: a.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									a.subject,
									" · ",
									formatDate(a.date),
									" · ",
									a.itemCount,
									" items"
								]
							})] }), a.archived ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Archived" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "accent",
								children: a.type
							})]
						}) }, a.id)), !assessments.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "No assessments yet."
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Latest scans" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, {
						className: "mb-4",
						children: "Flagged sheets wait here until you confirm them."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-2",
						children: [scans.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Roll ",
								s.rollNumber,
								" · ",
								s.score,
								" pts"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: s.status === "passed" ? "ok" : s.status === "flagged" ? "warn" : "danger",
								children: s.status
							})]
						}, s.id)), !scans.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "No scans yet. Try Scan papers."
						})]
					})
				] })]
			})
		]
	});
}
function Stat({ label, value, warn }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `mt-2 font-display text-3xl tabular-nums ${warn ? "text-warn" : ""}`,
			children: value
		})]
	});
}
//#endregion
export { Home as component };
