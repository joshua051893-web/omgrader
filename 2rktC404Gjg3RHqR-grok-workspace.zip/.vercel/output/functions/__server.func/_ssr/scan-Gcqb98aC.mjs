import { i as __toESM } from "../_runtime.mjs";
import { c as uid, n as db, o as nowIso, s as padRoll } from "./utils-DYXV9Fl_.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Route$6 } from "./router-CLqpKR0U.mjs";
import { t as Button } from "./button-BW_xqhyX.mjs";
import { r as CardTitle, t as Card } from "./card-BL1KPyKC.mjs";
import { t as Badge } from "./badge-PKkwSRI6.mjs";
import { i as putBlob, o as saveScan } from "./repo-DVWp7U09.mjs";
import { t as useLiveQuery } from "../_libs/dexie-react-hooks.mjs";
import { n as canvasToBlob, r as renderSheetCanvas, t as buildLayout } from "./render-canvas-JAwDJkbQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scan-Gcqb98aC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function loadImageElement(src) {
	if (src instanceof HTMLCanvasElement) return Promise.resolve(src);
	if (typeof ImageBitmap !== "undefined" && src instanceof ImageBitmap) {
		const c = document.createElement("canvas");
		c.width = src.width;
		c.height = src.height;
		c.getContext("2d").drawImage(src, 0, 0);
		return Promise.resolve(c);
	}
	if (src instanceof HTMLImageElement) {
		const c = document.createElement("canvas");
		c.width = src.naturalWidth || src.width;
		c.height = src.naturalHeight || src.height;
		c.getContext("2d").drawImage(src, 0, 0);
		return Promise.resolve(c);
	}
	const blob = src;
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(blob);
		const img = new Image();
		img.onload = () => {
			const c = document.createElement("canvas");
			c.width = img.naturalWidth;
			c.height = img.naturalHeight;
			c.getContext("2d").drawImage(img, 0, 0);
			URL.revokeObjectURL(url);
			resolve(c);
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("The image file could not be opened. Try a JPEG or PNG scan."));
		};
		img.src = url;
	});
}
function toGrayscale(canvas) {
	const img = canvas.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, canvas.width, canvas.height);
	const g = new Uint8ClampedArray(img.width * img.height);
	for (let i = 0, p = 0; i < img.data.length; i += 4, p++) g[p] = img.data[i] * .299 + img.data[i + 1] * .587 + img.data[i + 2] * .114 | 0;
	return {
		data: g,
		width: img.width,
		height: img.height
	};
}
function otsuThreshold(gray) {
	const hist = new Array(256).fill(0);
	for (let i = 0; i < gray.length; i++) hist[gray[i]]++;
	const total = gray.length;
	let sum = 0;
	for (let t = 0; t < 256; t++) sum += t * hist[t];
	let sumB = 0;
	let wB = 0;
	let max = 0;
	let thresh = 127;
	for (let t = 0; t < 256; t++) {
		wB += hist[t];
		if (wB === 0) continue;
		const wF = total - wB;
		if (wF === 0) break;
		sumB += t * hist[t];
		const mB = sumB / wB;
		const mF = (sum - sumB) / wF;
		const between = wB * wF * (mB - mF) * (mB - mF);
		if (between > max) {
			max = between;
			thresh = t;
		}
	}
	return thresh;
}
function findFiducials(gray, width, height) {
	const t = otsuThreshold(gray);
	const bin = new Uint8Array(gray.length);
	for (let i = 0; i < gray.length; i++) bin[i] = gray[i] < t * .78 ? 1 : 0;
	const blobs = connectedSquares(bin, width, height);
	const minA = width * height * 25e-5;
	const maxA = width * height * .04;
	const squares = blobs.filter((b) => {
		const w = b.maxX - b.minX + 1;
		const h = b.maxY - b.minY + 1;
		const aspect = w / h;
		const fill = b.area / (w * h);
		return b.area >= minA && b.area <= maxA && aspect > .65 && aspect < 1.45 && fill > .45;
	});
	if (squares.length < 4) return null;
	squares.sort((a, b) => a.area - b.area);
	const corners = pickFourCorners(squares.slice(-8), width, height);
	if (!corners) return null;
	return {
		tl: {
			x: corners.tl.cx,
			y: corners.tl.cy
		},
		tr: {
			x: corners.tr.cx,
			y: corners.tr.cy
		},
		bl: {
			x: corners.bl.cx,
			y: corners.bl.cy
		},
		br: {
			x: corners.br.cx,
			y: corners.br.cy
		}
	};
}
function pickFourCorners(blobs, width, height) {
	if (blobs.length < 4) return null;
	const scored = blobs.map((b) => ({
		b,
		tl: b.cx + b.cy,
		tr: width - b.cx + b.cy,
		bl: b.cx + (height - b.cy),
		br: width - b.cx + (height - b.cy)
	}));
	const tl = scored.reduce((a, c) => c.tl < a.tl ? c : a).b;
	const tr = scored.reduce((a, c) => c.tr < a.tr ? c : a).b;
	const bl = scored.reduce((a, c) => c.bl < a.bl ? c : a).b;
	const br = scored.reduce((a, c) => c.br < a.br ? c : a).b;
	if ((/* @__PURE__ */ new Set([
		tl,
		tr,
		bl,
		br
	])).size < 4) return null;
	return {
		tl,
		tr,
		bl,
		br
	};
}
function connectedSquares(bin, width, height) {
	const seen = new Uint8Array(bin.length);
	const blobs = [];
	const qx = [];
	const qy = [];
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
		const i = y * width + x;
		if (!bin[i] || seen[i]) continue;
		qx.length = 0;
		qy.length = 0;
		qx.push(x);
		qy.push(y);
		seen[i] = 1;
		let minX = x, minY = y, maxX = x, maxY = y, area = 0, sx = 0, sy = 0;
		while (qx.length) {
			const cx = qx.pop();
			const cy = qy.pop();
			area++;
			sx += cx;
			sy += cy;
			if (cx < minX) minX = cx;
			if (cy < minY) minY = cy;
			if (cx > maxX) maxX = cx;
			if (cy > maxY) maxY = cy;
			for (const [dx, dy] of [
				[1, 0],
				[-1, 0],
				[0, 1],
				[0, -1]
			]) {
				const nx = cx + dx;
				const ny = cy + dy;
				if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
				const ni = ny * width + nx;
				if (bin[ni] && !seen[ni]) {
					seen[ni] = 1;
					qx.push(nx);
					qy.push(ny);
				}
			}
		}
		if (area > 20) blobs.push({
			minX,
			minY,
			maxX,
			maxY,
			area,
			cx: sx / area,
			cy: sy / area
		});
	}
	return blobs;
}
function solveHomography(src, dst) {
	if (src.length < 4 || dst.length < 4) return null;
	const A = [];
	const b = [];
	for (let i = 0; i < 4; i++) {
		const s = src[i];
		const d = dst[i];
		A.push([
			s.x,
			s.y,
			1,
			0,
			0,
			0,
			-d.x * s.x,
			-d.x * s.y
		]);
		b.push(d.x);
		A.push([
			0,
			0,
			0,
			s.x,
			s.y,
			1,
			-d.y * s.x,
			-d.y * s.y
		]);
		b.push(d.y);
	}
	const h = gaussianSolve(A, b);
	if (!h) return null;
	h.push(1);
	return h;
}
function gaussianSolve(A, b) {
	const n = b.length;
	const M = A.map((row, i) => [...row, b[i]]);
	for (let col = 0; col < n; col++) {
		let pivot = col;
		for (let r = col + 1; r < n; r++) if (Math.abs(M[r][col]) > Math.abs(M[pivot][col])) pivot = r;
		const tmp = M[col];
		M[col] = M[pivot];
		M[pivot] = tmp;
		const div = M[col][col];
		if (Math.abs(div) < 1e-12) return null;
		for (let c = col; c <= n; c++) M[col][c] /= div;
		for (let r = 0; r < n; r++) {
			if (r === col) continue;
			const f = M[r][col];
			for (let c = col; c <= n; c++) M[r][c] -= f * M[col][c];
		}
	}
	return M.map((row) => row[n]);
}
function applyH(h, x, y) {
	const w = h[6] * x + h[7] * y + h[8];
	return {
		x: (h[0] * x + h[1] * y + h[2]) / w,
		y: (h[3] * x + h[4] * y + h[5]) / w
	};
}
function warpToCanvas(src, h, width, height) {
	const out = document.createElement("canvas");
	out.width = width;
	out.height = height;
	const srcData = src.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, src.width, src.height);
	const dctx = out.getContext("2d");
	const dst = dctx.createImageData(width, height);
	const inv = invertH(h);
	if (!inv) return out;
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
		const p = applyH(inv, x, y);
		const sx = p.x | 0;
		const sy = p.y | 0;
		if (sx < 0 || sy < 0 || sx >= src.width - 1 || sy >= src.height - 1) continue;
		const si = (sy * src.width + sx) * 4;
		const di = (y * width + x) * 4;
		dst.data[di] = srcData.data[si];
		dst.data[di + 1] = srcData.data[si + 1];
		dst.data[di + 2] = srcData.data[si + 2];
		dst.data[di + 3] = 255;
	}
	dctx.putImageData(dst, 0, 0);
	return out;
}
function invertH(h) {
	const m = [
		[
			h[0],
			h[1],
			h[2]
		],
		[
			h[3],
			h[4],
			h[5]
		],
		[
			h[6],
			h[7],
			h[8]
		]
	];
	const det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
	if (Math.abs(det) < 1e-12) return null;
	return [
		(m[1][1] * m[2][2] - m[1][2] * m[2][1]) / det,
		(m[0][2] * m[2][1] - m[0][1] * m[2][2]) / det,
		(m[0][1] * m[1][2] - m[0][2] * m[1][1]) / det,
		(m[1][2] * m[2][0] - m[1][0] * m[2][2]) / det,
		(m[0][0] * m[2][2] - m[0][2] * m[2][0]) / det,
		(m[0][2] * m[1][0] - m[0][0] * m[1][2]) / det,
		(m[1][0] * m[2][1] - m[1][1] * m[2][0]) / det,
		(m[0][1] * m[2][0] - m[0][0] * m[2][1]) / det,
		(m[0][0] * m[1][1] - m[0][1] * m[1][0]) / det
	];
}
async function detectSheet(source, assessment) {
	const cfg = {
		...assessment.sheetConfig,
		itemCount: assessment.itemCount
	};
	const layout = buildLayout(cfg);
	const canvas = await loadImageElement(source);
	const gray = toGrayscale(canvas);
	const corners = findFiducials(gray.data, gray.width, gray.height);
	if (!corners) return fail(canvas, [
		"unreadable",
		"invalid_sheet",
		"needs_review"
	]);
	const srcPts = [
		corners.tl,
		corners.tr,
		corners.br,
		corners.bl
	];
	const fid = {
		TL: layout.fiducials.find((f) => f.id === "TL"),
		TR: layout.fiducials.find((f) => f.id === "TR"),
		BR: layout.fiducials.find((f) => f.id === "BR"),
		BL: layout.fiducials.find((f) => f.id === "BL")
	};
	const scale = 5;
	const outW = Math.round(layout.widthMm * scale);
	const outH = Math.round(layout.heightMm * scale);
	const mm = (xMm, yMm) => ({
		x: xMm / layout.widthMm * outW,
		y: yMm / layout.heightMm * outH
	});
	const hPx = solveHomography(srcPts, [
		mm(fid.TL.x + fid.TL.size / 2, fid.TL.y + fid.TL.size / 2),
		mm(fid.TR.x + fid.TR.size / 2, fid.TR.y + fid.TR.size / 2),
		mm(fid.BR.x + fid.BR.size / 2, fid.BR.y + fid.BR.size / 2),
		mm(fid.BL.x + fid.BL.size / 2, fid.BL.y + fid.BL.size / 2)
	]);
	if (!hPx) return fail(canvas, ["unreadable", "needs_review"]);
	const warped = warpToCanvas(canvas, hPx, outW, outH);
	const wimg = warped.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, outW, outH);
	const darknessAt = (mmX, mmY, rMm) => {
		const cx = mmX / layout.widthMm * outW;
		const cy = mmY / layout.heightMm * outH;
		const r = Math.max(2, rMm / layout.widthMm * outW * .55);
		let dark = 0;
		let n = 0;
		const r2 = r * r;
		for (let y = -r; y <= r; y++) for (let x = -r; x <= r; x++) {
			if (x * x + y * y > r2) continue;
			const px = cx + x | 0;
			const py = cy + y | 0;
			if (px < 0 || py < 0 || px >= outW || py >= outH) continue;
			const i = (py * outW + px) * 4;
			const g = wimg.data[i] * .299 + wimg.data[i + 1] * .587 + wimg.data[i + 2] * .114;
			dark += (255 - g) / 255;
			n++;
		}
		return n ? dark / n : 0;
	};
	const flags = [];
	let roll = "";
	let rollConf = 1;
	if (layout.rollBubbles.length) {
		const digits = cfg.rollDigits;
		const chars = [];
		for (let d = 0; d < digits; d++) {
			const scores = layout.rollBubbles.filter((b) => b.digitIndex === d).map((b) => ({
				v: b.value,
				s: darknessAt(b.cx, b.cy, b.r)
			}));
			scores.sort((a, b) => b.s - a.s);
			const top = scores[0];
			const second = scores[1] ?? {
				s: 0,
				v: 0
			};
			if (top.s < .38) {
				chars.push("?");
				rollConf *= .4;
				flags.push("unclear_bubble");
			} else if (top.s - second.s < .12) {
				chars.push("?");
				rollConf *= .5;
				flags.push("unclear_bubble");
			} else {
				chars.push(String(top.v));
				rollConf *= Math.min(1, .55 + top.s);
			}
		}
		roll = chars.join("");
		if (roll.includes("?")) flags.push("unknown_roll");
	}
	const answers = [];
	const byItem = /* @__PURE__ */ new Map();
	for (const b of layout.answerBubbles) {
		const arr = byItem.get(b.item) ?? [];
		arr.push(b);
		byItem.set(b.item, arr);
	}
	let confAcc = 0;
	for (let i = 0; i < assessment.itemCount; i++) {
		const bubbles = byItem.get(i) ?? [];
		const fillRatios = {};
		const scored = bubbles.map((b) => {
			const s = darknessAt(b.cx, b.cy, b.r);
			fillRatios[b.choice] = s;
			return {
				choice: b.choice,
				s
			};
		});
		scored.sort((a, b) => b.s - a.s);
		const top = scored[0];
		const second = scored[1];
		let choice = null;
		let multiple = false;
		let unclear = false;
		let c = .9;
		if (!top || top.s < .34) {
			choice = null;
			c = .85;
		} else if (second && second.s > .34 && top.s - second.s < .1) {
			multiple = true;
			unclear = true;
			choice = top.choice;
			c = .35;
			flags.push("multiple_answers");
		} else if (top.s < .42) {
			unclear = true;
			choice = top.choice;
			c = .45;
			flags.push("unclear_bubble");
		} else {
			choice = top.choice;
			c = Math.min(.99, .5 + top.s);
		}
		confAcc += c;
		answers.push({
			item: i,
			choice,
			confidence: c,
			multiple,
			unclear,
			fillRatios
		});
	}
	const unique = Array.from(new Set(flags));
	if (unique.length) unique.push("needs_review");
	return {
		warped,
		rollNumber: roll.includes("?") ? roll : padRoll(roll, cfg.rollDigits),
		rollConfidence: rollConf,
		answers,
		flags: Array.from(new Set(unique)),
		confidence: answers.length ? confAcc / answers.length : 0,
		valid: true
	};
}
function fail(canvas, flags) {
	return {
		warped: canvas,
		rollNumber: "",
		rollConfidence: 0,
		answers: [],
		flags,
		confidence: 0,
		valid: false
	};
}
function scoreDetection(assessment, detection, students, existingRolls) {
	const flags = [...detection.flags];
	const key = assessment.answerKey;
	const answers = detection.answers.map((a) => a.multiple ? null : a.choice);
	let correct = 0;
	let wrong = 0;
	let blank = 0;
	for (let i = 0; i < assessment.itemCount; i++) {
		const a = answers[i] ?? null;
		const k = key[i];
		if (!a) blank++;
		else if (k && a === k) correct++;
		else wrong++;
	}
	const score = correct;
	const percentage = assessment.itemCount ? correct / assessment.itemCount * 100 : 0;
	const roll = detection.rollNumber.replace(/\?/g, "");
	const padded = padRoll(roll, assessment.sheetConfig.rollDigits);
	const student = students.find((s) => s.rollNumber === padded);
	if (!roll || detection.rollNumber.includes("?")) flags.push("unknown_roll");
	if (roll && !student) flags.push("missing_student");
	if (padded && existingRolls.includes(padded)) flags.push("duplicate_roll");
	let status = "pending";
	const uniq = Array.from(new Set(flags));
	if (uniq.includes("unreadable") || uniq.includes("invalid_sheet")) status = "flagged";
	else if (uniq.length) status = "flagged";
	else if (score >= assessment.passingScore) status = "passed";
	else status = "failed";
	return {
		assessmentId: assessment.id,
		studentId: student?.id ?? null,
		rollNumber: detection.rollNumber,
		answers,
		flags: uniq,
		score,
		correct,
		wrong,
		blank,
		percentage,
		status,
		confidence: detection.confidence,
		remarks: "",
		reviewed: false
	};
}
async function renderMarkedPaper(warped, assessment, result, studentName) {
	const cfg = {
		...assessment.sheetConfig,
		itemCount: assessment.itemCount
	};
	const layout = buildLayout(cfg);
	const out = document.createElement("canvas");
	out.width = warped.width;
	out.height = warped.height;
	const ctx = out.getContext("2d");
	ctx.drawImage(warped, 0, 0);
	const sx = out.width / layout.widthMm;
	const sy = out.height / layout.heightMm;
	const byItem = /* @__PURE__ */ new Map();
	for (const b of layout.answerBubbles) {
		const arr = byItem.get(b.item) ?? [];
		arr.push(b);
		byItem.set(b.item, arr);
	}
	for (let i = 0; i < assessment.itemCount; i++) {
		const studentAns = result.answers[i] ?? null;
		const key = assessment.answerKey[i];
		const bubbles = byItem.get(i) ?? [];
		for (const b of bubbles) {
			const x = b.cx * sx;
			const y = b.cy * sy;
			const r = b.r * sx * 1.15;
			if (key && b.choice === key) {
				ctx.strokeStyle = "#1f6b4a";
				ctx.lineWidth = 2.2;
				ctx.beginPath();
				ctx.arc(x, y, r, 0, Math.PI * 2);
				ctx.stroke();
			}
			if (studentAns && b.choice === studentAns && studentAns !== key) {
				ctx.strokeStyle = "#9f2d2d";
				ctx.lineWidth = 2.4;
				ctx.beginPath();
				ctx.moveTo(x - r, y - r);
				ctx.lineTo(x + r, y + r);
				ctx.moveTo(x + r, y - r);
				ctx.lineTo(x - r, y + r);
				ctx.stroke();
			}
		}
	}
	ctx.fillStyle = "rgba(28,25,23,0.9)";
	ctx.fillRect(0, 0, out.width, Math.max(48, out.height * .07));
	ctx.fillStyle = "#fbfaf6";
	ctx.font = `600 ${Math.round(out.width * .022)}px IBM Plex Sans, sans-serif`;
	const title = `${studentName || "Student"}  ·  Roll ${result.rollNumber}  ·  ${result.score}/${assessment.itemCount}  (${result.percentage.toFixed(0)}%)`;
	ctx.fillText(title, 16, Math.round(out.height * .045));
	ctx.font = `400 ${Math.round(out.width * .016)}px IBM Plex Sans, sans-serif`;
	ctx.fillText(`Correct ${result.correct}   Wrong ${result.wrong}   Blank ${result.blank}   ${assessment.name}`, 16, Math.round(out.height * .062));
	return out;
}
function ScanPage() {
	const { assessmentId } = Route$6.useSearch();
	const assessments = useLiveQuery(() => db.assessments.toArray()) ?? [];
	const students = useLiveQuery(() => db.students.toArray()) ?? [];
	const [aid, setAid] = (0, import_react.useState)(assessmentId ?? "");
	const selected = assessments.find((a) => a.id === (aid || assessmentId)) ?? assessments[0];
	const scans = useLiveQuery(() => selected ? db.scans.where("assessmentId").equals(selected.id).toArray() : [], [selected?.id]) ?? [];
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [progress, setProgress] = (0, import_react.useState)("");
	const videoRef = (0, import_react.useRef)(null);
	const [camOn, setCamOn] = (0, import_react.useState)(false);
	async function processCanvas(canvas, filename) {
		if (!selected) throw new Error("Choose an assessment first.");
		const blob = await canvasToBlob(canvas, "image/jpeg");
		const detection = await detectSheet(canvas, selected);
		const existing = scans.map((s) => s.rollNumber);
		const scored = scoreDetection(selected, detection, students, existing);
		const student = students.find((s) => s.id === scored.studentId);
		const marked = await renderMarkedPaper(detection.warped, selected, scored, student?.fullName);
		const markedBlob = await canvasToBlob(marked, "image/png");
		const originalBlobId = await putBlob("scan", blob, filename);
		const markedBlobId = await putBlob("marked", markedBlob, filename.replace(/\.\w+$/, "") + "-marked.png");
		const rec = {
			...scored,
			id: uid("scan"),
			originalBlobId,
			markedBlobId,
			createdAt: nowIso(),
			updatedAt: nowIso()
		};
		await saveScan(rec);
		return rec;
	}
	async function onFiles(files) {
		if (!files?.length || !selected) return;
		setBusy(true);
		try {
			for (let i = 0; i < files.length; i++) {
				const file = files[i];
				setProgress(`Reading ${file.name} (${i + 1}/${files.length})`);
				if (file.type === "application/pdf") {
					toast.error("Save PDF pages as JPEG or PNG, then upload the images.");
					continue;
				}
				const bmp = await createImageBitmap(file);
				const c = document.createElement("canvas");
				c.width = bmp.width;
				c.height = bmp.height;
				c.getContext("2d").drawImage(bmp, 0, 0);
				await processCanvas(c, file.name);
			}
			toast.success("Scanning finished. Review any flagged rows.");
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "The answer sheet could not be processed.");
		} finally {
			setBusy(false);
			setProgress("");
		}
	}
	async function simulateClass() {
		if (!selected) return;
		const classStudents = students.filter((s) => s.gradeLevel === selected.gradeLevel && s.section === selected.section);
		if (!classStudents.length) {
			toast.error("Add students before running a class scan.");
			return;
		}
		setBusy(true);
		try {
			for (let i = 0; i < classStudents.length; i++) {
				const st = classStudents[i];
				setProgress(`Scanning ${st.fullName} (${i + 1}/${classStudents.length})`);
				const answers = selected.answerKey.map((k, idx) => {
					if (idx % 9 === i % 9) return selected.sheetConfig.choices[(selected.sheetConfig.choices.indexOf(k) + 1) % selected.sheetConfig.choices.length];
					if (idx === 17 && i % 4 === 0) return null;
					return k;
				});
				const { canvas } = renderSheetCanvas(selected.sheetConfig, {
					student: st,
					fill: {
						answers,
						rollNumber: st.rollNumber
					}
				});
				await processCanvas(canvas, `${st.rollNumber}.png`);
			}
			toast.success("Class set processed. Open flagged rows to confirm.");
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "Bulk scan failed.");
		} finally {
			setBusy(false);
			setProgress("");
		}
	}
	async function startCam() {
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
			if (videoRef.current) {
				videoRef.current.srcObject = stream;
				await videoRef.current.play();
				setCamOn(true);
			}
		} catch {
			toast.error("The camera could not be started in this browser.");
		}
	}
	async function captureCam() {
		const v = videoRef.current;
		if (!v) return;
		const c = document.createElement("canvas");
		c.width = v.videoWidth;
		c.height = v.videoHeight;
		c.getContext("2d").drawImage(v, 0, 0);
		setBusy(true);
		try {
			await processCanvas(c, `webcam-${Date.now()}.png`);
			toast.success("Frame captured.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Scan papers"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Upload photos, capture from a camera, or run a sample class so you can see bulk scoring without a printer."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-wrap items-end gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-52 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide text-muted uppercase",
							children: "Assessment"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "mt-1 h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm",
							value: selected?.id ?? "",
							onChange: (e) => setAid(e.target.value),
							children: assessments.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: a.id,
								children: a.name
							}, a.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/jpeg,image/png,image/webp,application/pdf",
						multiple: true,
						hidden: true,
						onChange: (e) => void onFiles(e.target.files)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						type: "button",
						onClick: (e) => e.currentTarget.previousElementSibling?.click(),
						children: "Upload images"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: startCam,
						disabled: camOn,
						children: "Webcam"
					}),
					camOn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: captureCam,
						children: "Capture frame"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: simulateClass,
						disabled: busy,
						children: "Scan sample class"
					})
				]
			}),
			camOn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: videoRef,
				className: "max-h-64 w-full rounded-[var(--radius-md)] bg-ink",
				playsInline: true
			}),
			busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: progress || "Working…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "overflow-x-auto p-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-4 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Processing table" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[800px] text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-left text-xs tracking-wide text-muted uppercase",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2",
									children: "Roll"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Student" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Score" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "%" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Correct" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Wrong" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Blank" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Status" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: scans.map((s) => {
							const st = students.find((x) => x.id === s.studentId);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-2 font-mono",
										children: s.rollNumber
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: st?.fullName ?? "Unknown" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [
										s.score,
										"/",
										selected?.itemCount
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [Math.round(s.percentage), "%"] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: s.correct }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: s.wrong }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: s.blank }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: s.status === "passed" ? "ok" : s.status === "flagged" ? "warn" : "danger",
										children: s.status
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "pr-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/review/$id",
											params: { id: s.id },
											className: "text-accent underline",
											children: "Review"
										})
									})
								]
							}, s.id);
						}) })]
					}),
					!scans.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-6 text-sm text-muted",
						children: "No sheets yet for this assessment."
					})
				]
			})
		]
	});
}
//#endregion
export { ScanPage as component };
