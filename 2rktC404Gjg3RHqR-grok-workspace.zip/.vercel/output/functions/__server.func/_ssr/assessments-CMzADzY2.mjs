import { i as __toESM } from "../_runtime.mjs";
import { c as uid, i as formatDate, n as db, o as nowIso } from "./utils-DYXV9Fl_.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { s as defaultSheetConfig } from "./router-CLqpKR0U.mjs";
import { t as Button } from "./button-BW_xqhyX.mjs";
import { n as Textarea, t as Input } from "./input-BhHbezq6.mjs";
import { t as Card } from "./card-BL1KPyKC.mjs";
import { t as Badge } from "./badge-PKkwSRI6.mjs";
import { a as saveAssessment, r as getSettings } from "./repo-DVWp7U09.mjs";
import { t as Label } from "./label-ZkCXXQbY.mjs";
import { n as DialogContent, r as DialogTitle, t as Dialog } from "./dialog-IeDYUs8y.mjs";
import { t as ASSESSMENT_TYPES } from "./types-wE3ipxpv.mjs";
import { t as useLiveQuery } from "../_libs/dexie-react-hooks.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assessments-CMzADzY2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AssessmentsPage() {
	const list = useLiveQuery(() => db.assessments.orderBy("date").reverse().toArray()) ?? [];
	const cats = useLiveQuery(() => db.categories.toArray()) ?? [];
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [subject, setSubject] = (0, import_react.useState)("Mathematics");
	const [items, setItems] = (0, import_react.useState)(20);
	const [passing, setPassing] = (0, import_react.useState)(12);
	const [type, setType] = (0, import_react.useState)("Quiz");
	const [instructions, setInstructions] = (0, import_react.useState)("Shade one bubble per item.");
	const [categoryId, setCategoryId] = (0, import_react.useState)("");
	async function create() {
		const settings = await getSettings();
		const t = nowIso();
		const a = {
			id: uid("asm"),
			name: name || "Untitled assessment",
			subject,
			gradeLevel: settings.defaultGrade,
			section: settings.defaultSection,
			teacher: settings.teacherName,
			schoolYear: settings.defaultSchoolYear,
			date: t.slice(0, 10),
			itemCount: items,
			passingScore: passing,
			instructions,
			answerKey: Array.from({ length: items }, () => "A"),
			timeLimitMinutes: null,
			type,
			categoryId: categoryId || cats[0]?.id || "",
			archived: false,
			sheetConfig: defaultSheetConfig({
				quizName: name || "Untitled assessment",
				subject,
				itemCount: items,
				teacher: settings.teacherName,
				school: settings.schoolName,
				instructions,
				rollDigits: settings.rollDigits
			}),
			createdAt: t,
			updatedAt: t
		};
		await saveAssessment(a);
		toast.success("Assessment saved.");
		setOpen(false);
		setName("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: "Assessments"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Answer keys, bubble sheets, and scan history live here."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setOpen(true),
					children: "Create assessment"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: list.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/assessments/$id",
					params: { id: a.id },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "flex flex-wrap items-center justify-between gap-3 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: a.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								a.subject,
								" · Grade ",
								a.gradeLevel,
								"-",
								a.section,
								" · ",
								a.itemCount,
								" items · ",
								formatDate(a.date)
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: a.archived ? "neutral" : "accent",
								children: a.archived ? "Archived" : a.type
							})
						})]
					})
				}, a.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New assessment" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: name,
								onChange: (e) => setName(e.target.value)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Subject" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: subject,
										onChange: (e) => setSubject(e.target.value)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Type" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: "h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm",
										value: type,
										onChange: (e) => setType(e.target.value),
										children: ASSESSMENT_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Items" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: items,
										onChange: (e) => setItems(Number(e.target.value))
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Passing score" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: passing,
										onChange: (e) => setPassing(Number(e.target.value))
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "h-10 w-full rounded-[var(--radius-sm)] border border-line bg-surface px-2 text-sm",
								value: categoryId,
								onChange: (e) => setCategoryId(e.target.value),
								children: cats.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: c.id,
									children: [
										c.name,
										" (",
										c.weight,
										"%)"
									]
								}, c.id))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Instructions" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: instructions,
								onChange: (e) => setInstructions(e.target.value)
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setOpen(false),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: create,
							children: "Save"
						})]
					})
				] })
			})
		]
	});
}
//#endregion
export { AssessmentsPage as component };
