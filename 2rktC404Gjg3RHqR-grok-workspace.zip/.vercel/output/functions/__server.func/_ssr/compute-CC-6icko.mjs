//#region node_modules/.nitro/vite/services/ssr/assets/compute-CC-6icko.js
function computeGradebook(students, assessments, scans, categories) {
	const active = assessments.filter((a) => !a.archived);
	return students.slice().sort((a, b) => a.rollNumber.localeCompare(b.rollNumber)).map((student) => {
		const byAssessment = {};
		for (const a of active) {
			const s = scans.find((x) => x.assessmentId === a.id && x.studentId === student.id && x.status !== "pending");
			byAssessment[a.id] = s ?? null;
		}
		const categoryPct = {};
		for (const c of categories) {
			const scores = active.filter((a) => a.categoryId === c.id).map((a) => byAssessment[a.id]).filter((x) => !!x).map((x) => x.percentage);
			categoryPct[c.id] = scores.length ? scores.reduce((p, n) => p + n, 0) / scores.length : null;
		}
		let weighted = 0;
		let wsum = 0;
		for (const c of categories) {
			const pct = categoryPct[c.id];
			if (pct == null) continue;
			weighted += pct * c.weight;
			wsum += c.weight;
		}
		return {
			student,
			byAssessment,
			categoryPct,
			average: wsum ? weighted / wsum : null
		};
	});
}
function itemAnalysis(assessment, scans) {
	const n = assessment.itemCount;
	const stats = Array.from({ length: n }, (_, item) => ({
		item,
		correct: 0,
		wrong: 0,
		blank: 0,
		difficulty: 0,
		optionCounts: Object.fromEntries(assessment.sheetConfig.choices.map((c) => [c, 0])),
		mostWrong: null
	}));
	const usable = scans.filter((s) => s.assessmentId === assessment.id && !s.flags.includes("unreadable"));
	for (const s of usable) for (let i = 0; i < n; i++) {
		const a = s.answers[i] ?? null;
		const k = assessment.answerKey[i];
		const st = stats[i];
		if (!a) st.blank++;
		else {
			st.optionCounts[a] = (st.optionCounts[a] ?? 0) + 1;
			if (k && a === k) st.correct++;
			else st.wrong++;
		}
	}
	for (const st of stats) {
		const total = st.correct + st.wrong + st.blank;
		st.difficulty = total ? st.correct / total : 0;
		const key = assessment.answerKey[st.item];
		let best = null;
		let bestN = 0;
		for (const [opt, count] of Object.entries(st.optionCounts)) {
			if (opt === key) continue;
			if (count > bestN) {
				bestN = count;
				best = opt;
			}
		}
		st.mostWrong = bestN ? best : null;
	}
	return stats;
}
function assessmentSummary(assessment, scans) {
	const usable = scans.filter((s) => s.assessmentId === assessment.id && s.status !== "pending");
	const scores = usable.map((s) => s.score).sort((a, b) => a - b);
	const avg = scores.length ? scores.reduce((p, n) => p + n, 0) / scores.length : 0;
	const mid = scores.length ? scores.length % 2 ? scores[(scores.length - 1) / 2] : (scores[scores.length / 2 - 1] + scores[scores.length / 2]) / 2 : 0;
	const passed = usable.filter((s) => s.score >= assessment.passingScore).length;
	return {
		count: usable.length,
		highest: scores.length ? scores[scores.length - 1] : 0,
		lowest: scores.length ? scores[0] : 0,
		average: avg,
		median: mid,
		passed,
		failed: usable.length - passed
	};
}
//#endregion
export { computeGradebook as n, itemAnalysis as r, assessmentSummary as t };
