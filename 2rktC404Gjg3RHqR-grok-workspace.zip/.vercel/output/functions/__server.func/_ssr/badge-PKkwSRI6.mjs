import { t as cn } from "./utils-DYXV9Fl_.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-PKkwSRI6.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, tone = "neutral", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium", {
			neutral: "bg-bg text-muted border-line",
			ok: "bg-accent-soft text-ok border-transparent",
			warn: "bg-[#f3e6cf] text-warn border-transparent",
			danger: "bg-[#f3d6d2] text-danger border-transparent",
			accent: "bg-accent text-accent-fg border-transparent"
		}[tone], className),
		...props
	});
}
//#endregion
export { Badge as t };
