import { i as __toESM } from "../_runtime.mjs";
import { a as fullName, c as uid, n as db, o as nowIso, r as downloadBlob, s as padRoll } from "./utils-DYXV9Fl_.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Button } from "./button-BW_xqhyX.mjs";
import { n as Textarea, t as Input } from "./input-BhHbezq6.mjs";
import { t as Card } from "./card-BL1KPyKC.mjs";
import { t as Badge } from "./badge-PKkwSRI6.mjs";
import { c as upsertStudent, n as deleteStudent } from "./repo-DVWp7U09.mjs";
import { t as Label } from "./label-ZkCXXQbY.mjs";
import { n as DialogContent, r as DialogTitle, t as Dialog } from "./dialog-IeDYUs8y.mjs";
import { t as useLiveQuery } from "../_libs/dexie-react-hooks.mjs";
import { n as utils, r as writeSync, t as readSync } from "../_libs/xlsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/students-BWwLj-qi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STUDENT_COLUMNS = [
	"Roll Number",
	"LRN",
	"First Name",
	"Middle Name",
	"Last Name",
	"Grade",
	"Section",
	"School Year"
];
function studentTemplateWorkbook() {
	const ws = utils.aoa_to_sheet([[...STUDENT_COLUMNS], [
		"001",
		"136900001001",
		"Juan",
		"P",
		"Dela Cruz",
		"9",
		"A",
		"2026-2027"
	]]);
	ws["!cols"] = STUDENT_COLUMNS.map(() => ({ wch: 16 }));
	const wb = utils.book_new();
	utils.book_append_sheet(wb, ws, "Students");
	return writeSync(wb, {
		type: "array",
		bookType: "xlsx"
	});
}
function studentTemplateCsv() {
	return `${STUDENT_COLUMNS.join(",")}
001,136900001001,Juan,P,Dela Cruz,9,A,2026-2027
`;
}
function cell(v) {
	return String(v ?? "").trim();
}
function parseStudentFile(data, filename) {
	const wb = readSync(data, { type: "array" });
	const sheet = wb.Sheets[wb.SheetNames[0]];
	if (!sheet) return [];
	return utils.sheet_to_json(sheet, { defval: "" }).map((raw, i) => {
		const get = (...keys) => {
			for (const k of keys) {
				const found = Object.keys(raw).find((rk) => rk.toLowerCase().replace(/\s+/g, "") === k.toLowerCase().replace(/\s+/g, ""));
				if (found) return cell(raw[found]);
			}
			return "";
		};
		const row = {
			row: i + 2,
			rollNumber: padRoll(get("Roll Number", "Roll", "RollNo")),
			lrn: get("LRN", "Student ID", "LRN/Student ID"),
			firstName: get("First Name", "First"),
			middleName: get("Middle Name", "Middle", "MI"),
			lastName: get("Last Name", "Last"),
			gradeLevel: get("Grade", "Grade Level"),
			section: get("Section"),
			schoolYear: get("School Year", "SY"),
			errors: [],
			warnings: []
		};
		if (!row.rollNumber) row.errors.push("Missing roll number");
		if (!row.firstName) row.errors.push("Missing first name");
		if (!row.lastName) row.errors.push("Missing last name");
		if (!row.gradeLevel) row.errors.push("Missing grade");
		if (!row.section) row.errors.push("Missing section");
		return row;
	});
}
function validateImport(rows, existing) {
	const byRoll = /* @__PURE__ */ new Map();
	const byLrn = /* @__PURE__ */ new Map();
	rows.forEach((r, i) => {
		if (r.rollNumber) {
			const a = byRoll.get(r.rollNumber) ?? [];
			a.push(i);
			byRoll.set(r.rollNumber, a);
		}
		if (r.lrn) {
			const a = byLrn.get(r.lrn) ?? [];
			a.push(i);
			byLrn.set(r.lrn, a);
		}
	});
	return rows.map((r) => {
		const errors = [...r.errors];
		const warnings = [...r.warnings];
		if ((byRoll.get(r.rollNumber)?.length ?? 0) > 1) errors.push("Duplicate roll number in file");
		if (r.lrn && (byLrn.get(r.lrn)?.length ?? 0) > 1) errors.push("Duplicate LRN in file");
		if (existing.some((s) => s.rollNumber === r.rollNumber)) warnings.push("Roll number already in roster");
		if (r.lrn && existing.some((s) => s.lrn && s.lrn === r.lrn)) warnings.push("LRN already in roster");
		return {
			...r,
			errors,
			warnings
		};
	});
}
function rowsToStudents(rows, existing, mode) {
	const t = nowIso();
	if (mode === "replace") return rows.filter((r) => r.errors.length === 0).map((r) => toStudent(r, t));
	const map = new Map(existing.map((s) => [s.id, s]));
	const byRoll = new Map(existing.map((s) => [s.rollNumber, s]));
	for (const r of rows) {
		if (r.errors.length) continue;
		const prev = byRoll.get(r.rollNumber);
		if (prev && (mode === "update" || mode === "add")) {
			if (mode === "add") continue;
			const next = {
				...prev,
				...toStudent(r, t),
				id: prev.id,
				createdAt: prev.createdAt
			};
			map.set(prev.id, next);
		} else {
			const s = toStudent(r, t);
			map.set(s.id, s);
		}
	}
	return Array.from(map.values());
}
function toStudent(r, t) {
	return {
		id: uid("stu"),
		rollNumber: padRoll(r.rollNumber),
		lrn: r.lrn,
		firstName: r.firstName,
		middleName: r.middleName,
		lastName: r.lastName,
		fullName: fullName(r.firstName, r.middleName, r.lastName),
		gradeLevel: r.gradeLevel,
		section: r.section,
		schoolYear: r.schoolYear,
		extra: "",
		createdAt: t,
		updatedAt: t
	};
}
function studentsToXlsx(students) {
	const aoa = [[...STUDENT_COLUMNS, "Full Name"], ...students.map((s) => [
		s.rollNumber,
		s.lrn,
		s.firstName,
		s.middleName,
		s.lastName,
		s.gradeLevel,
		s.section,
		s.schoolYear,
		s.fullName
	])];
	const ws = utils.aoa_to_sheet(aoa);
	const wb = utils.book_new();
	utils.book_append_sheet(wb, ws, "Students");
	return writeSync(wb, {
		type: "array",
		bookType: "xlsx"
	});
}
function emptyForm() {
	return {
		rollNumber: "",
		lrn: "",
		firstName: "",
		middleName: "",
		lastName: "",
		gradeLevel: "9",
		section: "A",
		schoolYear: "2026-2027",
		extra: ""
	};
}
function StudentsPage() {
	const students = useLiveQuery(() => db.students.toArray()) ?? [];
	const [q, setQ] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)(emptyForm());
	const [importOpen, setImportOpen] = (0, import_react.useState)(false);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [mode, setMode] = (0, import_react.useState)("add");
	const filtered = (0, import_react.useMemo)(() => {
		const s = q.trim().toLowerCase();
		return students.filter((st) => {
			if (!s) return true;
			return [
				st.fullName,
				st.rollNumber,
				st.lrn,
				st.gradeLevel,
				st.section
			].join(" ").toLowerCase().includes(s);
		}).sort((a, b) => a.rollNumber.localeCompare(b.rollNumber));
	}, [students, q]);
	function startNew() {
		setEditing(null);
		setForm(emptyForm());
		setOpen(true);
	}
	function startEdit(st) {
		setEditing(st);
		setForm({ ...st });
		setOpen(true);
	}
	async function save() {
		if (!form.rollNumber || !form.firstName || !form.lastName) {
			toast.error("Roll number, first name, and last name are required.");
			return;
		}
		if (students.find((s) => s.rollNumber === form.rollNumber.padStart(3, "0") && s.id !== editing?.id)) {
			toast.error("That roll number is already assigned.");
			return;
		}
		await upsertStudent({
			...form,
			id: editing?.id
		});
		toast.success(editing ? "Student updated." : "Student added.");
		setOpen(false);
	}
	async function onImportFile(file) {
		const rows = validateImport(parseStudentFile(await file.arrayBuffer(), file.name), students);
		setPreview(rows);
	}
	async function commitImport() {
		if (!preview) return;
		const next = rowsToStudents(preview, students, mode);
		if (mode === "replace") await db.students.clear();
		await db.students.bulkPut(next);
		toast.success("Student list updated.");
		setImportOpen(false);
		setPreview(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: "Students"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Roster for quizzes, scans, and the gradebook."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => {
								const buf = studentTemplateWorkbook();
								downloadBlob(new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }), "student-template.xlsx");
							},
							children: "Download student template"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => downloadBlob(new Blob([studentTemplateCsv()], { type: "text/csv" }), "student-template.csv"),
							children: "CSV template"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setImportOpen(true),
							children: "Import"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => {
								const buf = studentsToXlsx(students);
								downloadBlob(new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }), "students.xlsx");
							},
							children: "Export Excel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: startNew,
							children: "Add student"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				placeholder: "Search name, roll, LRN, grade, section",
				value: q,
				onChange: (e) => setQ(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "overflow-x-auto p-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[720px] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b border-line text-xs tracking-wide text-muted uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Roll"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Student" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "LRN" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Grade" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Section" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "SY" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: filtered.map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-line last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 font-mono tabular-nums",
								children: st.rollNumber
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/students/$id",
								params: { id: st.id },
								className: "font-medium hover:underline",
								children: st.fullName
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-muted",
								children: st.lrn || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: st.gradeLevel }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: st.section }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-muted",
								children: st.schoolYear
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => startEdit(st),
									children: "Edit"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: async () => {
										if (!confirm(`Remove ${st.fullName} from the roster?`)) return;
										await deleteStudent(st.id);
										toast.success("Student removed.");
									},
									children: "Delete"
								})]
							})
						]
					}, st.id)) })]
				}), !filtered.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-sm text-muted",
					children: "No students match this search."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editing ? "Edit student" : "Add student" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [[
							["rollNumber", "Roll number"],
							["lrn", "LRN / Student ID"],
							["firstName", "First name"],
							["middleName", "Middle name"],
							["lastName", "Last name"],
							["gradeLevel", "Grade"],
							["section", "Section"],
							["schoolYear", "School year"]
						].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form[key],
								onChange: (e) => setForm({
									...form,
									[key]: e.target.value
								})
							})]
						}, key)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1 sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Notes" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: form.extra,
								onChange: (e) => setForm({
									...form,
									extra: e.target.value
								})
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setOpen(false),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: save,
							children: "Save"
						})]
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: importOpen,
				onOpenChange: setImportOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-3xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Import students" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Existing records are not erased unless you choose Replace."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "mt-4 text-sm",
							type: "file",
							accept: ".xlsx,.xls,.csv",
							onChange: (e) => {
								const f = e.target.files?.[0];
								if (f) onImportFile(f);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [
								"add",
								"update",
								"replace"
							].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: mode === m ? "default" : "outline",
								onClick: () => setMode(m),
								children: m === "add" ? "Add new" : m === "update" ? "Update existing" : "Replace list"
							}, m))
						}),
						preview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 max-h-72 overflow-auto text-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "text-left text-xs text-muted",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Row" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Roll" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Name" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Issues" })
									]
								}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: preview.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-line",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: r.row }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: r.rollNumber }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [
											r.firstName,
											" ",
											r.lastName
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [r.errors.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											tone: "danger",
											className: "mr-1",
											children: e
										}, e)), r.warnings.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											tone: "warn",
											className: "mr-1",
											children: e
										}, e))] })
									]
								}, r.row)) })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setImportOpen(false),
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: !preview,
								onClick: commitImport,
								children: "Save import"
							})]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { StudentsPage as component };
