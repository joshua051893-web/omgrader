import { n as db, r as downloadBlob } from "./utils-DYXV9Fl_.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as Button } from "./button-BW_xqhyX.mjs";
import { t as Card } from "./card-BL1KPyKC.mjs";
import { t as useLiveQuery } from "../_libs/dexie-react-hooks.mjs";
import { n as computeGradebook } from "./compute-CC-6icko.mjs";
import { n as utils, r as writeSync } from "../_libs/xlsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gradebook-B4w6LFhD.js
var import_jsx_runtime = require_jsx_runtime();
function GradebookPage() {
	const students = useLiveQuery(() => db.students.toArray()) ?? [];
	const assessments = useLiveQuery(() => db.assessments.toArray()) ?? [];
	const scans = useLiveQuery(() => db.scans.toArray()) ?? [];
	const cats = useLiveQuery(() => db.categories.toArray()) ?? [];
	const active = assessments.filter((a) => !a.archived);
	const rows = computeGradebook(students, assessments, scans, cats);
	function exportBook() {
		const data = rows.map((r) => {
			const rec = {
				Roll: r.student.rollNumber,
				Student: r.student.fullName
			};
			for (const a of active) {
				const s = r.byAssessment[a.id];
				rec[a.name] = s ? Math.round(s.percentage) : "";
			}
			rec.Average = r.average == null ? "" : Math.round(r.average);
			return rec;
		});
		const ws = utils.json_to_sheet(data);
		const wb = utils.book_new();
		utils.book_append_sheet(wb, ws, "Gradebook");
		const buf = writeSync(wb, {
			type: "array",
			bookType: "xlsx"
		});
		downloadBlob(new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }), "gradebook.xlsx");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Gradebook"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: ["Weights: ", cats.map((c) => `${c.name} ${c.weight}%`).join(" · ") || "Set weights in Settings"]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: exportBook,
				children: "Export Excel"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "overflow-x-auto p-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[800px] text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-left text-xs text-muted uppercase",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3",
							children: "Roll"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Student" }),
						active.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: a.name }, a.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Average" })
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-2 font-mono",
							children: r.student.rollNumber
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							className: "hover:underline",
							to: "/students/$id",
							params: { id: r.student.id },
							children: r.student.fullName
						}) }),
						active.map((a) => {
							const s = r.byAssessment[a.id];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "tabular-nums",
								children: s ? `${s.score}/${a.itemCount}` : "—"
							}, a.id);
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "tabular-nums",
							children: r.average == null ? "—" : `${r.average.toFixed(0)}%`
						})
					]
				}, r.student.id)) })]
			})
		})]
	});
}
//#endregion
export { GradebookPage as component };
